import { eq } from "drizzle-orm";
import { randomBytes, randomUUID, scrypt, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { db } from "@/db";
import { accounts, profiles } from "@/db/schema";
import { logActivity, profileForUser, visitorCountry, visitorCountryCode } from "@/lib/app";

export const dynamic = "force-dynamic";
const scryptAsync = promisify(scrypt);
const validGenders = new Set(["male", "female", "nonbinary", "prefer-not-to-say"]);

async function hash(password: string, salt: string) {
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  return derived.toString("hex");
}

function safeAccount(account: typeof accounts.$inferSelect) {
  return {
    id: account.id,
    email: account.email,
    name: account.name,
    dob: account.dob,
    gender: account.gender,
    country: account.country,
    createdAt: account.createdAt,
    lastLoginAt: account.lastLoginAt,
  };
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const action = String(body.action || "signup");
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 6) {
      return Response.json({ error: "Use a valid email and a password of at least 6 characters." }, { status: 400 });
    }

    if (action === "signin") {
      const [account] = await db.select().from(accounts).where(eq(accounts.email, email)).limit(1);
      if (!account) return Response.json({ error: "No account found for this email. Please sign up first." }, { status: 404 });
      const candidate = await hash(password, account.passwordSalt);
      const valid = timingSafeEqual(Buffer.from(candidate, "hex"), Buffer.from(account.passwordHash, "hex"));
      if (!valid) return Response.json({ error: "Incorrect password. Please try again." }, { status: 401 });
      await db.update(accounts).set({ lastLoginAt: new Date() }).where(eq(accounts.id, account.id));
      let profile = await profileForUser(account.id);
      if (!profile) {
        // Heal an older guest profile that used the same email under a different id.
        const [byEmail] = await db.select().from(profiles).where(eq(profiles.email, account.email)).limit(1);
        if (byEmail) {
          await db.update(profiles).set({ userId: account.id }).where(eq(profiles.email, account.email));
          profile = await profileForUser(account.id);
        }
      }
      if (!profile) {
        await db.insert(profiles).values({
          userId: account.id, email: account.email, name: account.name, dob: account.dob,
          gender: account.gender, country: account.country, countryCode: account.countryCode || "",
        });
        profile = await profileForUser(account.id);
      }
      await logActivity(account.id, "signed_in", account.country);
      return Response.json({ account: safeAccount({ ...account, lastLoginAt: new Date() }), profile });
    }

    const name = String(body.name || "").trim();
    const dob = String(body.dob || "").trim();
    const gender = String(body.gender || "").trim().toLowerCase();
    if (!name || !dob || !validGenders.has(gender) || new Date(dob).getTime() > Date.now()) {
      return Response.json({ error: "Please add your name, birthday and gender." }, { status: 400 });
    }
    const [existingProfile] = await db.select().from(profiles).where(eq(profiles.email, email)).limit(1);
    const [existing] = await db.select({ id: accounts.id }).from(accounts).where(eq(accounts.email, email)).limit(1);
    if (existing) {
      // Heal a half-created account: point the older same-email profile at the account id.
      if (existingProfile && existingProfile.userId !== existing.id) {
        const clash = await profileForUser(existing.id);
        if (!clash) await db.update(profiles).set({ userId: existing.id }).where(eq(profiles.email, email));
      }
      return Response.json({ error: "This email is already registered. Please sign in." }, { status: 409 });
    }

    // Adopt an existing guest profile with this email so history and admin checks carry over.
    const id = existingProfile?.userId || randomUUID();
    const salt = randomBytes(16).toString("hex");
    const passwordHash = await hash(password, salt);
    const country = visitorCountry(request);
    const countryCode = visitorCountryCode(request);
    const lockedUntil = new Date(Date.now() + 24 * 60 * 60 * 1000);
    await db.insert(accounts).values({ id, email, passwordHash, passwordSalt: salt, name, dob, gender, country, countryCode, lastLoginAt: new Date() });
    await db.insert(profiles).values({
      userId: id, email, name, dob, gender, country, countryCode, profileLockedUntil: lockedUntil,
    }).onConflictDoUpdate({
      target: profiles.userId,
      set: { email, name, dob, gender, country, countryCode, profileLockedUntil: lockedUntil, updatedAt: new Date() },
    });
    const profile = await profileForUser(id);
    await logActivity(id, "signed_up", country, { gender });
    const [account] = await db.select().from(accounts).where(eq(accounts.id, id)).limit(1);
    return Response.json({ account: safeAccount(account), profile });
  } catch {
    return Response.json({ error: "Authentication is temporarily unavailable." }, { status: 500 });
  }
}
