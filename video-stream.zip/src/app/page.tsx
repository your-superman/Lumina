"use client";

import { FormEvent, type ReactElement, useCallback, useEffect, useRef, useState } from "react";

type Gender = "male" | "female" | "nonbinary" | "prefer-not-to-say" | "";
type Preference = "all" | "male" | "female";
type CallState = "idle" | "searching" | "connected";
type AdminSection = "overview" | "people" | "activity" | "ads" | "notifications" | "messages" | "masks" | "branding" | "system";
type MainTab = "connect" | "profile" | "support" | "admin";

type Profile = {
  userId: string; email: string; name: string; dob: string; gender: Gender; country: string; countryCode?: string;
  profileLockedUntil: string | null; updatedAt?: string;
};
type Peer = { name: string; gender: string; country: string; countryCode?: string };
type MatchResponse = { matched: boolean; waiting?: boolean; sessionId?: string; initiator?: boolean; peer?: Peer; error?: string };
type Advertisement = {
  id: string; title: string; mediaUrl: string; mediaType: "image" | "video"; linkUrl: string;
  borderColor: string; durationSeconds?: number | null; active: boolean; createdAt: string;
};
type ChatItem = { id: string; text: string; mine: boolean; sentAt: string };
type AccountInfo = { id: string; email: string; name: string; dob: string; gender: string; country: string; countryCode?: string; createdAt: string; lastLoginAt: string | null };
type AppNotification = { id: string; targetUserId: string | null; title: string; body: string; imageUrl: string; createdAt: string; expiresAt?: string | null; read?: boolean };
type FaceMask = { id: string; name: string; imageUrl: string; active: boolean; createdAt: string };
type SplashSetting = { mode: "logo" | "full"; mediaType: "image" | "gif" | "video"; mediaUrl: string; durationSeconds: number; updatedAt?: string | null };
type SupportMessage = { id: string; userId: string; senderId: string; senderRole: "user" | "admin" | string; body: string; imageUrl: string; readByAdmin: boolean; readByUser: boolean; createdAt: string };
type SupportConversation = { userId: string; name: string; email: string; country: string; countryCode?: string; unread: number; lastMessageAt?: string; messages: SupportMessage[] };
type AdminData = {
  summary: { users: number; countries: number; calls: number; activeAds: number; online: number; accounts: number; totalVisitors: number };
  onlineUserIds: string[];
  users: Profile[]; accounts: AccountInfo[];
  activities: { id: number; userId: string; event: string; country: string; createdAt: string; detail: Record<string, unknown> }[];
  ads: Advertisement[]; notifications: AppNotification[];
};

const ADMIN_EMAIL = "mirzaahmed20042004@gmail.com";
const ICE_SERVERS: RTCIceServer[] = [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun1.l.google.com:19302" }];

function Icon({ name, size = 20, stroke = 2 }: { name: string; size?: number; stroke?: number }) {
  const paths: Record<string, ReactElement> = {
    spark: <path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Zm6 12 .7 2.3L21 18l-2.3.7L18 21l-.7-2.3L15 18l2.3-.7L18 15Z" />,
    video: <><rect x="3" y="6" width="12" height="12" rx="2" /><path d="m15 10 5-3v10l-5-3" /></>,
    user: <><circle cx="12" cy="8" r="3.25" /><path d="M5 20c.6-3.2 3.1-5 7-5s6.4 1.8 7 5" /></>,
    shield: <path d="M12 3 19 6v5c0 4.3-2.7 7.9-7 10-4.3-2.1-7-5.7-7-10V6l7-3Z" />,
    globe: <><circle cx="12" cy="12" r="9" /><path d="M3.5 12h17M12 3c2.3 2.5 3.4 5.5 3.4 9S14.3 18.5 12 21c-2.3-2.5-3.4-5.5-3.4-9S9.7 5.5 12 3Z" /></>,
    search: <><circle cx="11" cy="11" r="6.5" /><path d="m16 16 4 4" /></>,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    mic: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M8.5 21h7" /></>,
    micOff: <><path d="m4 4 16 16" /><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5.5 11.5a6.5 6.5 0 0 0 9.6 5.7M12 18v3M8.5 21h7" /></>,
    flip: <><path d="M7 7h8.5l-2.5-2.5M17 17H8.5L11 19.5" /><path d="M16 7a6 6 0 0 1 1 10M8 17a6 6 0 0 1-1-10" /></>,
    eye: <><path d="M2.5 12s3.3-5 9.5-5 9.5 5 9.5 5-3.3 5-9.5 5-9.5-5-9.5-5Z" /><circle cx="12" cy="12" r="2" /></>,
    eyeOff: <><path d="m3 3 18 18M10.5 7.2A10 10 0 0 1 12 7c6.2 0 9.5 5 9.5 5a18.6 18.6 0 0 1-3.1 3.4M6.2 6.2C3.7 7.9 2.5 10 2.5 12c0 0 3.3 5 9.5 5 1.2 0 2.3-.2 3.3-.5" /><path d="M10 10a3 3 0 0 0 4 4" /></>,
    hideSelf: <><circle cx="10" cy="8" r="3.4" /><path d="M4.8 20c.7-3.6 2.6-5.4 5.2-5.4s4.5 1.8 5.2 5.4" /><path d="m16 3.8 4.2 4.2M20.2 3.8 16 8" /></>,
    hidePartner: <><rect x="3" y="5" width="18" height="14" rx="3" /><circle cx="12" cy="10.2" r="1.9" /><path d="M8.7 16.4c.7-1.6 1.8-2.4 3.3-2.4s2.6.8 3.3 2.4M5.5 4.5l13 15" /></>,
    send: <path d="m21 3-7.5 18-3.1-7.4L3 10.5 21 3Zm-10.6 10.6L15 9" />,
    arrow: <path d="M5 12h14m-6-6 6 6-6 6" />,
    check: <path d="m5 12 4.2 4.2L19 6.8" />,
    lock: <><rect x="5" y="10" width="14" height="10" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3" /></>,
    camera: <><path d="M3 8.5A2.5 2.5 0 0 1 5.5 6h7A2.5 2.5 0 0 1 15 8.5v7a2.5 2.5 0 0 1-2.5 2.5h-7A2.5 2.5 0 0 1 3 15.5v-7Z" /><path d="m15 10 5-2.5v9L15 14" /></>,
    play: <path d="m9 7 7 5-7 5V7Z" fill="currentColor" stroke="none" />,
    ad: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M8 9h8M8 13h5" /></>,
    trash: <><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13" /></>,
    external: <><path d="M14 4h6v6M20 4l-9 9" /><path d="M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5" /></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    download: <><path d="M12 3v12m0 0 4-4m-4 4-4-4M4 20h16" /></>,
    bell: <><path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 3h-15L6 16Z" /><path d="M10 22a2.2 2.2 0 0 0 4 0" /></>,
    upload: <><path d="M12 16V4m0 0L8 8m4-4 4 4" /><path d="M4 20h16" /></>,
    logout: <><path d="M14 4h5v16h-5M10 8l-4 4 4 4M6 12h11" /></>,
    blur: <><circle cx="12" cy="12" r="3.2" /><circle cx="12" cy="12" r="7.5" strokeDasharray="2.5 3" /><circle cx="12" cy="12" r="10.2" strokeDasharray="1.5 4" /></>,
    gauge: <><path d="M4 14a8 8 0 1 1 16 0" /><path d="m12 14 4-4" /><path d="M2 19h20" /></>,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></>,
    layers: <><path d="m12 3 9 5-9 5-9-5 9-5Z" /><path d="m3 13 9 5 9-5" /></>,
    mask: <><path d="M4 10.2C4 6.8 7.5 4.5 12 4.5s8 2.3 8 5.7c0 3.9-2 8.3-4.7 8.3-1.5 0-2-.8-3.3-.8s-1.8.8-3.3.8C6 18.5 4 14.1 4 10.2Z" /><circle cx="9" cy="10.5" r=".7" fill="currentColor" /><circle cx="15" cy="10.5" r=".7" fill="currentColor" /><path d="M9.2 15.2c1.8 1 3.8 1 5.6 0" /></>,
    users: <><circle cx="9" cy="8.5" r="3" /><path d="M3.5 19.5c.6-3 2.5-4.6 5.5-4.6s4.9 1.6 5.5 4.6M16 5.8a3 3 0 0 1 0 5.7M17.5 15.2c1.7.6 2.7 2 3 4.3" /></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name] || paths.spark}</svg>;
}

function LuminaLogo({ compact = false, iconUrl = "/icons/icon-512.png" }: { compact?: boolean; iconUrl?: string }) {
  return (
    <div className="brand" aria-label="Lumina Connect">
      <span className="brand-mark"><img src={iconUrl} alt="" /></span>
      {!compact && <span className="brand-word">lumina<span>connect</span></span>}
    </div>
  );
}

/** Video element that (re)attaches its stream on every mount — fixes the blank self-preview. */
function StreamVideo({ stream, className, mirrored = false, muted = false }: { stream: MediaStream | null; className?: string; mirrored?: boolean; muted?: boolean }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (el.srcObject !== stream) el.srcObject = stream;
    if (stream) void el.play().catch(() => undefined);
  }, [stream]);
  return <video ref={ref} className={`${className || "video-feed"}${mirrored ? " mirrored" : ""}`} autoPlay muted={muted} playsInline />;
}

/** Country flag emoji from an ISO code — every country in the world. */
function flagEmoji(code?: string | null) {
  const clean = (code || "").trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(clean)) return "🌐";
  return String.fromCodePoint(...[...clean].map((char) => 127397 + char.charCodeAt(0)));
}

let regionNamesCache: Intl.DisplayNames | null = null;
function regionNames() {
  if (!regionNamesCache) { try { regionNamesCache = new Intl.DisplayNames(["en"], { type: "region" }); } catch { regionNamesCache = null; } }
  return regionNamesCache;
}
function countryLabel(code?: string | null, fallbackName?: string) {
  const clean = (code || "").trim().toUpperCase();
  if (/^[A-Z]{2}$/.test(clean)) { try { return regionNames()?.of(clean) || fallbackName || clean; } catch { return fallbackName || clean; } }
  return fallbackName && fallbackName !== "Unknown" ? fallbackName : "Worldwide";
}

let codeByNameCache: Map<string, string> | null = null;
/** Resolve a stored country name ("Pakistan") back to its code ("PK"). */
function codeForCountry(country?: string | null, code?: string | null) {
  const direct = (code || "").trim().toUpperCase();
  if (/^[A-Z]{2}$/.test(direct)) return direct;
  const name = (country || "").trim();
  if (/^[A-Z]{2}$/i.test(name)) return name.toUpperCase();
  if (!name || name === "Unknown") return "";
  if (!codeByNameCache) {
    codeByNameCache = new Map();
    const names = regionNames();
    if (names) {
      for (let a = 65; a <= 90; a++) for (let b = 65; b <= 90; b++) {
        const candidate = String.fromCharCode(a, b);
        try { const label = names.of(candidate); if (label && label !== candidate) codeByNameCache.set(label.toLowerCase(), candidate); } catch { /* not a region */ }
      }
    }
  }
  return codeByNameCache.get(name.toLowerCase()) || "";
}

/** "🇵🇰 Pakistan" — auto-detected from IP, works for every country. */
function countryWithFlag(country?: string | null, code?: string | null) {
  const resolved = codeForCountry(country, code);
  if (!resolved) return country && country !== "Unknown" ? country : "Worldwide";
  return `${flagEmoji(resolved)} ${countryLabel(resolved, country || undefined)}`;
}

function genderSymbol(gender?: string) { return gender === "female" ? "♀" : gender === "male" ? "♂" : "⚧"; }
function genderLabel(gender?: string) { return gender === "female" ? "Female" : gender === "male" ? "Male" : "Person"; }
function genderTone(gender?: string) { return gender === "female" ? "female" : gender === "male" ? "male" : "other"; }

function GenderAvatar({ gender, name }: { gender?: string; name: string }) {
  const tone = genderTone(gender);
  const main = tone === "female" ? "#FC84BD" : tone === "male" ? "#5AA9E6" : "#B79CED";
  const dark = tone === "female" ? "#D65290" : tone === "male" ? "#2F7FC4" : "#7E63C9";
  return (
    <div className={`gender-avatar ${tone}`} role="img" aria-label={`${name}, ${genderLabel(gender)}`}>
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <circle cx="60" cy="60" r="58" fill={tone === "female" ? "#FFE0EF" : tone === "male" ? "#DCEFFF" : "#EAE3FF"} />
        <path d="M22 112c5-22 19-32 38-32s33 10 38 32" fill={main} />
        {tone === "female" && <><rect x="33" y="46" width="11" height="38" rx="5.5" fill="#6B4632" /><rect x="76" y="46" width="11" height="38" rx="5.5" fill="#6B4632" /></>}
        <circle cx="60" cy="52" r="21" fill="#FFD9C4" />
        {tone === "female"
          ? <path d="M39 50c-1-15 9-24 21-24s22 9 21 24c-1 3-3 6-5 8-1-11-7-17-16-17s-15 6-16 17c-2-2-4-5-5-8Z" fill="#6B4632" />
          : <path d="M40 47c1-13 9-21 20-21s19 8 20 21c-6-7-12-9-20-9s-14 2-20 9Z" fill="#4A3428" />}
        <circle cx="53" cy="53" r="2.2" fill="#3B2A33" /><circle cx="67" cy="53" r="2.2" fill="#3B2A33" />
        <path d="M54 62c4 3 8 3 12 0" stroke="#3B2A33" strokeWidth="2.2" strokeLinecap="round" fill="none" />
        <circle cx="47" cy="60" r="3.4" fill="#FFB3D1" opacity=".8" /><circle cx="73" cy="60" r="3.4" fill="#FFB3D1" opacity=".8" />
        <path d="M52 92h16" stroke={dark} strokeWidth="3" strokeLinecap="round" />
      </svg>
      <span className="gender-badge" style={{ background: main }}>{genderSymbol(gender)}</span>
      <span className="sr-only">{name}</span>
    </div>
  );
}

function formatLock(value: string | null | undefined) {
  if (!value) return null;
  const difference = new Date(value).getTime() - Date.now();
  if (difference <= 0) return null;
  const hours = Math.floor(difference / 3_600_000);
  const minutes = Math.ceil((difference % 3_600_000) / 60_000);
  return `${hours}h ${minutes}m`;
}
function dateLabel(value: string | null | undefined) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(new Date(value));
}
/** Notifications auto-remove 24h after they are sent — show the countdown. */
function expiresInLabel(item: AppNotification) {
  const expires = item.expiresAt ? new Date(item.expiresAt).getTime() : new Date(item.createdAt).getTime() + 24 * 60 * 60 * 1000;
  const left = expires - Date.now();
  if (left <= 0) return "removing…";
  const hours = Math.floor(left / 3_600_000);
  const minutes = Math.max(1, Math.round((left % 3_600_000) / 60_000));
  return hours > 0 ? `auto-removes in ${hours}h ${minutes}m` : `auto-removes in ${minutes}m`;
}

type FaceBox = { x: number; y: number; w: number; h: number };
type FacePoint = { x: number; y: number };
type EyePair = { left: FacePoint; right: FacePoint };
type TrackedFace = {
  current: FaceBox; target: FaceBox; velocity: FaceBox; lastSeen: number;
  eyesCurrent?: EyePair; eyesTarget?: EyePair;
  noseCurrent?: FacePoint; noseTarget?: FacePoint;
  mouthCurrent?: FacePoint; mouthTarget?: FacePoint;
  chinCurrent?: FacePoint; chinTarget?: FacePoint;
  polygonCurrent?: FacePoint[]; polygonTarget?: FacePoint[];
};
type NormalizedFace = {
  box: FaceBox; eyes?: EyePair; nose?: FacePoint; mouth?: FacePoint;
  chin?: FacePoint; forehead?: FacePoint; polygon?: FacePoint[];
};
type FaceEngine = {
  kind: "mediapipe" | "native";
  detect: (video: HTMLVideoElement, timestamp: number) => Promise<NormalizedFace[]>;
};
type MaskKind = "eyes" | "full" | "lower" | "upper" | "left" | "right" | "custom";
type MaskAsset = {
  source: string;
  img: HTMLImageElement;
  crop: { sx: number; sy: number; sw: number; sh: number };
  bounds: { x: number; y: number; w: number; h: number };
  eyes?: EyePair;
  eyesFull?: EyePair;
  template: boolean;
  kind: MaskKind;
  coverage: number;
};
type BlurRig = {
  video: HTMLVideoElement; canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D;
  temp: HTMLCanvasElement; tempCtx: CanvasRenderingContext2D; small: HTMLCanvasElement;
  raf: number; lastDetect: number; lastFrame: number; detectorBusy: boolean;
  engine: FaceEngine | null; engineLoading: boolean; blurFilterSupported: boolean | null;
};
type PermState = "granted" | "denied" | "prompt" | "unsupported" | "unknown";
type BeforeInstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };

export default function HomePage() {
  const [userId, setUserId] = useState("");
  const [profile, setProfile] = useState<Profile | null>(null);
  const [profileForm, setProfileForm] = useState({ name: "", email: "", dob: "", gender: "" as Gender });
  const [tab, setTab] = useState<MainTab>("connect");
  const [preference, setPreference] = useState<Preference>("all");
  const [callState, setCallState] = useState<CallState>("idle");
  const [sessionId, setSessionId] = useState("");
  const [peer, setPeer] = useState<Peer | null>(null);
  const [connectAnim, setConnectAnim] = useState<Peer | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [muted, setMuted] = useState(false);
  const [selfHidden, setSelfHidden] = useState(false);
  const [peerHidden, setPeerHidden] = useState(false);
  const [peerVideoHidden, setPeerVideoHidden] = useState(false);
  const [faceBlur, setFaceBlur] = useState(false);
  const [faceEngineStatus, setFaceEngineStatus] = useState<"idle" | "loading" | "ready" | "error">("idle");
  const [connectionNotice, setConnectionNotice] = useState("");
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [chatText, setChatText] = useState("");
  const [messages, setMessages] = useState<ChatItem[]>([]);
  const [ads, setAds] = useState<Advertisement[]>([]);
  const [activeAd, setActiveAd] = useState(0);
  const [toast, setToast] = useState("");
  const [mediaError, setMediaError] = useState("");
  const [onlineCount, setOnlineCount] = useState(0);
  const [totalVisitors, setTotalVisitors] = useState(0);
  const [quality, setQuality] = useState({ rtt: 0, fps: 0, kbps: 0, label: "Auto optimizer ready" });
  const [pageVisible, setPageVisible] = useState(true);
  const [isOnline, setIsOnline] = useState(true);
  const [adminData, setAdminData] = useState<AdminData | null>(null);
  const [adminSection, setAdminSection] = useState<AdminSection>("overview");
  const [adminEmail, setAdminEmail] = useState("");
  const [adForm, setAdForm] = useState({ title: "", mediaUrl: "", linkUrl: "", mediaType: "image" as "image" | "video", borderColor: "#FC84BD" });
  const [adDuration, setAdDuration] = useState<number | null>(null);
  const [adFileName, setAdFileName] = useState("");
  const [saving, setSaving] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  // Auth
  const [authMode, setAuthMode] = useState<"signup" | "signin">("signup");
  const [password, setPassword] = useState("");
  const [signInForm, setSignInForm] = useState({ email: "", password: "" });
  const [signedIn, setSignedIn] = useState(false);
  const [guestMode, setGuestMode] = useState(false);
  const [authBusy, setAuthBusy] = useState(false);
  // Notifications + permissions (re-openable forever, never suppressed)
  const [showNotifPrompt, setShowNotifPrompt] = useState(false);
  const [permOpen, setPermOpen] = useState(false);
  const [permStatus, setPermStatus] = useState<{ camera: PermState; microphone: PermState; notifications: PermState }>({ camera: "unknown", microphone: "unknown", notifications: "unknown" });
  const [canInstall, setCanInstall] = useState(false);
  const [installHelpOpen, setInstallHelpOpen] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [incomingNotif, setIncomingNotif] = useState<AppNotification | null>(null);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifList, setNotifList] = useState<AppNotification[]>([]);
  const [notifForm, setNotifForm] = useState({ target: "all", title: "", body: "", imageUrl: "", imageName: "" });
  const [notifTargetSearch, setNotifTargetSearch] = useState("");
  const [notifSuggestOpen, setNotifSuggestOpen] = useState(false);
  const [notifCount, setNotifCount] = useState("1");
  const [selectedNotifIds, setSelectedNotifIds] = useState<Set<string>>(new Set());
  const [brandIcon, setBrandIcon] = useState("/icons/icon-512.png");
  const [brandDraft, setBrandDraft] = useState<{ icon192: string; icon512: string; fileName: string } | null>(null);
  const [brandSaving, setBrandSaving] = useState(false);
  const [splashSetting, setSplashSetting] = useState<SplashSetting>({ mode: "logo", mediaType: "image", mediaUrl: "", durationSeconds: 2 });
  const [splashDraft, setSplashDraft] = useState<{ mode: "logo" | "full"; mediaType: "image" | "gif" | "video"; mediaUrl: string; durationSeconds: string; fileName: string }>({ mode: "logo", mediaType: "image", mediaUrl: "", durationSeconds: "2", fileName: "" });
  const [splashVisible, setSplashVisible] = useState(false);
  const [splashSaving, setSplashSaving] = useState(false);
  const [activeFaceMask, setActiveFaceMask] = useState<FaceMask | null>(null);
  const [faceMasks, setFaceMasks] = useState<FaceMask[]>([]);
  const [availableFaceMasks, setAvailableFaceMasks] = useState<FaceMask[]>([]);
  const [selectedFaceMaskId, setSelectedFaceMaskId] = useState("");
  const [maskPickerOpen, setMaskPickerOpen] = useState(false);
  const [maskForm, setMaskForm] = useState({ name: "", imageUrl: "", fileName: "" });
  const [supportLocked, setSupportLocked] = useState(false);
  const [supportMessages, setSupportMessages] = useState<SupportMessage[]>([]);
  const [supportText, setSupportText] = useState("");
  const [supportImage, setSupportImage] = useState<{ data: string; name: string } | null>(null);
  const [supportSending, setSupportSending] = useState(false);
  const [supportConversations, setSupportConversations] = useState<SupportConversation[]>([]);
  const [selectedSupportId, setSelectedSupportId] = useState("");
  const [adminReplyText, setAdminReplyText] = useState("");
  const [adminReplyImage, setAdminReplyImage] = useState<{ data: string; name: string } | null>(null);

  const rawStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioTrackRef = useRef<MediaStreamTrack | null>(null);
  const processedStreamRef = useRef<MediaStream | null>(null);
  const blurRigRef = useRef<BlurRig | null>(null);
  const trackedFacesRef = useRef<TrackedFace[]>([]);
  const blurOnRef = useRef(false);
  const selfHiddenRef = useRef(false);
  const localStreamRef = useRef<MediaStream | null>(null);
  const rtcRef = useRef<RTCPeerConnection | null>(null);
  const lastSignalId = useRef(0);
  const signalAbortRef = useRef<AbortController | null>(null);
  const searchAbortRef = useRef<AbortController | null>(null);
  const optimizerTierRef = useRef("");
  const installPromptRef = useRef<BeforeInstallPromptEvent | null>(null);
  const knownNotifIdsRef = useRef<Set<string>>(new Set());
  const notifPrimedRef = useRef(false);
  const endCallRef = useRef<((silent?: boolean) => Promise<void>) | null>(null);
  const pendingCandidates = useRef<RTCIceCandidateInit[]>([]);
  const callStateRef = useRef<CallState>("idle");
  const activeSessionRef = useRef("");
  const chatScrollRef = useRef<HTMLDivElement>(null);
  const chatNearBottomRef = useRef(true);
  const supportScrollRef = useRef<HTMLDivElement>(null);
  const adminSupportScrollRef = useRef<HTMLDivElement>(null);
  const adFileRef = useRef<HTMLInputElement>(null);
  const notifImageRef = useRef<HTMLInputElement>(null);
  const maskFileRef = useRef<HTMLInputElement>(null);
  const supportFileRef = useRef<HTMLInputElement>(null);
  const adminSupportFileRef = useRef<HTMLInputElement>(null);
  const brandFileRef = useRef<HTMLInputElement>(null);
  const splashFileRef = useRef<HTMLInputElement>(null);
  const splashTimerRef = useRef<number | null>(null);
  const faceEngineRef = useRef<FaceEngine | null>(null);
  const faceEnginePromiseRef = useRef<Promise<FaceEngine> | null>(null);
  const dataChannelRef = useRef<RTCDataChannel | null>(null);
  const isInitiatorRef = useRef(false);
  const reconnectAttemptsRef = useRef(0);
  const reconnectTimerRef = useRef<number | null>(null);
  const reconnectingRef = useRef(false);
  const statsRef = useRef<{ lastTs: number; lastBytes: number; targetKbps: number; lastApply: number; loss: number; jitter: number }>({ lastTs: 0, lastBytes: 0, targetKbps: 1200, lastApply: 0, loss: 0, jitter: 0 });
  const maskAssetRef = useRef<MaskAsset | null>(null);
  const maskAssetsRef = useRef<Map<string, MaskAsset>>(new Map());
  const selectedFaceMaskIdRef = useRef("");

  const isAdmin = profile?.email?.toLowerCase() === ADMIN_EMAIL;
  const lockRemaining = formatLock(profile?.profileLockedUntil);
  const profileComplete = Boolean(profile?.name && profile?.email && profile?.dob && profile?.gender);

  useEffect(() => { callStateRef.current = callState; }, [callState]);
  useEffect(() => { activeSessionRef.current = sessionId; }, [sessionId]);
  useEffect(() => { localStreamRef.current = localStream; }, [localStream]);
  useEffect(() => { if (chatNearBottomRef.current && chatScrollRef.current) chatScrollRef.current.scrollTo({ top: chatScrollRef.current.scrollHeight, behavior: "smooth" }); }, [messages]);
  useEffect(() => { if (tab === "support") supportScrollRef.current?.scrollTo({ top: supportScrollRef.current.scrollHeight, behavior: "smooth" }); }, [supportMessages, tab]);
  useEffect(() => { if (adminSection === "messages") adminSupportScrollRef.current?.scrollTo({ top: adminSupportScrollRef.current.scrollHeight, behavior: "smooth" }); }, [adminSection, selectedSupportId, supportConversations]);
  useEffect(() => { if (!toast) return; const timer = window.setTimeout(() => setToast(""), 4200); return () => window.clearTimeout(timer); }, [toast]);
  useEffect(() => { if ("serviceWorker" in navigator) void navigator.serviceWorker.register("/sw.js", { updateViaCache: "none" }).catch(() => undefined); }, []);
  useEffect(() => {
    const onVis = () => setPageVisible(!document.hidden);
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);
  useEffect(() => {
    const updateOnline = () => setIsOnline(navigator.onLine);
    updateOnline();
    window.addEventListener("online", updateOnline);
    window.addEventListener("offline", updateOnline);
    return () => { window.removeEventListener("online", updateOnline); window.removeEventListener("offline", updateOnline); };
  }, []);
  useEffect(() => { if (!connectAnim) return; const t = window.setTimeout(() => setConnectAnim(null), 3000); return () => window.clearTimeout(t); }, [connectAnim]);

  const loadProfile = useCallback(async (id: string) => {
    const response = await fetch(`/api/profile?userId=${encodeURIComponent(id)}`, { cache: "no-store" });
    const data = await response.json() as { profile: Profile | null };
    if (data.profile) {
      setProfile(data.profile);
      setProfileForm({ name: data.profile.name, email: data.profile.email, dob: data.profile.dob, gender: data.profile.gender });
    }
  }, []);

  const loadAds = useCallback(async (id = "") => {
    const response = await fetch(`/api/ads${id ? `?userId=${encodeURIComponent(id)}` : ""}`, { cache: "no-store" });
    if (!response.ok) return;
    const data = await response.json() as { ads: Advertisement[] };
    setAds(data.ads.filter((item) => item.active));
    setActiveAd(0);
  }, []);

  const loadBrand = useCallback(async () => {
    try {
      const response = await fetch("/api/brand", { cache: "no-store" });
      if (!response.ok) return;
      const data = await response.json() as { icon?: string; splash?: SplashSetting };
      if (data.icon) setBrandIcon(data.icon);
      if (data.splash) {
        setSplashSetting(data.splash);
        setSplashDraft({
          mode: data.splash.mode,
          mediaType: data.splash.mediaType,
          mediaUrl: data.splash.mediaUrl,
          durationSeconds: String(data.splash.durationSeconds || 2),
          fileName: "",
        });
        if (!window.sessionStorage.getItem("lumina-splash-seen")) {
          window.sessionStorage.setItem("lumina-splash-seen", "1");
          setSplashVisible(true);
          if (splashTimerRef.current) window.clearTimeout(splashTimerRef.current);
          splashTimerRef.current = window.setTimeout(() => setSplashVisible(false), Math.min(data.splash.mode === "logo" ? 10 : 8, Math.max(1, data.splash.durationSeconds || 2)) * 1000);
        }
      }
    } catch { /* default Lumina icon remains */ }
  }, []);

  useEffect(() => { void loadBrand(); }, [loadBrand]);
  useEffect(() => () => { if (splashTimerRef.current) window.clearTimeout(splashTimerRef.current); }, []);

  // ---- Permissions center: always re-openable, never permanently dismissed --
  const refreshPermissions = useCallback(async () => {
    const next: { camera: PermState; microphone: PermState; notifications: PermState } = {
      camera: "unknown", microphone: "unknown",
      notifications: "Notification" in window ? (Notification.permission === "default" ? "prompt" : Notification.permission as PermState) : "unsupported",
    };
    if (navigator.permissions?.query) {
      for (const name of ["camera", "microphone"] as const) {
        try {
          const status = await navigator.permissions.query({ name } as unknown as PermissionDescriptor);
          next[name] = status.state === "granted" ? "granted" : status.state === "denied" ? "denied" : "prompt";
        } catch { /* Permissions API partial support — attempt-based status below */ }
      }
    }
    if (rawStreamRef.current?.getVideoTracks().some((t) => t.readyState === "live")) next.camera = "granted";
    if (rawStreamRef.current?.getAudioTracks().some((t) => t.readyState === "live")) next.microphone = "granted";
    setPermStatus(next);
    return next;
  }, []);

  const openPermissions = useCallback(() => {
    setPermOpen(true);
    void refreshPermissions();
  }, [refreshPermissions]);

  const requestMediaPermission = async (kind: "camera" | "microphone") => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia(kind === "camera" ? { video: true } : { audio: true });
      stream.getTracks().forEach((track) => track.stop()); // permission granted; capture starts on demand
      await refreshPermissions();
      setToast(kind === "camera" ? "Camera allowed — you’re ready to be seen." : "Microphone allowed — you’re ready to be heard.");
    } catch {
      await refreshPermissions();
      setToast("Still blocked. Open your browser’s site settings → Permissions and allow it for Lumina, then tap Enable again.");
    }
  };

  const requestNotificationPermission = async () => {
    if (!("Notification" in window)) { setToast("Notifications are not supported in this browser."); return; }
    if (Notification.permission === "denied") {
      setToast("Notifications are blocked. Open your browser’s site settings → Permissions → Notifications and allow Lumina.");
      return;
    }
    try {
      const result = await Notification.requestPermission();
      await refreshPermissions();
      setToast(result === "granted" ? "Notifications on — you’ll never miss a moment." : "No problem — you can enable notifications here anytime.");
    } catch { setToast("Notifications are not available in this browser."); }
  };

  const getInstallPrompt = useCallback(() => {
    return installPromptRef.current || (window as unknown as { __luminaBIP?: BeforeInstallPromptEvent | null }).__luminaBIP || null;
  }, []);

  const installApp = useCallback(async () => {
    const standalone = window.matchMedia("(display-mode: standalone)").matches || (navigator as unknown as { standalone?: boolean }).standalone === true;
    if (standalone) { setIsInstalled(true); setToast("Lumina is already installed on this device."); return; }
    const prompt = getInstallPrompt();
    if (prompt) {
      await prompt.prompt().catch(() => undefined);
      const choice = await prompt.userChoice.catch(() => null);
      installPromptRef.current = null;
      (window as unknown as { __luminaBIP?: BeforeInstallPromptEvent | null }).__luminaBIP = null;
      setCanInstall(false);
      if (choice?.outcome === "accepted") { setIsInstalled(true); setToast("Lumina is installing — find it on your home screen."); }
      else setToast("No problem — the Install button stays here whenever you’re ready.");
      return;
    }
    // Safari/iOS and some browsers never fire an install prompt — the button
    // opens the exact guided steps for this device instead of failing.
    setInstallHelpOpen(true);
  }, [getInstallPrompt]);

  useEffect(() => {
    const onInstallPrompt = (event: Event) => {
      event.preventDefault();
      installPromptRef.current = event as BeforeInstallPromptEvent;
      setCanInstall(true);
    };
    // The prompt may have been captured before React mounted (layout script).
    if (getInstallPrompt()) setCanInstall(true);
    const standalone = window.matchMedia("(display-mode: standalone)").matches || (navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(standalone);
    const onInstalled = () => { setIsInstalled(true); setCanInstall(false); setInstallHelpOpen(false); setToast("Lumina installed — enjoy one-tap opening."); };
    window.addEventListener("beforeinstallprompt", onInstallPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => { window.removeEventListener("beforeinstallprompt", onInstallPrompt); window.removeEventListener("appinstalled", onInstalled); };
  }, [getInstallPrompt]);

  useEffect(() => {
    let id = window.localStorage.getItem("lumina-visitor-id");
    if (!id) { id = window.crypto.randomUUID(); window.localStorage.setItem("lumina-visitor-id", id); }
    setUserId(id);
    if (window.localStorage.getItem("lumina-account-id") === id) setSignedIn(true);
    void loadProfile(id);
    void loadAds(id);
    void refreshPermissions();
    // Permission invitation on every visit until granted — declining never hides it forever.
    if ("Notification" in window && Notification.permission !== "granted") {
      window.setTimeout(() => setShowNotifPrompt(true), 1600);
    }
  }, [loadAds, loadProfile, refreshPermissions]);

  // ---- Presence: green-dot online count -------------------------------------
  useEffect(() => {
    if (!userId) return;
    let alive = true;
    const heartbeat = async () => {
      try {
        const response = await fetch("/api/presence", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId }) });
        const data = await response.json() as { online: number; totalVisitors?: number };
        if (alive) {
          setOnlineCount(data.online || 0);
          setTotalVisitors(data.totalVisitors || 0);
        }
      } catch { /* keep last count */ }
    };
    void heartbeat();
    const timer = window.setInterval(() => { if (!document.hidden) void heartbeat(); }, 25000);
    const leave = () => { void fetch(`/api/presence?userId=${encodeURIComponent(userId)}`, { method: "DELETE", keepalive: true }).catch(() => undefined); };
    window.addEventListener("pagehide", leave);
    return () => { alive = false; window.clearInterval(timer); window.removeEventListener("pagehide", leave); };
  }, [userId, profile?.name]);

  // Rotate the 1:1 showcase endlessly.
  useEffect(() => {
    if (ads.length < 2 || !pageVisible) return;
    const timer = window.setInterval(() => setActiveAd((index) => (index + 1) % ads.length), 6000);
    return () => window.clearInterval(timer);
  }, [ads.length, pageVisible]);

  // ---- Notifications: 24h inbox + badge; only brand-new items ever pop up ----
  const markNotifRead = useCallback(async (id: string) => {
    if (!userId) return;
    setNotifList((current) => current.map((item) => (item.id === id ? { ...item, read: true } : item)));
    await fetch("/api/notifications", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, notificationId: id }) }).catch(() => undefined);
  }, [userId]);

  const loadNotifications = useCallback(async () => {
    if (!userId) return;
    try {
      const response = await fetch(`/api/notifications?userId=${encodeURIComponent(userId)}`, { cache: "no-store" });
      if (!response.ok) return;
      const data = await response.json() as { notifications: AppNotification[] };
      const cutoff = Date.now() - 24 * 60 * 60 * 1000;
      const fresh24 = data.notifications.filter((item) => new Date(item.createdAt).getTime() > cutoff);
      setNotifList(fresh24);
      // Prime on first load: everything already there is "old" and must never
      // pop up. Only items arriving after this moment can appear as a popup.
      if (!notifPrimedRef.current) {
        fresh24.forEach((item) => knownNotifIdsRef.current.add(item.id));
        notifPrimedRef.current = true;
        return;
      }
      const brandNew = fresh24.filter((item) => !item.read && !knownNotifIdsRef.current.has(item.id));
      fresh24.forEach((item) => knownNotifIdsRef.current.add(item.id));
      if (!brandNew.length) return;
      const latest = brandNew[0];
      setIncomingNotif(latest);
      if ("Notification" in window && Notification.permission === "granted") {
        // Show every newly arrived copy separately in the device notification
        // bar. If admin typed 5 copies, the user receives 5 device alerts.
        try {
          const registration = await navigator.serviceWorker?.ready;
          const ordered = [...brandNew].reverse();
          for (const item of ordered) {
            const options: NotificationOptions & { badge?: string } = {
              body: item.body,
              icon: "/api/brand/icon?size=192",
              badge: "/api/brand/icon?size=192",
              tag: item.id,
            };
            if (registration) await registration.showNotification(item.title, options);
            else new Notification(item.title, options);
          }
        } catch { /* in-app banner covers it */ }
      }
    } catch { /* silent */ }
  }, [userId]);

  useEffect(() => {
    if (!userId) return;
    void loadNotifications();
    const timer = window.setInterval(() => { if (!document.hidden) void loadNotifications(); }, 30000);
    const onFocus = () => void loadNotifications();
    window.addEventListener("focus", onFocus);
    return () => { window.clearInterval(timer); window.removeEventListener("focus", onFocus); };
  }, [loadNotifications, userId]);

  const openNotifications = useCallback(async () => {
    setNotifOpen(true);
    void loadNotifications();
    if (!userId) return;
    // Opening the panel clears the badge — everything is seen now.
    setNotifList((current) => current.map((item) => ({ ...item, read: true })));
    await fetch("/api/notifications", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, markAll: true }) }).catch(() => undefined);
  }, [loadNotifications, userId]);

  const unreadCount = notifList.filter((item) => !item.read).length;

  const answerNotifPrompt = async (allow: boolean) => {
    setShowNotifPrompt(false); // dismissed for this visit only — it returns next visit until granted
    if (!allow) return;
    if ("Notification" in window && Notification.permission === "denied") { openPermissions(); return; }
    await requestNotificationPermission();
  };

  // ---- Media + adaptive optimizer -------------------------------------------
  const captureSpec = () => {
    // Light-by-default capture: phones and modest devices start small and fast
    // (less encoder heat, less battery, less Wi-Fi); the optimizer steps up only
    // when the network proves it can stay smooth.
    const conn = (navigator as unknown as { connection?: { effectiveType?: string; saveData?: boolean } }).connection;
    const cores = navigator.hardwareConcurrency || 4;
    const memory = (navigator as unknown as { deviceMemory?: number }).deviceMemory || 4;
    const smallScreen = Math.min(window.screen.width, window.screen.height) < 820;
    if (conn?.saveData || conn?.effectiveType?.includes("2g")) return { width: 480, height: 270, fps: 15 };
    if (conn?.effectiveType?.includes("3g")) return { width: 640, height: 360, fps: 20 };
    if (smallScreen || cores <= 4 || memory <= 4) return { width: 640, height: 360, fps: 24 };
    return { width: 960, height: 540, fps: 30 };
  };

  const enhanceAudio = useCallback(async (stream: MediaStream) => {
    const micTrack = stream.getAudioTracks()[0];
    if (!micTrack) return stream;
    if (audioTrackRef.current?.readyState === "live") {
      return new MediaStream([...stream.getVideoTracks(), audioTrackRef.current]);
    }
    try {
      const AudioContextCtor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextCtor || !("audioWorklet" in AudioContext.prototype)) return stream;
      const context = audioContextRef.current || new AudioContextCtor({ latencyHint: "interactive" });
      audioContextRef.current = context;
      await context.audioWorklet.addModule("/audio-processor.js");
      await context.resume().catch(() => undefined);
      const source = context.createMediaStreamSource(new MediaStream([micTrack]));
      const processor = new AudioWorkletNode(context, "lumina-audio-processor", { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [1] });
      const destination = context.createMediaStreamDestination();
      source.connect(processor);
      processor.connect(destination);
      const enhanced = destination.stream.getAudioTracks()[0];
      if (!enhanced) return stream;
      try { enhanced.contentHint = "speech"; } catch { /* optional */ }
      audioTrackRef.current = enhanced;
      return new MediaStream([...stream.getVideoTracks(), enhanced]);
    } catch {
      return stream; // native AEC/NS/AGC still applies
    }
  }, []);

  const prepareMedia = useCallback(async () => {
    if (rawStreamRef.current?.getVideoTracks().some((track) => track.readyState === "live")) {
      return blurOnRef.current && processedStreamRef.current ? processedStreamRef.current : rawStreamRef.current;
    }
    try {
      setMediaError("");
      const spec = captureSpec();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing, width: { ideal: spec.width }, height: { ideal: spec.height }, frameRate: { ideal: spec.fps, max: 30 } },
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
      });
      stream.getVideoTracks().forEach((track) => { try { track.contentHint = "motion"; } catch { /* optional */ } });
      const enhancedStream = await enhanceAudio(stream);
      rawStreamRef.current = enhancedStream;
      void refreshPermissions();
      if (!blurOnRef.current) setLocalStream(enhancedStream);
      return enhancedStream;
    } catch (error) {
      const denied = error instanceof DOMException && (error.name === "NotAllowedError" || error.name === "SecurityError");
      setMediaError(denied
        ? "Camera/microphone is blocked. Review permissions — you can re-enable them anytime."
        : "Camera or microphone access is needed to start a video conversation.");
      if (denied) { void refreshPermissions(); setPermOpen(true); }
      throw new Error("Media permission denied");
    }
  }, [enhanceAudio, facing, refreshPermissions]);

  const analyzeMaskImage = useCallback((img: HTMLImageElement): MaskAsset => {
    const fallback: MaskAsset = {
      source: img.src,
      img,
      crop: { sx: 0, sy: 0, sw: img.naturalWidth || img.width, sh: img.naturalHeight || img.height },
      bounds: { x: 0, y: 0, w: 1, h: 1 },
      template: true,
      kind: "custom",
      coverage: 0,
    };
    try {
      const maxSide = 160;
      const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
      const w = Math.max(2, Math.round(img.naturalWidth * scale));
      const h = Math.max(2, Math.round(img.naturalHeight * scale));
      const canvas = document.createElement("canvas");
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      if (!ctx || !img.naturalWidth || !img.naturalHeight) return fallback;
      ctx.drawImage(img, 0, 0, w, h);
      const data = ctx.getImageData(0, 0, w, h).data;
      const alphaAt = (x: number, y: number) => data[(y * w + x) * 4 + 3];
      let minX = w, minY = h, maxX = -1, maxY = -1;
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        if (alphaAt(x, y) > 24) { minX = Math.min(minX, x); minY = Math.min(minY, y); maxX = Math.max(maxX, x); maxY = Math.max(maxY, y); }
      }
      if (maxX < 0) return fallback;
      // Flood-fill transparent pixels from the edges. Any transparent area not
      // reached is an enclosed hole (usually eye holes), used for alignment.
      const exterior = new Uint8Array(w * h);
      const stack: number[] = [];
      const pushIfOutside = (x: number, y: number) => {
        if (x < 0 || y < 0 || x >= w || y >= h) return;
        const index = y * w + x;
        if (!exterior[index] && alphaAt(x, y) < 24) { exterior[index] = 1; stack.push(index); }
      };
      for (let x = 0; x < w; x++) { pushIfOutside(x, 0); pushIfOutside(x, h - 1); }
      for (let y = 0; y < h; y++) { pushIfOutside(0, y); pushIfOutside(w - 1, y); }
      while (stack.length) {
        const index = stack.pop()!;
        const x = index % w, y = Math.floor(index / w);
        pushIfOutside(x + 1, y); pushIfOutside(x - 1, y); pushIfOutside(x, y + 1); pushIfOutside(x, y - 1);
      }
      const cropW = Math.max(1, maxX - minX + 1), cropH = Math.max(1, maxY - minY + 1);
      const holes = { left: { x: 0, y: 0, count: 0 }, right: { x: 0, y: 0, count: 0 } };
      for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
        const index = y * w + x;
        if (alphaAt(x, y) >= 24 || exterior[index]) continue;
        const relX = (x - minX) / cropW, relY = (y - minY) / cropH;
        if (relX < 0.06 || relX > 0.94 || relY < 0.12 || relY > 0.68) continue;
        const side = relX < 0.5 ? holes.left : holes.right;
        side.x += relX; side.y += relY; side.count += 1;
      }
      const eyes = holes.left.count > 12 && holes.right.count > 12
        ? {
          left: { x: holes.left.x / holes.left.count, y: holes.left.y / holes.left.count },
          right: { x: holes.right.x / holes.right.count, y: holes.right.y / holes.right.count },
        }
        : undefined;
      let opaque = 0, topOpaque = 0, bottomOpaque = 0, leftOpaque = 0, rightOpaque = 0;
      for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
        if (alphaAt(x, y) <= 24) continue;
        opaque += 1;
        if ((y - minY) / cropH < 0.5) topOpaque += 1; else bottomOpaque += 1;
        if ((x - minX) / cropW < 0.5) leftOpaque += 1; else rightOpaque += 1;
      }
      const halfArea = Math.max(1, cropW * cropH * 0.5);
      const topCoverage = topOpaque / halfArea;
      const bottomCoverage = bottomOpaque / halfArea;
      const leftCoverage = leftOpaque / halfArea;
      const rightCoverage = rightOpaque / halfArea;
      const coverage = opaque / Math.max(1, cropW * cropH);
      const kind: MaskKind = eyes
        ? "eyes"
        : coverage >= 0.52
          ? "full"
          : bottomCoverage >= 0.42 && topCoverage <= 0.28
            ? "lower"
            : topCoverage >= 0.42 && bottomCoverage <= 0.28
              ? "upper"
              : leftCoverage >= 0.42 && rightCoverage <= 0.28
                ? "left"
                : rightCoverage >= 0.42 && leftCoverage <= 0.28
                  ? "right"
                  : "custom";
      const sxScale = img.naturalWidth / w, syScale = img.naturalHeight / h;
      const bounds = { x: minX / w, y: minY / h, w: cropW / w, h: cropH / h };
      const eyesFull = eyes ? {
        left: { x: bounds.x + eyes.left.x * bounds.w, y: bounds.y + eyes.left.y * bounds.h },
        right: { x: bounds.x + eyes.right.x * bounds.w, y: bounds.y + eyes.right.y * bounds.h },
      } : undefined;
      return {
        source: img.src,
        img,
        crop: { sx: minX * sxScale, sy: minY * syScale, sw: cropW * sxScale, sh: cropH * syScale },
        bounds,
        // If the artwork already fills its PNG canvas, preserve that canvas as
        // a face template. If it is an isolated object, use its tight crop.
        template: bounds.w > 0.9 && bounds.h > 0.82,
        eyes,
        eyesFull,
        kind,
        coverage,
      };
    } catch {
      return fallback;
    }
  }, []);

  const prepareMaskAsset = useCallback(async (mask: FaceMask | null) => {
    if (!mask?.imageUrl) return null;
    const cached = maskAssetsRef.current.get(mask.id);
    if (cached?.source === mask.imageUrl) {
      if (selectedFaceMaskIdRef.current === mask.id) maskAssetRef.current = cached;
      return cached;
    }
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = mask.imageUrl;
    try { await img.decode(); } catch { /* onload path below */ }
    if (!img.complete || !img.naturalWidth) {
      await new Promise<void>((resolve) => { img.onload = () => resolve(); img.onerror = () => resolve(); });
    }
    if (!img.naturalWidth) return null;
    const asset = analyzeMaskImage(img);
    maskAssetsRef.current.set(mask.id, asset);
    if (selectedFaceMaskIdRef.current === mask.id) maskAssetRef.current = asset;
    return asset;
  }, [analyzeMaskImage]);

  const loadFaceMasks = useCallback(async (forAdmin = false) => {
    try {
      const response = await fetch(`/api/masks${userId ? `?userId=${encodeURIComponent(userId)}` : ""}`, { cache: "no-store" });
      if (!response.ok) return;
      const data = await response.json() as { activeMask: FaceMask | null; masks?: FaceMask[]; availableMasks?: FaceMask[] };
      const available = data.availableMasks || (forAdmin ? (data.masks || []).filter((mask) => mask.active) : data.masks || []);
      setAvailableFaceMasks(available);
      setActiveFaceMask(available.find((mask) => mask.id === selectedFaceMaskIdRef.current) || data.activeMask || available[0] || null);
      if (forAdmin) setFaceMasks(data.masks || []);
      // Preload only the first few; every other mask loads on tap so an
      // unlimited admin library stays light on phones and Wi-Fi.
      available.slice(0, 3).forEach((mask) => void prepareMaskAsset(mask));
    } catch { /* built-in strong face concealment remains available */ }
  }, [prepareMaskAsset, userId]);

  useEffect(() => { if (userId) void loadFaceMasks(isAdmin); }, [isAdmin, loadFaceMasks, userId]);

  const loadFaceEngine = useCallback(async (): Promise<FaceEngine> => {
    if (faceEngineRef.current) return faceEngineRef.current;
    if (faceEnginePromiseRef.current) return faceEnginePromiseRef.current;
    setFaceEngineStatus("loading");

    faceEnginePromiseRef.current = (async () => {
      // Primary: MediaPipe FaceLandmarker (468 landmarks, local model/WASM).
      // It gives the exact face oval + eye/nose/mouth/chin anchors needed for
      // a worn-on mask fit at any distance or angle. BlazeFace is fallback.
      try {
        const vision = await import("@mediapipe/tasks-vision");
        const fileset = await vision.FilesetResolver.forVisionTasks("/mediapipe/wasm");
        const OVAL = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109];
        const avg = (points: { x: number; y: number }[]) => ({
          x: points.reduce((sum, point) => sum + point.x, 0) / Math.max(1, points.length),
          y: points.reduce((sum, point) => sum + point.y, 0) / Math.max(1, points.length),
        });

        try {
          const createLandmarker = (delegate: "GPU" | "CPU") => vision.FaceLandmarker.createFromOptions(fileset, {
            baseOptions: { modelAssetPath: "/models/face_landmarker.task", delegate },
            runningMode: "VIDEO",
            numFaces: 8,
            minFaceDetectionConfidence: 0.45,
            minFacePresenceConfidence: 0.45,
            minTrackingConfidence: 0.45,
            outputFaceBlendshapes: false,
            outputFacialTransformationMatrixes: true,
          });
          let landmarker: Awaited<ReturnType<typeof createLandmarker>> | null = null;
          let cpuMode = false;
          try { landmarker = await createLandmarker("GPU"); } catch { landmarker = await createLandmarker("CPU"); cpuMode = true; }
          const landmarkerEngine: FaceEngine = {
            kind: "mediapipe",
            detect: async (video, timestamp) => {
              if (!landmarker || video.videoWidth < 2 || video.videoHeight < 2) return [];
              let result: ReturnType<typeof landmarker.detectForVideo>;
              try {
                result = landmarker.detectForVideo(video, Math.max(1, Math.round(timestamp)));
              } catch (error) {
                if (cpuMode) throw error;
                cpuMode = true;
                landmarker = await createLandmarker("CPU");
                result = landmarker.detectForVideo(video, Math.max(2, Math.round(timestamp) + 1));
              }
              return (result.faceLandmarks || []).map((landmarks): NormalizedFace | null => {
                if (!landmarks?.length) return null;
                const at = (index: number) => landmarks[index] ? { x: landmarks[index].x, y: landmarks[index].y } : undefined;
                const eyeA = avg([at(33), at(133), at(160), at(159), at(158), at(145)].filter((point): point is FacePoint => Boolean(point)));
                const eyeB = avg([at(362), at(263), at(387), at(386), at(385), at(374)].filter((point): point is FacePoint => Boolean(point)));
                const eyes = eyeA && eyeB ? { left: eyeA.x <= eyeB.x ? eyeA : eyeB, right: eyeA.x <= eyeB.x ? eyeB : eyeA } : undefined;
                const polygon = OVAL.map((index) => at(index)).filter((point): point is FacePoint => Boolean(point));
                const xs = landmarks.map((point) => point.x), ys = landmarks.map((point) => point.y);
                const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
                return {
                  box: { x: minX, y: minY, w: Math.max(0.01, maxX - minX), h: Math.max(0.01, maxY - minY) },
                  eyes,
                  nose: at(1),
                  mouth: avg([at(13), at(14), at(78), at(308)].filter((point): point is FacePoint => Boolean(point))),
                  chin: at(152),
                  forehead: at(10),
                  polygon: polygon.length > 12 ? polygon : undefined,
                };
              }).filter((item): item is NormalizedFace => Boolean(item));
            },
          };
          faceEngineRef.current = landmarkerEngine;
          setFaceEngineStatus("ready");
          return landmarkerEngine;
        } catch { /* fall through to the lighter detector */ }

        const create = (delegate: "GPU" | "CPU") => vision.FaceDetector.createFromOptions(fileset, {
          baseOptions: { modelAssetPath: "/models/blaze_face_short_range.tflite", delegate },
          runningMode: "VIDEO",
          minDetectionConfidence: 0.45,
          minSuppressionThreshold: 0.3,
        });
        let detector: Awaited<ReturnType<typeof create>> | null = null;
        let gpuFailed = false;
        try { detector = await create("GPU"); } catch { detector = await create("CPU"); gpuFailed = true; }
        const engine: FaceEngine = {
          kind: "mediapipe",
          detect: async (video, timestamp) => {
            if (!detector || video.videoWidth < 2 || video.videoHeight < 2) return [];
            let result: ReturnType<typeof detector.detectForVideo>;
            try {
              result = detector.detectForVideo(video, Math.max(1, Math.round(timestamp)));
            } catch (error) {
              if (gpuFailed) throw error;
              gpuFailed = true;
              detector = await create("CPU");
              result = detector.detectForVideo(video, Math.max(2, Math.round(timestamp) + 1));
            }
            return (result.detections || []).map((detection): NormalizedFace | null => {
              const bb = detection.boundingBox;
              if (!bb) return null;
              const points = detection.keypoints || [];
              const point = (index: number) => points[index] ? { x: points[index].x, y: points[index].y } : undefined;
              const p0 = point(0), p1 = point(1);
              const eyes = p0 && p1 ? { left: p0.x <= p1.x ? p0 : p1, right: p0.x <= p1.x ? p1 : p0 } : undefined;
              const box = {
                x: bb.originX / video.videoWidth,
                y: bb.originY / video.videoHeight,
                w: bb.width / video.videoWidth,
                h: bb.height / video.videoHeight,
              };
              return {
                box,
                eyes,
                nose: point(2),
                mouth: point(3),
                chin: { x: box.x + box.w / 2, y: box.y + box.h },
                forehead: { x: box.x + box.w / 2, y: box.y },
              };
            }).filter((item): item is NormalizedFace => Boolean(item));
          },
        };
        faceEngineRef.current = engine;
        setFaceEngineStatus("ready");
        return engine;
      } catch (mediaPipeError) {
        // Fallback: native Shape Detection where available.
        const NativeFaceDetector = (window as unknown as {
          FaceDetector?: new (options: object) => {
            detect: (source: HTMLCanvasElement | HTMLVideoElement) => Promise<{ boundingBox: DOMRectReadOnly; landmarks?: { type?: string; locations?: FacePoint[] }[] }[]>;
          };
        }).FaceDetector;
        if (!NativeFaceDetector) throw mediaPipeError;
        const detector = new NativeFaceDetector({ fastMode: true, maxDetectedFaces: 8 });
        const engine: FaceEngine = {
          kind: "native",
          detect: async (video) => {
            const faces = await detector.detect(video);
            const width = video.videoWidth || 1, height = video.videoHeight || 1;
            return faces.map((face) => {
              const eyeCenters = (face.landmarks || [])
                .filter((landmark) => landmark.type?.toLowerCase().includes("eye") && landmark.locations?.length)
                .map((landmark) => {
                  const locations = landmark.locations || [];
                  return {
                    x: locations.reduce((sum, item) => sum + item.x, 0) / locations.length / width,
                    y: locations.reduce((sum, item) => sum + item.y, 0) / locations.length / height,
                  };
                }).sort((a, b) => a.x - b.x);
              return {
                box: { x: face.boundingBox.x / width, y: face.boundingBox.y / height, w: face.boundingBox.width / width, h: face.boundingBox.height / height },
                eyes: eyeCenters.length >= 2 ? { left: eyeCenters[0], right: eyeCenters[eyeCenters.length - 1] } : undefined,
              };
            });
          },
        };
        faceEngineRef.current = engine;
        setFaceEngineStatus("ready");
        return engine;
      }
    })().catch((error) => {
      faceEnginePromiseRef.current = null;
      setFaceEngineStatus("error");
      throw error;
    });

    return faceEnginePromiseRef.current;
  }, []);

  const stopBlurProcessing = useCallback((restoreRawPreview = true) => {
    const rig = blurRigRef.current;
    if (rig) cancelAnimationFrame(rig.raf);
    blurRigRef.current = null;
    processedStreamRef.current?.getVideoTracks().forEach((track) => track.stop());
    processedStreamRef.current = null;
    trackedFacesRef.current = [];
    if (restoreRawPreview && rawStreamRef.current) setLocalStream(rawStreamRef.current);
  }, []);

  const ensureProcessedStream = useCallback(async (raw: MediaStream) => {
    if (processedStreamRef.current?.getVideoTracks().some((track) => track.readyState === "live")) return processedStreamRef.current;
    const video = document.createElement("video");
    video.muted = true; video.playsInline = true; video.srcObject = raw;
    await video.play().catch(() => undefined);
    // Match the camera's real aspect (portrait stays portrait) at a light
    // processing size — faces are never cropped and the CPU stays cool.
    const vw = video.videoWidth || 640, vh = video.videoHeight || 360;
    const scaleDown = Math.min(1, 480 / Math.max(vw, vh));
    const W = Math.max(2, Math.round((vw * scaleDown) / 2) * 2);
    const H = Math.max(2, Math.round((vh * scaleDown) / 2) * 2);
    const canvas = document.createElement("canvas"); canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return raw;
    const temp = document.createElement("canvas"); temp.width = W; temp.height = H;
    const tempCtx = temp.getContext("2d", { alpha: false });
    if (!tempCtx) return raw;
    const small = document.createElement("canvas");
    const rig: BlurRig = { video, canvas, ctx, temp, tempCtx, small, raf: 0, lastDetect: 0, lastFrame: 0, detectorBusy: false, engine: faceEngineRef.current, engineLoading: false, blurFilterSupported: null };
    blurRigRef.current = rig;
    trackedFacesRef.current = [];

    const draw = () => {
      if (!blurOnRef.current || blurRigRef.current !== rig) return;
      rig.raf = requestAnimationFrame(draw);
      if (video.readyState < 2 || document.hidden) return;
      const now = performance.now();
      if (now - rig.lastFrame < 42) return; // ~24 fps keeps masks glued smoothly to faces
      rig.lastFrame = now;
      // The untouched frame goes out first — background, body and room stay
      // perfectly clear. Only tracked face ovals are pixel-shielded after.
      tempCtx.drawImage(video, 0, 0, W, H);
      ctx.drawImage(temp, 0, 0);
      if (now - rig.lastDetect > 160 && !rig.detectorBusy) {
        rig.lastDetect = now;
        if (!rig.engine && !rig.engineLoading) {
          rig.engineLoading = true;
          void loadFaceEngine()
            .then((engine) => { rig.engine = engine; })
            .catch(() => undefined)
            .finally(() => { rig.engineLoading = false; });
        }
        if (rig.engine) {
          rig.detectorBusy = true;
          rig.engine.detect(video, now).then((detections) => {
            const seenAt = performance.now();
            const tracked = trackedFacesRef.current;
            const used = new Set<number>();
            detections.forEach(({ box, eyes, nose, mouth, chin, polygon }) => {
              const center = { x: box.x + box.w / 2, y: box.y + box.h / 2 };
              let bestIndex = -1, bestDistance = 0.09;
              tracked.forEach((face, index) => {
                if (used.has(index)) return;
                const predicted = {
                  x: face.current.x + face.velocity.x * 0.08 + face.current.w / 2,
                  y: face.current.y + face.velocity.y * 0.08 + face.current.h / 2,
                };
                const distance = (predicted.x - center.x) ** 2 + (predicted.y - center.y) ** 2;
                if (distance < bestDistance) { bestDistance = distance; bestIndex = index; }
              });
              if (bestIndex >= 0) {
                const previous = tracked[bestIndex].target;
                tracked[bestIndex].velocity = {
                  x: (box.x - previous.x) * 0.65 + tracked[bestIndex].velocity.x * 0.35,
                  y: (box.y - previous.y) * 0.65 + tracked[bestIndex].velocity.y * 0.35,
                  w: (box.w - previous.w) * 0.5 + tracked[bestIndex].velocity.w * 0.5,
                  h: (box.h - previous.h) * 0.5 + tracked[bestIndex].velocity.h * 0.5,
                };
                tracked[bestIndex].target = box;
                tracked[bestIndex].eyesTarget = eyes || tracked[bestIndex].eyesTarget;
                tracked[bestIndex].noseTarget = nose || tracked[bestIndex].noseTarget;
                tracked[bestIndex].mouthTarget = mouth || tracked[bestIndex].mouthTarget;
                tracked[bestIndex].chinTarget = chin || tracked[bestIndex].chinTarget;
                tracked[bestIndex].polygonTarget = polygon || tracked[bestIndex].polygonTarget;
                tracked[bestIndex].lastSeen = seenAt;
                used.add(bestIndex);
              } else if (tracked.length < 8) {
                tracked.push({
                  current: { ...box }, target: box, velocity: { x: 0, y: 0, w: 0, h: 0 }, lastSeen: seenAt,
                  eyesCurrent: eyes, eyesTarget: eyes, noseCurrent: nose, noseTarget: nose,
                  mouthCurrent: mouth, mouthTarget: mouth, chinCurrent: chin, chinTarget: chin,
                  polygonCurrent: polygon, polygonTarget: polygon,
                });
                used.add(tracked.length - 1);
              }
            });
            trackedFacesRef.current = tracked.filter((face) => seenAt - face.lastSeen < 1100).slice(0, 8);
          }).catch(() => undefined).finally(() => { rig.detectorBusy = false; });
        }
      }
      const affineFromTriangles = (
        s0: FacePoint, s1: FacePoint, s2: FacePoint,
        d0: FacePoint, d1: FacePoint, d2: FacePoint,
      ) => {
        const ux = s1.x - s0.x, uy = s1.y - s0.y;
        const vx = s2.x - s0.x, vy = s2.y - s0.y;
        const denom = ux * vy - uy * vx;
        if (Math.abs(denom) < 0.000001) return null;
        const Ux = d1.x - d0.x, Uy = d1.y - d0.y;
        const Vx = d2.x - d0.x, Vy = d2.y - d0.y;
        const a = (Ux * vy - Vx * uy) / denom;
        const c = (-Ux * vx + Vx * ux) / denom;
        const b = (Uy * vy - Vy * uy) / denom;
        const d = (-Uy * vx + Vy * ux) / denom;
        const e = d0.x - a * s0.x - c * s0.y;
        const f = d0.y - b * s0.x - d * s0.y;
        return { a, b, c, d, e, f };
      };
      const drawMaskAffine = (
        mask: MaskAsset,
        source: [FacePoint, FacePoint, FacePoint],
        dest: [FacePoint, FacePoint, FacePoint],
      ) => {
        const matrix = affineFromTriangles(source[0], source[1], source[2], dest[0], dest[1], dest[2]);
        if (!matrix) return false;
        ctx.setTransform(matrix.a, matrix.b, matrix.c, matrix.d, matrix.e, matrix.f);
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = "high";
        ctx.drawImage(mask.img, 0, 0);
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        return true;
      };

      // Glide each tracked oval toward its face; expired tracks disappear so
      // nothing except a real, current face is ever concealed.
      trackedFacesRef.current = trackedFacesRef.current.filter((face) => now - face.lastSeen < 1100);
      for (const face of trackedFacesRef.current) {
        const c = face.current, t = face.target, v = face.velocity;
        // Predictive follow compensates for detector latency: the mask/blur is
        // drawn where the face is now, not where it was ~150 ms ago.
        const predicted = { x: t.x + v.x * 0.42, y: t.y + v.y * 0.42, w: t.w + v.w * 0.25, h: t.h + v.h * 0.25 };
        c.x += (predicted.x - c.x) * 0.68; c.y += (predicted.y - c.y) * 0.68; c.w += (predicted.w - c.w) * 0.6; c.h += (predicted.h - c.h) * 0.6;
        if (face.eyesTarget) {
          if (!face.eyesCurrent) face.eyesCurrent = { left: { ...face.eyesTarget.left }, right: { ...face.eyesTarget.right } };
          (["left", "right"] as const).forEach((side) => {
            face.eyesCurrent![side].x += (face.eyesTarget![side].x - face.eyesCurrent![side].x) * 0.68;
            face.eyesCurrent![side].y += (face.eyesTarget![side].y - face.eyesCurrent![side].y) * 0.68;
          });
        }
        const smoothPoint = (current: FacePoint | undefined, target: FacePoint | undefined) => {
          if (!target) return current;
          if (!current) return { ...target };
          current.x += (target.x - current.x) * 0.68;
          current.y += (target.y - current.y) * 0.68;
          return current;
        };
        face.noseCurrent = smoothPoint(face.noseCurrent, face.noseTarget);
        face.mouthCurrent = smoothPoint(face.mouthCurrent, face.mouthTarget);
        face.chinCurrent = smoothPoint(face.chinCurrent, face.chinTarget);
        if (face.polygonTarget?.length) {
          if (!face.polygonCurrent || face.polygonCurrent.length !== face.polygonTarget.length) {
            face.polygonCurrent = face.polygonTarget.map((point) => ({ ...point }));
          } else {
            face.polygonCurrent = face.polygonCurrent.map((point, index) => {
              const target = face.polygonTarget![index];
              point.x += (target.x - point.x) * 0.62;
              point.y += (target.y - point.y) * 0.62;
              return point;
            });
          }
        }
        const centerX = (c.x + c.w / 2) * W, centerY = (c.y + c.h / 2) * H;
        const radiusX = Math.max(4, c.w * W * 0.54), radiusY = Math.max(4, c.h * H * 0.56);
        const x = Math.max(0, centerX - radiusX), y = Math.max(0, centerY - radiusY);
        const w = Math.min(W - x, radiusX * 2), h = Math.min(H - y, radiusY * 2);
        if (w < 8 || h < 8) continue;
        const selectedMaskId = selectedFaceMaskIdRef.current;
        const mask = selectedMaskId ? maskAssetsRef.current.get(selectedMaskId) || maskAssetRef.current : null;

        if (!mask) {
          // Built-in smooth face blur: clip to the actual FaceLandmarker oval
          // (or a tight fallback oval), then apply only Gaussian-style blur.
          // No pixel/mosaic boxes and no blur outside the face.
          ctx.save();
          ctx.beginPath();
          if (face.polygonCurrent?.length && face.polygonCurrent.length > 12) {
            face.polygonCurrent.forEach((point, index) => {
              const px = point.x * W, py = point.y * H;
              if (index === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
            });
            ctx.closePath();
          } else {
            ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, Math.PI * 2);
          }
          ctx.clip();
          if (rig.blurFilterSupported === null) {
            try {
              ctx.filter = "blur(2px)";
              rig.blurFilterSupported = ctx.filter.includes("blur");
            } catch { rig.blurFilterSupported = false; }
            ctx.filter = "none";
          }
          if (rig.blurFilterSupported) {
            const blurPx = Math.max(12, Math.min(30, c.w * W * 0.11));
            try {
              ctx.filter = `blur(${blurPx}px)`;
              ctx.drawImage(temp, 0, 0, W, H);
              ctx.drawImage(temp, 0, 0, W, H);
            } catch { rig.blurFilterSupported = false; }
            ctx.filter = "none";
          }
          if (!rig.blurFilterSupported) {
            // Smooth fallback for browsers without CanvasRenderingContext2D
            // filter: downscale then upscale with interpolation (not mosaic).
            small.width = Math.max(14, Math.round(w / 9));
            small.height = Math.max(18, Math.round(h / 9));
            const sctx = small.getContext("2d");
            if (sctx) {
              sctx.imageSmoothingEnabled = true;
              sctx.imageSmoothingQuality = "high";
              sctx.drawImage(temp, x, y, w, h, 0, 0, small.width, small.height);
              ctx.imageSmoothingEnabled = true;
              ctx.imageSmoothingQuality = "high";
              ctx.drawImage(small, 0, 0, small.width, small.height, x, y, w, h);
              ctx.drawImage(small, 0, 0, small.width, small.height, x, y, w, h);
            }
          }
          ctx.fillStyle = "rgba(70, 45, 58, 0.12)";
          ctx.fillRect(x, y, w, h);
          ctx.restore();
          continue;
        }

        // PNG filter mode: draw only the PNG's own pixels. Transparent parts
        // (including detected eye holes and open half-mask areas) keep the
        // real face visible exactly where the admin designed it to show.
        const { img, crop, bounds, eyes: maskEyes, eyesFull, template, kind } = mask;
        const estimatedEyes: EyePair = {
          left: { x: c.x + c.w * 0.36, y: c.y + c.h * 0.42 },
          right: { x: c.x + c.w * 0.64, y: c.y + c.h * 0.42 },
        };
        const eyesForAlign = face.eyesCurrent || estimatedEyes;
        const faceCenter = { x: (c.x + c.w / 2) * W, y: (c.y + c.h / 2) * H };
        const faceAngle = Math.atan2(
          (eyesForAlign.right.y - eyesForAlign.left.y) * H,
          Math.max(1, (eyesForAlign.right.x - eyesForAlign.left.x) * W),
        );
        ctx.save();
        // A soft contact shadow makes the PNG sit on the face like a real
        // worn mask instead of looking like a floating sticker.
        ctx.shadowColor = "rgba(24, 8, 16, 0.28)";
        ctx.shadowBlur = Math.max(5, c.w * W * 0.045);
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = Math.max(1, c.h * H * 0.014);

        const destEyeL = { x: eyesForAlign.left.x * W, y: eyesForAlign.left.y * H };
        const destEyeR = { x: eyesForAlign.right.x * W, y: eyesForAlign.right.y * H };
        const destMouth = face.mouthCurrent
          ? { x: face.mouthCurrent.x * W, y: face.mouthCurrent.y * H }
          : { x: centerX, y: (c.y + c.h * 0.72) * H };
        const destChin = face.chinCurrent
          ? { x: face.chinCurrent.x * W, y: face.chinCurrent.y * H }
          : { x: centerX, y: (c.y + c.h) * H };
        const destNose = face.noseCurrent
          ? { x: face.noseCurrent.x * W, y: face.noseCurrent.y * H }
          : { x: centerX, y: (c.y + c.h * 0.55) * H };
        let affineDrawn = false;

        if (template) {
          const sourceW = img.naturalWidth || crop.sw, sourceH = img.naturalHeight || crop.sh;
          const sourceEyes = eyesFull || { left: { x: 0.38, y: 0.42 }, right: { x: 0.62, y: 0.42 } };
          affineDrawn = drawMaskAffine(mask, [
            { x: sourceEyes.left.x * sourceW, y: sourceEyes.left.y * sourceH },
            { x: sourceEyes.right.x * sourceW, y: sourceEyes.right.y * sourceH },
            { x: sourceW * 0.5, y: sourceH * 0.84 },
          ], [destEyeL, destEyeR, destChin]);
        } else {
          const toFull = (rel: FacePoint) => ({ x: crop.sx + rel.x * crop.sw, y: crop.sy + rel.y * crop.sh });
          const sourceEyes = maskEyes || (kind === "upper"
            ? { left: { x: 0.16, y: 0.88 }, right: { x: 0.84, y: 0.88 } }
            : kind === "lower"
              ? { left: { x: 0.16, y: 0.1 }, right: { x: 0.84, y: 0.1 } }
              : { left: { x: 0.2, y: 0.46 }, right: { x: 0.8, y: 0.46 } });
          const sourceThird = kind === "lower"
            ? { x: 0.5, y: 0.98 }
            : kind === "upper"
              ? { x: 0.5, y: 0.06 }
              : kind === "full"
                ? { x: 0.5, y: 0.94 }
                : { x: (sourceEyes.left.x + sourceEyes.right.x) / 2, y: Math.min(0.98, sourceEyes.left.y + Math.abs(sourceEyes.right.x - sourceEyes.left.x) * 1.35) };
          const destThird = kind === "lower" ? destChin : kind === "upper" ? { x: centerX, y: c.y * H } : kind === "full" ? destChin : destMouth;
          const destSource: [FacePoint, FacePoint, FacePoint] = kind === "lower"
            ? [
              { x: destNose.x - c.w * W * 0.42, y: destNose.y },
              { x: destNose.x + c.w * W * 0.42, y: destNose.y },
              destChin,
            ]
            : [destEyeL, destEyeR, destThird];
          affineDrawn = drawMaskAffine(mask, [toFull(sourceEyes.left), toFull(sourceEyes.right), toFull(sourceThird)], destSource);
        }
        if (affineDrawn) { ctx.restore(); continue; }

        if (template) {
          // Face-template PNG: preserve the admin's full canvas. Its own
          // transparent margins/half-face placement stay exactly as designed.
          const sourceW = img.naturalWidth || crop.sw, sourceH = img.naturalHeight || crop.sh;
          const sourceEyes = eyesFull;
          if (sourceEyes) {
            const sourceLeft = { x: sourceEyes.left.x * sourceW, y: sourceEyes.left.y * sourceH };
            const sourceRight = { x: sourceEyes.right.x * sourceW, y: sourceEyes.right.y * sourceH };
            const sourceMid = { x: (sourceLeft.x + sourceRight.x) / 2, y: (sourceLeft.y + sourceRight.y) / 2 };
            const sourceDist = Math.max(1, Math.hypot(sourceRight.x - sourceLeft.x, sourceRight.y - sourceLeft.y));
            const destLeft = { x: eyesForAlign.left.x * W, y: eyesForAlign.left.y * H };
            const destRight = { x: eyesForAlign.right.x * W, y: eyesForAlign.right.y * H };
            const destMid = { x: (destLeft.x + destRight.x) / 2, y: (destLeft.y + destRight.y) / 2 };
            const destDist = Math.max(1, Math.hypot(destRight.x - destLeft.x, destRight.y - destLeft.y));
            const scale = destDist / sourceDist;
            const sourceAngle = Math.atan2(sourceRight.y - sourceLeft.y, sourceRight.x - sourceLeft.x);
            ctx.translate(destMid.x, destMid.y);
            ctx.rotate(faceAngle - sourceAngle);
            ctx.scale(scale, scale);
            ctx.translate(-sourceMid.x, -sourceMid.y);
            ctx.drawImage(img, 0, 0, sourceW, sourceH, 0, 0, sourceW, sourceH);
          } else {
            const destW = c.w * W * 1.42, destH = c.h * H * 1.46;
            ctx.translate(faceCenter.x, faceCenter.y);
            ctx.rotate(faceAngle);
            ctx.drawImage(img, 0, 0, sourceW, sourceH, -destW / 2, -destH / 2, destW, destH);
          }
          ctx.restore();
          continue;
        }

        if (maskEyes) {
          const sourceLeft = { x: maskEyes.left.x * crop.sw, y: maskEyes.left.y * crop.sh };
          const sourceRight = { x: maskEyes.right.x * crop.sw, y: maskEyes.right.y * crop.sh };
          const sourceMid = { x: (sourceLeft.x + sourceRight.x) / 2, y: (sourceLeft.y + sourceRight.y) / 2 };
          const sourceDist = Math.max(1, Math.hypot(sourceRight.x - sourceLeft.x, sourceRight.y - sourceLeft.y));
          const destLeft = { x: eyesForAlign.left.x * W, y: eyesForAlign.left.y * H };
          const destRight = { x: eyesForAlign.right.x * W, y: eyesForAlign.right.y * H };
          const destMid = { x: (destLeft.x + destRight.x) / 2, y: (destLeft.y + destRight.y) / 2 };
          const destDist = Math.max(1, Math.hypot(destRight.x - destLeft.x, destRight.y - destLeft.y));
          const scale = destDist / sourceDist;
          const angle = faceAngle - Math.atan2(sourceRight.y - sourceLeft.y, sourceRight.x - sourceLeft.x);
          ctx.translate(destMid.x, destMid.y);
          ctx.rotate(Number.isFinite(angle) ? angle : 0);
          ctx.scale(scale, scale);
          ctx.translate(-sourceMid.x, -sourceMid.y);
          ctx.drawImage(img, crop.sx, crop.sy, crop.sw, crop.sh, 0, 0, crop.sw, crop.sh);
        } else {
          // Isolated PNG object: anchor its tight artwork to the real face
          // box and rotate with the eye line. Half masks attach to their half.
          const faceX = c.x * W, faceY = c.y * H, faceW = c.w * W, faceH = c.h * H;
          const aspect = Math.max(0.05, crop.sw / Math.max(1, crop.sh));
          let destW = faceW * 1.34;
          let destH = destW / aspect;
          if (kind === "full") {
            const coverScale = Math.max((faceW * 1.3) / crop.sw, (faceH * 1.24) / crop.sh);
            destW = crop.sw * coverScale;
            destH = crop.sh * coverScale;
          } else if (kind === "left" || kind === "right") {
            destH = faceH * 1.22;
            destW = destH * aspect;
          } else if (kind === "lower" || kind === "upper") {
            destW = faceW * 1.24;
            destH = destW / aspect;
          }
          let localX = -destW / 2;
          let localY = -destH / 2;
          if (kind === "lower") localY = faceH * 0.52 - destH;
          if (kind === "upper") localY = -faceH * 0.52;
          if (kind === "left") localX = -faceW * 0.52;
          if (kind === "right") localX = faceW * 0.52 - destW;
          ctx.translate(faceX + faceW / 2, faceY + faceH / 2);
          ctx.rotate(faceAngle);
          ctx.drawImage(img, crop.sx, crop.sy, crop.sw, crop.sh, localX, localY, destW, destH);
        }
        ctx.restore();
      }
    };
    draw();
    const canvasStream = canvas.captureStream(24);
    const combined = new MediaStream([...canvasStream.getVideoTracks(), ...raw.getAudioTracks()]);
    processedStreamRef.current = combined;
    setLocalStream(combined);
    return combined;
  }, []);

  const outgoingVideoTrack = useCallback(() => {
    if (blurOnRef.current && processedStreamRef.current?.getVideoTracks().some((t) => t.readyState === "live")) return processedStreamRef.current.getVideoTracks()[0];
    return rawStreamRef.current?.getVideoTracks()[0] || localStreamRef.current?.getVideoTracks()[0];
  }, []);

  const disableFaceEffect = useCallback(async (quiet = false) => {
    const raw = rawStreamRef.current;
    blurOnRef.current = false;
    setFaceBlur(false);
    selectedFaceMaskIdRef.current = "";
    setSelectedFaceMaskId("");
    setActiveFaceMask(null);
    maskAssetRef.current = null;
    setMaskPickerOpen(false);
    stopBlurProcessing(true);
    const sender = rtcRef.current?.getSenders().find((item) => item.track?.kind === "video");
    const rawTrack = raw?.getVideoTracks()[0];
    if (sender && rawTrack && !selfHiddenRef.current) await sender.replaceTrack(rawTrack).catch(() => undefined);
    if (!quiet) setToast("Face filter off — your real video is showing.");
  }, [stopBlurProcessing]);

  const enableFaceEffect = useCallback(async (maskId = "") => {
    const raw = rawStreamRef.current;
    if (!raw) { setToast("Start a call first, then choose a face filter."); return; }
    const selectedMask = maskId ? availableFaceMasks.find((mask) => mask.id === maskId) || null : null;
    if (maskId && !selectedMask) {
      await loadFaceMasks(false);
      setToast("That mask is no longer available. Choose another filter.");
      return;
    }
    selectedFaceMaskIdRef.current = maskId;
    setSelectedFaceMaskId(maskId);
    setActiveFaceMask(selectedMask);
    try {
      setFaceEngineStatus("loading");
      setToast("Loading pro face tracking…");
      const [, asset] = await Promise.all([
        loadFaceEngine(),
        selectedMask ? prepareMaskAsset(selectedMask) : Promise.resolve(null),
      ]);
      if (selectedMask && !asset) {
        setToast("That mask could not load, so Full Face Hide is being used.");
        selectedFaceMaskIdRef.current = ""; setSelectedFaceMaskId("");
      }
    } catch {
      selectedFaceMaskIdRef.current = "";
      setSelectedFaceMaskId("");
      setFaceEngineStatus("error");
      setToast("Face tracking could not load. Check connection once, then tap the filter again — Lumina will retry.");
      return;
    }
    if (!selectedMask) maskAssetRef.current = null;

    if (!blurOnRef.current) {
      blurOnRef.current = true;
      setFaceBlur(true);
      const processed = await ensureProcessedStream(raw);
      const track = processed.getVideoTracks()[0];
      const sender = rtcRef.current?.getSenders().find((item) => item.track?.kind === "video");
      if (sender && track && !selfHiddenRef.current) await sender.replaceTrack(track).catch(() => undefined);
    }
    setMaskPickerOpen(false);
    if (selectedMask) setToast(`${selectedMask.name} on — landmark tracking now follows every face.`);
    else setToast("Full Face Hide on — landmark tracking blurs only faces; everything else stays clear.");
  }, [availableFaceMasks, ensureProcessedStream, loadFaceEngine, loadFaceMasks, prepareMaskAsset]);

  const toggleFaceBlur = async () => {
    if (!rawStreamRef.current) { setToast("Start a call first, then blur your face."); return; }
    if (faceBlur && !selectedFaceMaskId) await disableFaceEffect();
    else await enableFaceEffect("");
  };

  const optimizeConnection = useCallback(async () => {
    const pc = rtcRef.current;
    if (!pc || pc.connectionState !== "connected") return;
    const state = statsRef.current;
    if (document.hidden && state.targetKbps <= 220) return;
    let rtt = 0, fps = 0, jitter = 0, fractionLost = 0, outboundBytes = 0;
    try {
      const stats = await pc.getStats();
      stats.forEach((report) => {
        const r = report as unknown as Record<string, unknown>;
        if (r.type === "candidate-pair" && (r.state === "succeeded" || r.nominated)) {
          rtt = Number(r.currentRoundTripTime || rtt || 0);
        }
        if (r.type === "remote-inbound-rtp" && (r.kind === "video" || r.mediaType === "video")) {
          jitter = Math.max(jitter, Number(r.jitter || 0));
          fractionLost = Math.max(fractionLost, Number(r.fractionLost || 0));
          rtt = rtt || Number(r.roundTripTime || 0);
        }
        if (r.type === "inbound-rtp" && (r.kind === "video" || r.mediaType === "video")) {
          fps = Number(r.framesPerSecond || fps || 0);
          jitter = Math.max(jitter, Number(r.jitter || 0));
          const lost = Number(r.packetsLost || 0), received = Number(r.packetsReceived || 0);
          if (lost + received > 0) fractionLost = Math.max(fractionLost, lost / (lost + received));
        }
        if (r.type === "outbound-rtp" && (r.kind === "video" || r.mediaType === "video")) {
          outboundBytes += Number(r.bytesSent || 0);
          fps = fps || Number(r.framesPerSecond || 0);
        }
      });
    } catch { return; }

    // Active Bandwidth Estimation: EWMA-smoothed jitter/loss reacts in
    // sub-second samples; encoder changes are hysteretic to avoid oscillation.
    state.jitter = state.jitter * 0.65 + jitter * 0.35;
    state.loss = state.loss * 0.65 + fractionLost * 0.35;
    const now = performance.now();
    let measuredKbps = 0;
    if (state.lastTs && outboundBytes >= state.lastBytes) {
      measuredKbps = ((outboundBytes - state.lastBytes) * 8) / Math.max(1, now - state.lastTs);
    }
    state.lastTs = now;
    state.lastBytes = outboundBytes;

    let target = state.targetKbps || 900;
    if (document.hidden) target = 200;
    else if (state.loss > 0.09 || state.jitter > 0.09 || rtt > 0.38) target *= 0.68;
    else if (state.loss > 0.035 || state.jitter > 0.045 || rtt > 0.22) target *= 0.84;
    else if (state.loss < 0.012 && state.jitter < 0.025 && rtt > 0 && rtt < 0.16) target *= 1.14;
    if (measuredKbps > 0 && measuredKbps < target * 0.72 && state.loss > 0.02) target = Math.max(180, measuredKbps * 1.08);
    target = Math.round(Math.min(document.hidden ? 220 : 1500, Math.max(document.hidden ? 160 : 180, target)));
    state.targetKbps = target;

    const label = document.hidden ? "Background saver" : target <= 420 ? "Low-data smooth" : target <= 820 ? "Balanced smooth" : "Ultra smooth";
    const shouldApply = now - state.lastApply > 1600;
    if (shouldApply && !selfHiddenRef.current) {
      const sender = pc.getSenders().find((item) => item.track?.kind === "video");
      if (sender) {
        try {
          const params = sender.getParameters();
          const existing = params.encodings?.length ? params.encodings : [{} as RTCRtpEncodingParameters];
          const layer = (index: number, ratio: number, scale: number, fpsCap: number): RTCRtpEncodingParameters => ({
            ...(existing[index] || existing[0] || {}),
            active: true,
            rid: existing[index]?.rid || (index === 0 ? "q" : index === 1 ? "h" : "f"),
            maxBitrate: Math.round(target * ratio) * 1000,
            maxFramerate: document.hidden ? 10 : fpsCap,
            scaleResolutionDownBy: existing[index]?.scaleResolutionDownBy || scale,
            priority: "high",
            networkPriority: "high",
          });
          params.degradationPreference = "maintain-framerate";
          params.encodings = existing.length >= 3
            ? [layer(0, 0.14, 4, 12), layer(1, 0.42, 2, 20), layer(2, 1, 1, 30)]
            : [{ ...(existing[0] || {}), active: true, maxBitrate: target * 1000, maxFramerate: document.hidden ? 10 : 30, priority: "high", networkPriority: "high" }];
          await sender.setParameters(params);
          state.lastApply = now;
          optimizerTierRef.current = label;
        } catch { /* browser adaptation remains active */ }
      }
    }
    const next = { rtt: Math.round(rtt * 1000), fps: Math.round(fps), kbps: target, label };
    setQuality((prev) => (prev.rtt === next.rtt && prev.fps === next.fps && prev.kbps === next.kbps && prev.label === next.label ? prev : next));
  }, []);

  useEffect(() => {
    if (callState !== "connected") return;
    optimizerTierRef.current = "";
    const kick = window.setTimeout(() => void optimizeConnection(), 1200);
    const timer = window.setInterval(() => void optimizeConnection(), 900);
    const onVis = () => void optimizeConnection(); // throttle down the moment we hide, restore on return
    document.addEventListener("visibilitychange", onVis);
    return () => { window.clearTimeout(kick); window.clearInterval(timer); document.removeEventListener("visibilitychange", onVis); };
  }, [callState, optimizeConnection]);

  // ---- WebRTC ----------------------------------------------------------------
  const sendSignal = useCallback(async (kind: string, payload: unknown, explicitSession?: string) => {
    const targetSession = explicitSession || activeSessionRef.current;
    if (!targetSession || !userId) return;
    await fetch("/api/signaling", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sessionId: targetSession, userId, kind, payload }) });
  }, [userId]);

  const sendData = useCallback((type: string, payload: Record<string, unknown> = {}) => {
    const channel = dataChannelRef.current;
    if (!channel || channel.readyState !== "open") return false;
    try {
      channel.send(JSON.stringify({ type, ...payload }));
      return true;
    } catch { return false; }
  }, []);

  const setupDataChannel = useCallback((channel: RTCDataChannel) => {
    dataChannelRef.current = channel;
    channel.onmessage = (event) => {
      try {
        const data = JSON.parse(String(event.data)) as Record<string, unknown>;
        if (data.type === "chat") {
          const item = data.item as { id?: string; text?: string; sentAt?: string } | undefined;
          if (item?.id && item.text) {
            setMessages((current) => current.some((message) => message.id === item.id)
              ? current
              : [...current.slice(-80), { id: item.id!, text: item.text!, mine: false, sentAt: item.sentAt || new Date().toISOString() }]);
          }
        } else if (data.type === "media-state") {
          if (typeof data.videoHidden === "boolean") setPeerVideoHidden(data.videoHidden);
        } else if (data.type === "ended") {
          setToast("Your partner ended the call.");
          void endCallRef.current?.(true);
        }
      } catch { /* ignore malformed peer messages */ }
    };
    channel.onclose = () => { if (dataChannelRef.current === channel) dataChannelRef.current = null; };
    channel.onerror = () => undefined;
  }, []);

  const scheduleReconnect = useCallback((connection: RTCPeerConnection, targetSession: string) => {
    if (reconnectingRef.current) return;
    if (reconnectAttemptsRef.current >= 3) {
      setConnectionNotice("Connection lost. Please end and start a new match.");
      setToast("Connection lost after 3 reconnection attempts.");
      return;
    }
    reconnectAttemptsRef.current += 1;
    const attempt = reconnectAttemptsRef.current;
    const delay = [800, 1600, 3200][attempt - 1] || 3200;
    reconnectingRef.current = true;
    setConnectionNotice(`Connection weak — reconnecting (${attempt}/3)…`);
    if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current);
    reconnectTimerRef.current = window.setTimeout(async () => {
      reconnectingRef.current = false;
      if (rtcRef.current !== connection || connection.connectionState === "connected" || connection.connectionState === "closed") return;
      try {
        connection.restartIce();
        if (isInitiatorRef.current) {
          const offer = await connection.createOffer({ iceRestart: true, offerToReceiveAudio: true, offerToReceiveVideo: true });
          await connection.setLocalDescription(offer);
          await sendSignal("offer", offer, targetSession);
        }
      } catch {
        scheduleReconnect(connection, targetSession);
      }
    }, delay);
  }, [sendSignal]);

  const createPeer = useCallback(async (targetSession: string, initiator: boolean, stream: MediaStream) => {
    if (rtcRef.current) return rtcRef.current;
    isInitiatorRef.current = initiator;
    reconnectAttemptsRef.current = 0;
    statsRef.current = { lastTs: 0, lastBytes: 0, targetKbps: 900, lastApply: 0, loss: 0, jitter: 0 };
    setConnectionNotice("");
    const connection = new RTCPeerConnection({ iceServers: ICE_SERVERS, iceCandidatePoolSize: 4, iceTransportPolicy: "all", bundlePolicy: "max-bundle", rtcpMuxPolicy: "require" });
    // Simulcast: independent low/medium/high layers let the receiving browser
    // and network keep motion moving instead of freezing on one fixed stream.
    stream.getTracks().forEach((track) => {
      if (track.kind === "video") {
        connection.addTransceiver(track, {
          direction: "sendrecv",
          streams: [stream],
          sendEncodings: [
            { rid: "q", active: true, scaleResolutionDownBy: 4, maxBitrate: 110_000, maxFramerate: 12 },
            { rid: "h", active: true, scaleResolutionDownBy: 2, maxBitrate: 340_000, maxFramerate: 20 },
            { rid: "f", active: true, scaleResolutionDownBy: 1, maxBitrate: 950_000, maxFramerate: 30 },
          ],
        });
      } else {
        connection.addTrack(track, stream);
      }
    });
    if (initiator) setupDataChannel(connection.createDataChannel("lumina-chat", { ordered: true }));
    connection.ondatachannel = (event) => setupDataChannel(event.channel);
    if (selfHiddenRef.current) {
      // Joined while "Hide me" is on: send nothing until they show themselves.
      const sender = connection.getSenders().find((item) => item.track?.kind === "video");
      if (sender) void sender.replaceTrack(null).catch(() => undefined);
    }
    try {
      const caps = RTCRtpSender.getCapabilities?.("video");
      const videoTransceiver = connection.getTransceivers().find((t) => t.sender.track?.kind === "video");
      if (caps && videoTransceiver) {
        // Prefer codecs commonly backed by phone hardware encoders, while
        // keeping RED/ULPFEC/RTX available for loss recovery over UDP.
        const score = (codec: RTCRtpCodec) => {
          const mime = codec.mimeType.toLowerCase();
          if (mime === "video/h264") return (codec.sdpFmtpLine?.includes("packetization-mode=1") ? 0 : 0.2);
          if (mime === "video/vp9") return 1;
          if (mime === "video/av1") return 2;
          if (mime === "video/vp8") return 3;
          if (mime === "video/red") return 4;
          if (mime === "video/ulpfec") return 5;
          if (mime === "video/rtx") return 6;
          return 8;
        };
        const preferred = [...caps.codecs].sort((a, b) => score(a) - score(b));
        if (preferred.length) videoTransceiver.setCodecPreferences(preferred);
      }
    } catch { /* defaults are fine */ }
    connection.ontrack = (event) => setRemoteStream(event.streams[0]);
    connection.onicecandidate = (event) => { if (event.candidate) void sendSignal("candidate", event.candidate.toJSON(), targetSession); };
    connection.onconnectionstatechange = () => {
      if (connection.connectionState === "connected") {
        reconnectAttemptsRef.current = 0;
        reconnectingRef.current = false;
        setConnectionNotice("");
        setToast("You’re live — say hello! ✨");
      }
      if (connection.connectionState === "failed") scheduleReconnect(connection, targetSession);
    };
    connection.oniceconnectionstatechange = () => {
      if (connection.iceConnectionState === "connected" || connection.iceConnectionState === "completed") {
        reconnectAttemptsRef.current = 0;
        reconnectingRef.current = false;
        setConnectionNotice("");
      }
      if (connection.iceConnectionState === "disconnected" || connection.iceConnectionState === "failed") {
        scheduleReconnect(connection, targetSession);
      }
    };
    rtcRef.current = connection;
    if (initiator) {
      const offer = await connection.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: true });
      await connection.setLocalDescription(offer);
      await sendSignal("offer", offer, targetSession);
    }
    return connection;
  }, [scheduleReconnect, sendSignal, setupDataChannel]);

  const activateMatch = useCallback(async (match: MatchResponse) => {
    if (!match.sessionId || activeSessionRef.current === match.sessionId) return;
    const matchedPeer = match.peer || { name: "New connection", gender: "", country: "" };
    setPeer(matchedPeer);
    setConnectAnim(matchedPeer); // 3-second gender-colour connecting card
    setSelfHidden(false); selfHiddenRef.current = false;
    setPeerHidden(false); setPeerVideoHidden(false);
    optimizerTierRef.current = "";
    setCallState("connected");
    setSessionId(match.sessionId);
    lastSignalId.current = 0;
    pendingCandidates.current = [];
    try {
      const stream = await prepareMedia();
      await createPeer(match.sessionId, Boolean(match.initiator), stream);
    } catch { setCallState("idle"); setSessionId(""); }
  }, [createPeer, prepareMedia]);

  const pollSignals = useCallback(async (abortSignal?: AbortSignal, wait = false) => {
    const currentSession = activeSessionRef.current;
    if (!currentSession || !userId) return false;
    const response = await fetch(`/api/signaling?sessionId=${encodeURIComponent(currentSession)}&userId=${encodeURIComponent(userId)}&after=${lastSignalId.current}${wait ? "&wait=1" : ""}`, { cache: "no-store", signal: abortSignal });
    if (!response.ok) return false;
    const data = await response.json() as { signals: { id: number; kind: string; payload: unknown; createdAt: string }[] };
    for (const signal of data.signals) {
      lastSignalId.current = Math.max(lastSignalId.current, signal.id);
      if (signal.kind === "offer") {
        const stream = await prepareMedia();
        const connection = await createPeer(currentSession, false, stream);
        await connection.setRemoteDescription(signal.payload as RTCSessionDescriptionInit);
        for (const candidate of pendingCandidates.current.splice(0)) await connection.addIceCandidate(candidate);
        const answer = await connection.createAnswer();
        await connection.setLocalDescription(answer);
        await sendSignal("answer", answer, currentSession);
      } else if (signal.kind === "answer" && rtcRef.current) {
        await rtcRef.current.setRemoteDescription(signal.payload as RTCSessionDescriptionInit);
        for (const candidate of pendingCandidates.current.splice(0)) await rtcRef.current.addIceCandidate(candidate);
      } else if (signal.kind === "candidate") {
        const candidate = signal.payload as RTCIceCandidateInit;
        if (rtcRef.current?.remoteDescription) await rtcRef.current.addIceCandidate(candidate);
        else pendingCandidates.current.push(candidate);
      } else if (signal.kind === "chat") {
        const item = signal.payload as { id?: string; text?: string; sentAt?: string };
        const messageText = item.text;
        if (messageText) setMessages((current) => [...current.slice(-80), { id: item.id || `${signal.id}`, text: messageText, mine: false, sentAt: item.sentAt || signal.createdAt }]);
      } else if (signal.kind === "media-state") {
        const state = signal.payload as { videoHidden?: boolean };
        if (typeof state.videoHidden === "boolean") setPeerVideoHidden(state.videoHidden);
      } else if (signal.kind === "ended") {
        setToast("Your partner ended the call.");
        void endCallRef.current?.(true);
        return true;
      }
    }
    return true;
  }, [createPeer, prepareMedia, sendSignal, userId]);

  // Long-poll loop: a single held request delivers offers/chat the moment they
  // land (~200 ms) instead of waking the radio every 500 ms.
  useEffect(() => {
    if (callState !== "connected" || !sessionId) return;
    let cancelled = false;
    const controller = new AbortController();
    signalAbortRef.current = controller;
    const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
    const loop = async () => {
      while (!cancelled) {
        try {
          const ok = await pollSignals(controller.signal, true);
          if (cancelled) break;
          if (!ok) { await delay(1200); continue; }
          if (document.hidden) await delay(2000); // background: breathe slowly
          else await delay(60);
        } catch {
          if (cancelled) break;
          await delay(900);
        }
      }
    };
    void loop();
    return () => { cancelled = true; controller.abort(); };
  }, [callState, pollSignals, sessionId]);

  const endCall = useCallback(async (silent = false) => {
    const currentSession = activeSessionRef.current;
    signalAbortRef.current?.abort();
    searchAbortRef.current?.abort();
    if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current);
    reconnectingRef.current = false;
    reconnectAttemptsRef.current = 0;
    if (currentSession && userId && !sendData("ended")) await sendSignal("ended", {}).catch(() => undefined);
    dataChannelRef.current?.close();
    dataChannelRef.current = null;
    setConnectionNotice("");
    if (userId) await fetch("/api/match", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "cancel" }) }).catch(() => undefined);
    rtcRef.current?.close();
    rtcRef.current = null;
    blurOnRef.current = false; setFaceBlur(false); stopBlurProcessing(true);
    selectedFaceMaskIdRef.current = ""; setSelectedFaceMaskId(""); setActiveFaceMask(null); maskAssetRef.current = null; setMaskPickerOpen(false);
    selfHiddenRef.current = false; setSelfHidden(false);
    setPeerHidden(false); setPeerVideoHidden(false);
    optimizerTierRef.current = "";
    setRemoteStream(null); setSessionId(""); setPeer(null); setConnectAnim(null); setMessages([]); setCallState("idle");
    if (!silent && currentSession) setToast("Call ended. Ready when you are.");
  }, [sendData, sendSignal, stopBlurProcessing, userId]);

  useEffect(() => { endCallRef.current = endCall; }, [endCall]);

  useEffect(() => () => {
    rtcRef.current?.close();
    cancelAnimationFrame(blurRigRef.current?.raf || 0);
    processedStreamRef.current?.getTracks().forEach((track) => track.stop());
    rawStreamRef.current?.getTracks().forEach((track) => track.stop());
  }, []);

  const startMatching = async () => {
    if (!profileComplete) { setTab("profile"); setToast("Set up your profile before connecting."); return; }
    try {
      await prepareMedia();
      setCallState("searching");
      const response = await fetch("/api/match", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "seek", preference }) });
      const match = await response.json() as MatchResponse;
      if (!response.ok) throw new Error(match.error || "Could not search right now.");
      if (match.matched) await activateMatch(match);
    } catch (error) {
      setCallState("idle");
      setToast(error instanceof Error ? error.message : "Could not start matching.");
    }
  };

  useEffect(() => {
    if (callState !== "searching" || !userId) return;
    let cancelled = false;
    const controller = new AbortController();
    searchAbortRef.current = controller;
    const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
    const loop = async () => {
      while (!cancelled) {
        try {
          if (document.hidden) { await delay(2000); continue; }
          const response = await fetch(`/api/match?userId=${encodeURIComponent(userId)}&wait=1`, { cache: "no-store", signal: controller.signal });
          if (!response.ok) { await delay(1200); continue; }
          const match = await response.json() as MatchResponse;
          if (match.matched) { await activateMatch(match); break; }
        } catch {
          if (cancelled) break;
          await delay(900);
        }
      }
    };
    void loop();
    return () => { cancelled = true; controller.abort(); };
  }, [activateMatch, callState, userId]);

  const flipCamera = async () => {
    const nextFacing = facing === "user" ? "environment" : "user";
    try {
      const spec = captureSpec();
      const replacement = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: nextFacing }, width: { ideal: spec.width }, height: { ideal: spec.height } }, audio: false });
      const nextTrack = replacement.getVideoTracks()[0];
      const raw = rawStreamRef.current;
      const previousTrack = raw?.getVideoTracks()[0];
      const updatedRaw = new MediaStream([nextTrack, ...(raw?.getAudioTracks() || [])]);
      rawStreamRef.current = updatedRaw;
      previousTrack?.stop();
      if (blurOnRef.current && blurRigRef.current) {
        blurRigRef.current.video.srcObject = updatedRaw;
        void blurRigRef.current.video.play().catch(() => undefined);
      } else {
        // While hidden from the partner the sender stays empty — flipping
        // only changes what *you* see in your own preview.
        if (!selfHiddenRef.current) {
          const sender = rtcRef.current?.getSenders().find((item) => item.track?.kind === "video");
          await sender?.replaceTrack(nextTrack);
        }
        setLocalStream(updatedRaw);
      }
      setFacing(nextFacing);
    } catch { setToast("Couldn’t flip the camera on this device."); }
  };

  const toggleMute = () => {
    const nextMuted = !muted;
    rawStreamRef.current?.getAudioTracks().forEach((track) => { track.enabled = !nextMuted; });
    setMuted(nextMuted);
  };

  // "Hide me" = privacy: your video stops reaching your partner (they see a
  // friendly notice), while your own preview keeps showing normally.
  // "Hide them" stays purely local — only your screen changes.
  const toggleSelfHidden = async () => {
    const next = !selfHidden;
    setSelfHidden(next);
    selfHiddenRef.current = next;
    if (!sendData("media-state", { videoHidden: next })) void sendSignal("media-state", { videoHidden: next });
    const sender = rtcRef.current?.getSenders().find((item) => item.track?.kind === "video");
    if (sender) {
      if (next) await sender.replaceTrack(null).catch(() => undefined);
      else {
        const track = outgoingVideoTrack();
        if (track) await sender.replaceTrack(track).catch(() => undefined);
        statsRef.current.lastApply = 0;
      }
    }
    setToast(next
      ? "You’re hidden from your partner — they see a notice. You can still see yourself."
      : "You’re visible to your partner again.");
  };

  const submitChat = async (event: FormEvent) => {
    event.preventDefault();
    const text = chatText.trim();
    if (!text || !sessionId) return;
    const item = { id: window.crypto.randomUUID(), text: text.slice(0, 500), sentAt: new Date().toISOString() };
    chatNearBottomRef.current = true;
    setMessages((current) => [...current.slice(-80), { ...item, mine: true }]);
    setChatText("");
    if (!sendData("chat", { item })) await sendSignal("chat", item);
  };

  // ---- Profile + auth ---------------------------------------------------------
  const saveProfile = async (event: FormEvent) => {
    event.preventDefault();
    setSaving(true);
    try {
      const response = await fetch("/api/profile", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, ...profileForm }) });
      const data = await response.json() as { profile?: Profile; error?: string };
      if (!response.ok) throw new Error(data.error || "Profile could not be saved.");
      if (data.profile) setProfile(data.profile);
      setToast("Profile saved — your details are protected for 24 hours.");
      setTab("connect");
    } catch (error) { setToast(error instanceof Error ? error.message : "Profile could not be saved."); }
    finally { setSaving(false); }
  };

  const applyAuth = (data: { account: AccountInfo; profile: Profile | null }) => {
    window.localStorage.setItem("lumina-visitor-id", data.account.id);
    window.localStorage.setItem("lumina-account-id", data.account.id);
    setUserId(data.account.id);
    setSignedIn(true); setGuestMode(false); setSupportLocked(false);
    if (data.profile) {
      setProfile(data.profile);
      setProfileForm({ name: data.profile.name, email: data.profile.email, dob: data.profile.dob, gender: data.profile.gender });
    }
    void loadAds(data.account.id);
  };

  const submitAuth = async (event: FormEvent) => {
    event.preventDefault();
    setAuthBusy(true);
    try {
      const payload = authMode === "signup"
        ? { action: "signup", ...profileForm, password }
        : { action: "signin", email: signInForm.email, password: signInForm.password };
      const response = await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data = await response.json() as { account?: AccountInfo; profile?: Profile | null; error?: string };
      if (!response.ok || !data.account) throw new Error(data.error || "Something went wrong.");
      applyAuth({ account: data.account, profile: data.profile || null });
      setPassword(""); setSignInForm({ email: "", password: "" });
      setToast(authMode === "signup" ? `Welcome to Lumina, ${data.account.name.split(" ")[0]}!` : `Welcome back, ${data.account.name.split(" ")[0]}!`);
      setTab("connect");
    } catch (error) { setToast(error instanceof Error ? error.message : "Authentication failed."); }
    finally { setAuthBusy(false); }
  };

  const signOut = () => {
    const guest = window.crypto.randomUUID();
    window.localStorage.setItem("lumina-visitor-id", guest);
    window.localStorage.removeItem("lumina-account-id");
    setUserId(guest); setSignedIn(false); setGuestMode(false); setSupportLocked(true); setSupportMessages([]);
    setProfile(null); setProfileForm({ name: "", email: "", dob: "", gender: "" });
    setTab("connect");
    setToast("Signed out. See you soon!");
  };

  // ---- Admin ------------------------------------------------------------------
  const loadAdmin = useCallback(async () => {
    if (!userId || !isAdmin) return;
    const query = adminEmail ? `&email=${encodeURIComponent(adminEmail)}` : "";
    const response = await fetch(`/api/admin?userId=${encodeURIComponent(userId)}${query}`, { cache: "no-store" });
    if (!response.ok) { setToast("Your administrator session could not be verified."); return; }
    setAdminData(await response.json() as AdminData);
  }, [adminEmail, isAdmin, userId]);

  useEffect(() => { if (tab === "admin" && isAdmin) void loadAdmin(); }, [isAdmin, loadAdmin, tab]);
  useEffect(() => {
    if (tab !== "admin" || !isAdmin) return;
    const timer = window.setInterval(() => { if (!document.hidden) void loadAdmin(); }, 20000);
    return () => window.clearInterval(timer);
  }, [isAdmin, loadAdmin, tab]);
  useEffect(() => { if (tab === "admin" && adminSection === "masks" && isAdmin) void loadFaceMasks(true); }, [adminSection, isAdmin, loadFaceMasks, tab]);

  const handleBrandFile = async (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) { setToast("Please choose an image for the brand logo."); return; }
    try {
      const url = URL.createObjectURL(file);
      const img = new Image();
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error("Logo image could not be read"));
        img.src = url;
      });
      const makeVariant = (size: number) => {
        const canvas = document.createElement("canvas");
        canvas.width = size; canvas.height = size;
        const ctx = canvas.getContext("2d");
        if (!ctx) throw new Error("Canvas unavailable");
        ctx.fillStyle = "#FC84BD";
        ctx.fillRect(0, 0, size, size);
        const scale = Math.min(size / Math.max(1, img.width), size / Math.max(1, img.height));
        const width = Math.max(1, Math.round(img.width * scale));
        const height = Math.max(1, Math.round(img.height * scale));
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = "high";
        ctx.drawImage(img, (size - width) / 2, (size - height) / 2, width, height);
        return canvas.toDataURL("image/png");
      };
      const icon512 = makeVariant(512);
      const icon192 = makeVariant(192);
      URL.revokeObjectURL(url);
      setBrandDraft({ icon192, icon512, fileName: file.name });
      setToast("Logo ready — one save updates the header, footer and PWA icon together.");
    } catch {
      setToast("That logo could not be loaded. Try a PNG or JPG image.");
    }
  };

  const saveBrand = async () => {
    if (!brandDraft || brandSaving) return;
    setBrandSaving(true);
    try {
      const response = await fetch("/api/brand", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, action: "save", icon192: brandDraft.icon192, icon512: brandDraft.icon512 }),
      });
      const data = await response.json() as { icon?: string; error?: string };
      if (!response.ok || !data.icon) throw new Error(data.error || "Brand icon could not be saved.");
      setBrandIcon(data.icon);
      setBrandDraft(null);
      void navigator.serviceWorker?.getRegistration().then((registration) => registration?.update()).catch(() => undefined);
      setToast("Brand logo saved everywhere. If Lumina is already installed, reinstall once so Android/iOS refreshes the home-screen icon.");
    } catch (error) {
      setToast(error instanceof Error ? error.message : "Brand icon could not be saved.");
    } finally { setBrandSaving(false); }
  };

  const resetBrand = async () => {
    if (!window.confirm("Reset to the original Lumina pink icon everywhere?")) return;
    setBrandSaving(true);
    try {
      const response = await fetch("/api/brand", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, action: "reset" }),
      });
      const data = await response.json() as { icon?: string; error?: string };
      if (!response.ok) throw new Error(data.error || "Brand icon could not be reset.");
      setBrandIcon(data.icon || "/icons/icon-512.png");
      setBrandDraft(null);
      await loadBrand();
      setToast("Original Lumina icon restored everywhere.");
    } catch (error) {
      setToast(error instanceof Error ? error.message : "Brand icon could not be reset.");
    } finally { setBrandSaving(false); }
  };

  const readFileAsDataUrl = (file: File) => new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("File could not be read"));
    reader.readAsDataURL(file);
  });

  const handleSplashFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const isVideo = file.type.startsWith("video/");
      const isGif = file.type === "image/gif";
      if (!isVideo && !file.type.startsWith("image/")) { setToast("Choose an image, GIF, or video for the splash screen."); return; }
      if (isVideo && file.size > 24_000_000) { setToast("Splash video is too large — please keep it under 24 MB."); return; }
      if (!isVideo && file.size > 14_000_000) { setToast("Splash image/GIF is too large — please keep it under 14 MB."); return; }
      const mediaUrl = isVideo || isGif ? await readFileAsDataUrl(file) : await compressImage(file, 1440);
      setSplashDraft((current) => ({
        ...current,
        mode: "full",
        mediaType: isVideo ? "video" : isGif ? "gif" : "image",
        mediaUrl,
        fileName: file.name,
        durationSeconds: current.durationSeconds || "3",
      }));
      setToast("Full-screen splash media ready — set its time and save.");
    } catch {
      setToast("That splash file could not be loaded.");
    }
  };

  const saveSplash = async () => {
    if (splashSaving) return;
    const max = splashDraft.mode === "logo" ? 10 : 8;
    const duration = Number(splashDraft.durationSeconds);
    if (!Number.isFinite(duration) || duration < 1 || duration > max || Math.floor(duration) !== duration) {
      setToast(`Splash time must be a whole number from 1 to ${max} seconds.`);
      return;
    }
    if (splashDraft.mode === "full" && !splashDraft.mediaUrl) { setToast("Upload a full-screen splash image, GIF, or video first."); return; }
    setSplashSaving(true);
    try {
      const response = await fetch("/api/brand", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, action: "saveSplash", mode: splashDraft.mode, mediaType: splashDraft.mediaType, mediaUrl: splashDraft.mediaUrl, durationSeconds: duration }),
      });
      const data = await response.json() as { splash?: SplashSetting; error?: string };
      if (!response.ok || !data.splash) throw new Error(data.error || "Splash screen could not be saved.");
      setSplashSetting(data.splash);
      setSplashDraft((current) => ({ ...current, fileName: "" }));
      window.sessionStorage.removeItem("lumina-splash-seen");
      setToast("Splash screen saved — it will show on the next app launch.");
    } catch (error) {
      setToast(error instanceof Error ? error.message : "Splash screen could not be saved.");
    } finally { setSplashSaving(false); }
  };

  const deleteSplash = async () => {
    if (!window.confirm("Delete the saved splash screen setting?")) return;
    setSplashSaving(true);
    try {
      const response = await fetch("/api/brand", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, action: "deleteSplash" }),
      });
      const data = await response.json() as { splash?: SplashSetting; error?: string };
      if (!response.ok) throw new Error(data.error || "Splash screen could not be deleted.");
      if (data.splash) {
        setSplashSetting(data.splash);
        setSplashDraft({ mode: "logo", mediaType: "image", mediaUrl: "", durationSeconds: "2", fileName: "" });
      }
      window.sessionStorage.removeItem("lumina-splash-seen");
      setToast("Splash screen deleted.");
    } catch (error) {
      setToast(error instanceof Error ? error.message : "Splash screen could not be deleted.");
    } finally { setSplashSaving(false); }
  };

  const previewSplash = () => {
    if (splashTimerRef.current) window.clearTimeout(splashTimerRef.current);
    setSplashSetting({ mode: splashDraft.mode, mediaType: splashDraft.mediaType, mediaUrl: splashDraft.mediaUrl, durationSeconds: Math.max(1, Number(splashDraft.durationSeconds) || 2) });
    setSplashVisible(true);
    splashTimerRef.current = window.setTimeout(() => setSplashVisible(false), Math.max(1, Number(splashDraft.durationSeconds) || 2) * 1000);
  };

  const compressImage = (file: File, maxSide: number) => new Promise<string>((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      const ctx = canvas.getContext("2d");
      if (!ctx) { reject(new Error("Canvas unavailable")); return; }
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/webp", 0.84));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Image could not be read")); };
    img.src = url;
  });

  const handleAdFile = async (file: File | undefined) => {
    if (!file) return;
    setAdFileName(file.name);
    try {
      if (file.type.startsWith("image/")) {
        const data = await compressImage(file, 1280);
        setAdForm((current) => ({ ...current, mediaUrl: data, mediaType: "image", title: current.title || file.name.replace(/\.[^.]+$/, "") }));
        setAdDuration(null);
        setToast("Image added — it will loop in the showcase endlessly.");
      } else if (file.type.startsWith("video/")) {
        const url = URL.createObjectURL(file);
        const probe = document.createElement("video");
        probe.preload = "metadata"; probe.src = url;
        await new Promise<void>((resolve, reject) => { probe.onloadedmetadata = () => resolve(); probe.onerror = () => reject(new Error("Video could not be read")); });
        const duration = probe.duration;
        URL.revokeObjectURL(url);
        if (!Number.isFinite(duration) || duration < 3 || duration > 30) { setToast("Please choose a video between 3 and 30 seconds."); return; }
        if (file.size > 20_000_000) { setToast("That video is very large — please use the media URL option for files over 20 MB."); return; }
        const data = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result));
          reader.onerror = () => reject(new Error("Video could not be read"));
          reader.readAsDataURL(file);
        });
        setAdForm((current) => ({ ...current, mediaUrl: data, mediaType: "video", title: current.title || file.name.replace(/\.[^.]+$/, "") }));
        setAdDuration(Math.round(duration));
        setToast(`Video added (${Math.round(duration)}s) — it will loop again and again.`);
      } else setToast("Choose an image or a video file.");
    } catch { setToast("That file could not be added. Try another one."); }
  };

  const saveAd = async (event: FormEvent) => {
    event.preventDefault();
    const response = await fetch("/api/ads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "create", ...adForm, durationSeconds: adForm.mediaType === "video" ? adDuration : null }) });
    const data = await response.json() as { error?: string };
    if (!response.ok) { setToast(data.error || "Ad could not be saved."); return; }
    setAdForm({ title: "", mediaUrl: "", linkUrl: "", mediaType: "image", borderColor: "#FC84BD" });
    setAdDuration(null); setAdFileName("");
    setToast("Campaign published to the home showcase.");
    await loadAdmin();
    await loadAds(userId);
  };

  const toggleAd = async (ad: Advertisement) => {
    await fetch("/api/ads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "toggle", id: ad.id, active: !ad.active }) });
    await loadAdmin(); await loadAds(userId);
  };
  const deleteAd = async (ad: Advertisement) => {
    await fetch("/api/ads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "delete", id: ad.id }) });
    await loadAdmin(); await loadAds(userId);
  };

  const handleMaskFile = async (file: File | undefined) => {
    if (!file) return;
    if (file.type !== "image/png" && !file.name.toLowerCase().endsWith(".png")) {
      setToast("Please choose a PNG mask image.");
      return;
    }
    try {
      const url = URL.createObjectURL(file);
      const img = new Image();
      await new Promise<void>((resolve, reject) => { img.onload = () => resolve(); img.onerror = () => reject(new Error("PNG could not be read")); img.src = url; });
      const scale = Math.min(1, 512 / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      const ctx = canvas.getContext("2d");
      URL.revokeObjectURL(url);
      if (!ctx) throw new Error("Canvas unavailable");
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      setMaskForm((current) => ({
        ...current,
        imageUrl: canvas.toDataURL("image/png"),
        fileName: file.name,
        name: current.name || file.name.replace(/\.png$/i, "").replace(/[-_]+/g, " "),
      }));
      setToast("PNG mask ready — transparent eye holes will auto-align when detected.");
    } catch {
      setToast("That PNG could not be added. Try another mask.");
    }
  };

  const saveMask = async (event: FormEvent) => {
    event.preventDefault();
    const response = await fetch("/api/masks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "create", name: maskForm.name, imageUrl: maskForm.imageUrl, activate: true }) });
    const data = await response.json() as { error?: string };
    if (!response.ok) { setToast(data.error || "Mask could not be saved."); return; }
    setMaskForm({ name: "", imageUrl: "", fileName: "" });
    setToast("Face mask published — users can now select it from Masks in a video call.");
    await loadFaceMasks(true);
  };

  const setMaskActive = async (mask: FaceMask, activate: boolean) => {
    await fetch("/api/masks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: activate ? "activate" : "deactivate", id: mask.id }) });
    if (!activate && selectedFaceMaskIdRef.current === mask.id) {
      selectedFaceMaskIdRef.current = "";
      setSelectedFaceMaskId("");
      maskAssetRef.current = null;
    }
    await loadFaceMasks(true);
  };

  const deleteMask = async (mask: FaceMask) => {
    await fetch("/api/masks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "delete", id: mask.id }) });
    if (selectedFaceMaskIdRef.current === mask.id) {
      selectedFaceMaskIdRef.current = "";
      setSelectedFaceMaskId("");
      maskAssetRef.current = null;
    }
    await loadFaceMasks(true);
  };

  const loadSupport = useCallback(async (markRead = true) => {
    if (!userId) return;
    if (!signedIn) { setSupportLocked(true); setSupportMessages([]); return; }
    try {
      const response = await fetch(`/api/support?userId=${encodeURIComponent(userId)}`, { cache: "no-store" });
      if (response.status === 403) { setSupportLocked(true); setSupportMessages([]); return; }
      if (!response.ok) return;
      setSupportLocked(false);
      const data = await response.json() as { messages?: SupportMessage[] };
      setSupportMessages(data.messages || []);
      if (markRead) {
        await fetch("/api/support", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "markRead" }) }).catch(() => undefined);
      }
    } catch { /* chat retries on the next gentle poll */ }
  }, [signedIn, userId]);

  useEffect(() => {
    if (tab !== "support" || !userId) return;
    if (!signedIn) { setSupportLocked(true); setSupportMessages([]); return; }
    void loadSupport();
    const timer = window.setInterval(() => { if (!document.hidden) void loadSupport(false); }, 8000);
    return () => window.clearInterval(timer);
  }, [loadSupport, signedIn, tab, userId]);

  const handleSupportImage = async (file: File | undefined, admin = false) => {
    if (!file) return;
    try {
      const data = await compressImage(file, 1280);
      if (admin) setAdminReplyImage({ data, name: file.name });
      else setSupportImage({ data, name: file.name });
    } catch { setToast("That image could not be added."); }
  };

  const sendSupportMessage = async (event: FormEvent) => {
    event.preventDefault();
    if (!signedIn) { setSupportLocked(true); setToast("Admin Chat is locked — sign up or sign in with your email first."); return; }
    if ((!supportText.trim() && !supportImage) || supportSending) return;
    setSupportSending(true);
    try {
      const response = await fetch("/api/support", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "send", body: supportText, imageUrl: supportImage?.data || "" }) });
      const data = await response.json() as { message?: SupportMessage; error?: string };
      if (!response.ok || !data.message) throw new Error(data.error || "Message could not be sent.");
      setSupportMessages((current) => [...current, data.message!]);
      setSupportText("");
      setSupportImage(null);
    } catch (error) {
      setToast(error instanceof Error ? error.message : "Message could not be sent.");
    } finally { setSupportSending(false); }
  };

  const loadAdminSupport = useCallback(async () => {
    if (!userId || !isAdmin) return;
    try {
      const response = await fetch(`/api/support?userId=${encodeURIComponent(userId)}`, { cache: "no-store" });
      if (!response.ok) return;
      const data = await response.json() as { conversations?: SupportConversation[] };
      const conversations = data.conversations || [];
      setSupportConversations(conversations);
      setSelectedSupportId((current) => current && conversations.some((item) => item.userId === current) ? current : conversations[0]?.userId || "");
    } catch { /* next poll retries */ }
  }, [isAdmin, userId]);

  useEffect(() => {
    if (tab !== "admin" || adminSection !== "messages" || !isAdmin) return;
    void loadAdminSupport();
    const timer = window.setInterval(() => { if (!document.hidden) void loadAdminSupport(); }, 10000);
    return () => window.clearInterval(timer);
  }, [adminSection, isAdmin, loadAdminSupport, tab]);

  const selectSupportConversation = async (conversation: SupportConversation) => {
    setSelectedSupportId(conversation.userId);
    setSupportConversations((current) => current.map((item) => item.userId === conversation.userId ? { ...item, unread: 0 } : item));
    await fetch("/api/support", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "markRead", targetUserId: conversation.userId }) }).catch(() => undefined);
  };

  const sendAdminReply = async (event: FormEvent) => {
    event.preventDefault();
    if (!selectedSupportId || (!adminReplyText.trim() && !adminReplyImage)) return;
    const response = await fetch("/api/support", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, action: "reply", targetUserId: selectedSupportId, body: adminReplyText, imageUrl: adminReplyImage?.data || "" }) });
    const data = await response.json() as { message?: SupportMessage; error?: string };
    if (!response.ok || !data.message) { setToast(data.error || "Reply could not be sent."); return; }
    const sent = data.message;
    setSupportConversations((current) => current.map((item) => item.userId === selectedSupportId ? { ...item, messages: [...item.messages, sent], lastMessageAt: sent.createdAt } : item));
    setAdminReplyText("");
    setAdminReplyImage(null);
  };

  const deleteSupportMessage = async (messageId: string) => {
    if (!window.confirm("Delete this chat message?")) return;
    const response = await fetch("/api/support", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, action: "deleteMessage", messageId }),
    });
    const data = await response.json() as { error?: string };
    if (!response.ok) { setToast(data.error || "Message could not be deleted."); return; }
    setSupportConversations((current) => current.map((item) => ({ ...item, messages: item.messages.filter((message) => message.id !== messageId) })));
    setToast("Message deleted.");
  };

  const deleteSupportConversation = async () => {
    if (!selectedSupportId || !window.confirm("Delete this entire user chat? This cannot be undone.")) return;
    const response = await fetch("/api/support", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, action: "deleteConversation", targetUserId: selectedSupportId }),
    });
    const data = await response.json() as { deleted?: number; error?: string };
    if (!response.ok) { setToast(data.error || "Chat could not be deleted."); return; }
    setSupportConversations((current) => current.filter((item) => item.userId !== selectedSupportId));
    setSelectedSupportId("");
    setToast(`${data.deleted || 0} chat message${(data.deleted || 0) === 1 ? "" : "s"} deleted.`);
  };

  const selectedConversation = supportConversations.find((item) => item.userId === selectedSupportId) || null;

  const handleNotifImage = async (file: File | undefined) => {
    if (!file) return;
    try {
      const data = await compressImage(file, 1000);
      setNotifForm((current) => ({ ...current, imageUrl: data, imageName: file.name }));
    } catch { setToast("That image could not be added."); }
  };

  const sendNotification = async (event: FormEvent) => {
    event.preventDefault();
    const parsedCount = Number(notifCount);
    if (!Number.isFinite(parsedCount) || parsedCount < 1 || Math.floor(parsedCount) !== parsedCount) {
      setToast("Enter a whole send count of 1 or more.");
      return;
    }
    const response = await fetch("/api/notifications", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, targetUserId: notifForm.target, title: notifForm.title, body: notifForm.body, imageUrl: notifForm.imageUrl, count: parsedCount }) });
    const data = await response.json() as { error?: string; sent?: number };
    if (!response.ok) { setToast(data.error || "Notification could not be sent."); return; }
    const sent = data.sent || parsedCount;
    setNotifForm({ target: "all", title: "", body: "", imageUrl: "", imageName: "" });
    setNotifTargetSearch("");
    setNotifSuggestOpen(false);
    setNotifCount("1");
    setToast(sent === 1
      ? "Notification sent — it will auto-remove in 24 hours."
      : `${sent} notification copies sent — each will auto-remove in 24 hours.`);
    await loadAdmin();
  };

  const deleteAdminNotifications = async (ids: string[], all = false) => {
    if (!all && !ids.length) { setToast("Select at least one notification to delete."); return; }
    if (all && !window.confirm("Delete ALL sent notifications for everyone?")) return;
    if (!all && ids.length > 1 && !window.confirm(`Delete ${ids.length} selected notifications?`)) return;
    const response = await fetch("/api/notifications", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, ids, all }),
    });
    const data = await response.json() as { deleted?: number; error?: string };
    if (!response.ok) { setToast(data.error || "Notifications could not be deleted."); return; }
    setSelectedNotifIds(new Set());
    setToast(`${data.deleted || 0} notification${(data.deleted || 0) === 1 ? "" : "s"} deleted.`);
    await loadAdmin();
    await loadNotifications();
  };

  const toggleAdminNotification = (id: string) => {
    setSelectedNotifIds((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const headerNav: { id: MainTab; label: string; icon: string }[] = [
    { id: "connect", label: "Connect", icon: "video" },
    { id: "profile", label: "Profile", icon: "user" },
    { id: "support", label: "Admin Chat", icon: "mail" },
  ];
  const countryText = profile?.country && profile.country !== "Unknown" ? profile.country : "Worldwide";
  const currentAd = ads.length ? ads[Math.min(activeAd, ads.length - 1)] : null;
  const notifCandidates: { id: string; name: string; email: string }[] = (() => {
    const merged = new Map<string, { id: string; name: string; email: string }>();
    (adminData?.accounts || []).forEach((account) => merged.set(account.id, { id: account.id, name: account.name, email: account.email }));
    (adminData?.users || []).forEach((person) => { if (!merged.has(person.userId)) merged.set(person.userId, { id: person.userId, name: person.name, email: person.email }); });
    return [...merged.values()].filter((person) => person.email);
  })();
  const onlineUserIds = new Set(adminData?.onlineUserIds || []);
  const adminNotifications = adminData?.notifications || [];
  const allAdminNotifsSelected = adminNotifications.length > 0 && adminNotifications.every((item) => selectedNotifIds.has(item.id));
  const selectedTargetLabel = notifCandidates.find((person) => person.id === notifForm.target)
    ? `${notifCandidates.find((person) => person.id === notifForm.target)?.name || ""} · ${notifCandidates.find((person) => person.id === notifForm.target)?.email || ""}`
    : "Selected user";
  const notifQuery = notifTargetSearch.trim().toLowerCase();
  const notifSuggestions = notifQuery
    ? notifCandidates
      .filter((person) => person.email.toLowerCase().includes(notifQuery) || person.name.toLowerCase().includes(notifQuery))
      .sort((a, b) => {
        const score = (person: { name: string; email: string }) => person.email.toLowerCase() === notifQuery ? 0 : person.email.toLowerCase().startsWith(notifQuery) ? 1 : person.name.toLowerCase().startsWith(notifQuery) ? 2 : 3;
        return score(a) - score(b) || a.email.localeCompare(b.email);
      })
      .slice(0, 6)
    : [];
  const selectNotifCandidate = (person: { id: string; name: string; email: string }) => {
    setNotifForm((current) => ({ ...current, target: person.id }));
    setNotifTargetSearch(person.email);
    setNotifSuggestOpen(false);
  };
  const handleNotifTargetSearch = (value: string) => {
    setNotifTargetSearch(value);
    const query = value.trim().toLowerCase();
    setNotifSuggestOpen(Boolean(query));
    const exact = notifCandidates.find((person) => person.email.toLowerCase() === query);
    // Empty = Everyone. An exact pasted/typed registered email selects that
    // account immediately; partial typing stays unselected until chosen.
    setNotifForm((current) => ({ ...current, target: exact ? exact.id : "all" }));
  };
  const adStageInner = currentAd ? (
    <>
      {currentAd.mediaType === "video"
        ? <video key={currentAd.id} src={currentAd.mediaUrl} autoPlay muted loop playsInline />
        : <img key={currentAd.id} src={currentAd.mediaUrl} alt={currentAd.title} />}
      <span className="ad-showcase-caption"><b>{currentAd.title}</b><small>{currentAd.linkUrl ? "Tap to visit" : "Sponsored"}</small></span>
    </>
  ) : null;

  return (
    <main className={`app-shell${pageVisible ? "" : " is-hidden"}`}>
      {splashVisible && <div className={`splash-screen ${splashSetting.mode}`} role="status" aria-label="Lumina is opening">
        {splashSetting.mode === "full" && splashSetting.mediaUrl ? (
          splashSetting.mediaType === "video"
            ? <video src={splashSetting.mediaUrl} autoPlay muted loop playsInline />
            : <img src={splashSetting.mediaUrl} alt="" />
        ) : <div className="splash-logo-wrap"><span className="splash-logo"><img src={brandIcon} alt="" /></span><strong>lumina<span>connect</span></strong><small>Real people. Real moments.</small><i /></div>}
        <button type="button" className="splash-skip" onClick={() => setSplashVisible(false)}>Skip</button>
      </div>}
      <div className="ambient ambient-one" /><div className="ambient ambient-two" /><div className="grain" />
      <header className="topbar">
        <LuminaLogo iconUrl={brandIcon} />
        <nav className={`top-nav ${menuOpen ? "open" : ""}`} aria-label="Main navigation">
          {headerNav.map((item) => <button key={item.id} onClick={() => { setTab(item.id); setMenuOpen(false); }} className={tab === item.id ? "nav-item active" : "nav-item"}><Icon name={item.icon} size={17} />{item.label}</button>)}
          {isAdmin && <button onClick={() => { setTab("admin"); setMenuOpen(false); }} className={tab === "admin" ? "nav-item active" : "nav-item"}><Icon name="shield" size={17} />Admin</button>}
        </nav>
        <div className="topbar-actions">
          <span className="online-pill"><i />{isOnline ? `${onlineCount} online` : "Offline ready"}</span>
          {!isInstalled && <button className="icon-button install-top-button" onClick={() => void installApp()} aria-label="Install Lumina app" title="Install Lumina app"><Icon name="download" size={18} /></button>}
          <button className="icon-button bell-button" onClick={() => void openNotifications()} aria-label={unreadCount ? `Notifications — ${unreadCount} unread` : "Notifications"} title="Notifications"><Icon name="bell" size={18} />{unreadCount > 0 && <span className="notif-badge">{unreadCount > 99 ? "99+" : unreadCount}</span>}</button>
          <button className="icon-button perm-button" onClick={openPermissions} aria-label="Permissions — camera, microphone, notifications" title="Permissions"><Icon name="shield" size={18} />{(permStatus.camera !== "granted" || permStatus.microphone !== "granted" || permStatus.notifications !== "granted") && <i className="perm-dot" />}</button>
          <button className="icon-button menu-button" onClick={() => setMenuOpen((open) => !open)} aria-label="Open navigation"><Icon name="menu" /></button>
        </div>
      </header>

      {toast && <div className="toast"><span><Icon name="spark" size={18} /></span>{toast}<button onClick={() => setToast("")} aria-label="Close notification"><Icon name="close" size={16} /></button></div>}

      {showNotifPrompt && <div className="notif-prompt" role="dialog" aria-label="Enable notifications">
        <span className="notif-prompt-icon"><Icon name="bell" size={21} /></span>
        <div><strong>Never miss a hello</strong><p>Allow notifications so Lumina can tell you about matches and updates, even in the background. You can change this anytime from Permissions.</p></div>
        <div className="notif-prompt-actions"><button className="notif-allow" onClick={() => void answerNotifPrompt(true)}>{permStatus.notifications === "denied" ? "Review" : "Allow"}</button><button className="notif-later" onClick={() => void answerNotifPrompt(false)}>Later</button></div>
      </div>}

      {incomingNotif && <div className="incoming-notif" role="alert">
        <button className="incoming-close" onClick={() => { void markNotifRead(incomingNotif.id); setIncomingNotif(null); }} aria-label="Dismiss"><Icon name="close" size={15} /></button>
        {incomingNotif.imageUrl && <img src={incomingNotif.imageUrl} alt="" />}
        <div><small><Icon name="bell" size={12} /> LUMINA UPDATE</small><strong>{incomingNotif.title}</strong>{incomingNotif.body && <p>{incomingNotif.body}</p>}</div>
        <button className="notif-allow" onClick={() => { void markNotifRead(incomingNotif.id); setIncomingNotif(null); }}>Got it</button>
      </div>}

      {notifOpen && <div className="modal-backdrop" onClick={(event) => { if (event.target === event.currentTarget) setNotifOpen(false); }}>
        <section className="notif-modal" role="dialog" aria-modal="true" aria-label="Notifications">
          <div className="permissions-head"><div><span className="field-label">NOTIFICATIONS</span><h2>Your updates</h2><p>Everything from the last 24 hours — older updates remove themselves automatically.</p></div><button className="incoming-close static" onClick={() => setNotifOpen(false)} aria-label="Close notifications"><Icon name="close" size={17} /></button></div>
          <div className="notif-list">
            {notifList.length ? notifList.map((item) => (
              <article className={item.read ? "notif-item" : "notif-item unread"} key={item.id}>
                {item.imageUrl ? <img src={item.imageUrl} alt="" /> : <span className="notif-item-icon"><Icon name="bell" size={17} /></span>}
                <div className="notif-item-copy">
                  <div className="notif-item-top"><b>{item.title}</b>{!item.read && <i className="unread-dot" />}</div>
                  {item.body && <p>{item.body}</p>}
                  <small>{dateLabel(item.createdAt)} · {expiresInLabel(item)}</small>
                </div>
              </article>
            )) : <div className="admin-empty notif-empty"><span className="notif-empty-icon"><Icon name="bell" size={22} /></span><b>No notifications yet</b><small>New updates will appear here for 24 hours.</small></div>}
          </div>
          <button className="secondary-cta perm-done" onClick={() => setNotifOpen(false)}>Done</button>
        </section>
      </div>}

      {installHelpOpen && <div className="modal-backdrop" onClick={(event) => { if (event.target === event.currentTarget) setInstallHelpOpen(false); }}>
        <section className="permissions-modal install-modal" role="dialog" aria-modal="true" aria-label="Install Lumina">
          <div className="permissions-head"><div><span className="field-label">INSTALL LUMINA</span><h2>Add to your home screen</h2><p>Two quick steps and Lumina opens like a real app — full screen, one tap.</p></div><button className="incoming-close static" onClick={() => setInstallHelpOpen(false)} aria-label="Close install help"><Icon name="close" size={17} /></button></div>
          {/iphone|ipad|ipod/i.test(navigator.userAgent) || (/macintosh/i.test(navigator.userAgent) && navigator.maxTouchPoints > 1) ? (
            <ol className="install-steps">
              <li><span>1</span><p><b>Tap the Share icon</b><small>In Safari’s toolbar (the square with an arrow pointing up).</small></p></li>
              <li><span>2</span><p><b>Choose “Add to Home Screen”</b><small>Scroll the share list a little if you don’t see it right away.</small></p></li>
              <li><span>3</span><p><b>Tap “Add”</b><small>Lumina’s pink icon appears on your home screen.</small></p></li>
            </ol>
          ) : (
            <ol className="install-steps">
              <li><span>1</span><p><b>Open your browser menu</b><small>Tap ⋮ (Chrome/Android) or check the right end of the address bar on desktop.</small></p></li>
              <li><span>2</span><p><b>Tap “Install app” / “Add to Home screen”</b><small>Then confirm — Lumina installs in a couple of seconds.</small></p></li>
              <li><span>3</span><p><b>Open Lumina from your home screen</b><small>It runs full screen, just like a native app.</small></p></li>
            </ol>
          )}
          {canInstall && <button className="perm-enable install-now" onClick={() => { setInstallHelpOpen(false); void installApp(); }}>Install now</button>}
          <button className="secondary-cta perm-done" onClick={() => setInstallHelpOpen(false)}>Done</button>
        </section>
      </div>}

      {permOpen && <div className="modal-backdrop" onClick={(event) => { if (event.target === event.currentTarget) setPermOpen(false); }}>
        <section className="permissions-modal" role="dialog" aria-modal="true" aria-label="Permissions">
          <div className="permissions-head"><div><span className="field-label">PERMISSIONS</span><h2>Your controls, always here</h2><p>Declined something once? No problem — review and re-enable every permission here, anytime, forever.</p></div><button className="incoming-close static" onClick={() => setPermOpen(false)} aria-label="Close permissions"><Icon name="close" size={17} /></button></div>
          {([
            ["camera", "Camera", "So people can see you during video calls.", "camera"],
            ["microphone", "Microphone", "So people can hear you during video calls.", "mic"],
            ["notifications", "Notifications", "Match and update alerts, even in the background.", "bell"],
          ] as ["camera" | "microphone" | "notifications", string, string, string][]).map(([key, label, detail, icon]) => (
            <div className="perm-row" key={key}>
              <span className="perm-icon"><Icon name={icon} size={18} /></span>
              <div className="perm-copy"><b>{label}</b><small>{detail}</small>{permStatus[key] === "denied" && <small className="perm-help">Blocked in your browser — open site settings → Permissions, allow {label.toLowerCase()}, then tap Enable.</small>}{permStatus[key] === "unsupported" && <small className="perm-help">Not supported in this browser.</small>}</div>
              <span className={`perm-status ${permStatus[key]}`}>{permStatus[key] === "granted" ? "Allowed" : permStatus[key] === "denied" ? "Blocked" : permStatus[key] === "unsupported" ? "N/A" : "Not set"}</span>
              {permStatus[key] !== "granted" && permStatus[key] !== "unsupported" && <button className="perm-enable" onClick={() => void (key === "notifications" ? requestNotificationPermission() : requestMediaPermission(key))}>Enable</button>}
            </div>
          ))}
          <div className="perm-row install-row">
            <span className="perm-icon"><Icon name="download" size={18} /></span>
            <div className="perm-copy"><b>Install Lumina</b><small>Add the app to your home screen for one-tap opening.</small></div>
            <button className="perm-enable" onClick={() => void installApp()}>{isInstalled ? "Installed ✓" : "Install"}</button>
          </div>
          <button className="secondary-cta perm-done" onClick={() => setPermOpen(false)}>Done</button>
        </section>
      </div>}

      <section className="promo-line"><Icon name="shield" size={16} /><span>Private peer-to-peer video — no bots, no recordings.</span><span className="promo-divider">•</span><Icon name="globe" size={16} /><span>Connecting from {profile ? countryWithFlag(profile.country, profile.countryCode) : countryText}</span></section>

      {tab === "connect" && <section className="page connect-page">
        <div className="hero-copy">
          <div className="eyebrow"><span className="dot" />REAL PEOPLE, RIGHT NOW</div>
          <h1>Meet your next <em>good moment.</em></h1>
          <p>Real conversations begin with a single click. Choose who you’d like to meet and we’ll connect you when someone compatible is ready.</p>
          <div className="hero-trust"><span><Icon name="check" size={16} />No fake profiles</span><span><Icon name="check" size={16} />Instant matching</span><span className="live-count"><i />{isOnline ? `${onlineCount} online now` : "Offline mode ready"}</span><span className="visitor-count"><Icon name="users" size={16} />{new Intl.NumberFormat().format(totalVisitors)} total visitors</span></div>
        </div>

        <div className={`call-stage ${callState}`}>
          {callState === "idle" && <>
            <div className="stage-glow" />
            <div className="preview-frame"><StreamVideo stream={localStream} mirrored muted />{!localStream && <div className="video-placeholder"><span className="camera-orb"><Icon name="camera" size={29} /></span><strong>Your camera preview</strong><small>We’ll ask permission when you connect.</small></div>}<span className="preview-tag">You {profile?.gender ? genderSymbol(profile.gender) : ""}</span></div>
            <div className="stage-caption"><span className="mini-pulse" />Ready when you are · {quality.label}</div>
          </>}
          {callState === "searching" && <>
            <div className="searching-panel"><div className="radar"><i /><i /><i /><span><Icon name="search" size={29} /></span></div><div className="searching-copy"><div className="eyebrow centered"><span className="dot" />LOOKING LIVE</div><h2>Finding someone<br />wonderful…</h2><p>We’re checking for a real person who matches your preference.</p></div><button className="cancel-search" onClick={() => void endCall(true)}><Icon name="close" size={17} />Cancel search</button></div>
            <div className="mini-local"><StreamVideo stream={localStream} mirrored muted /></div>
          </>}
          {callState === "connected" && <>
            <div className="remote-frame"><StreamVideo stream={remoteStream} className={peerHidden || peerVideoHidden ? "video-feed hidden-video" : "video-feed"} />{!remoteStream && !peerVideoHidden && <div className="connection-wait"><span className="loading-ring" /><strong>Securing your call…</strong><small>Connecting video with {peer?.name || "your match"}</small></div>}{peerVideoHidden ? <div className="remote-hidden-notice"><GenderAvatar gender={peer?.gender} name={peer?.name || "Your match"} /><strong>{peer?.name || "Your match"} hid their video</strong><span>They can still see and hear you — you’ll see them again when they’re back.</span></div> : peerHidden && <div className="hidden-cover"><Icon name="eyeOff" /><span>Hidden for you only</span></div>}<div className="person-label"><span className="person-online" />{peer?.name || "New connection"}<span className={`gender-chip ${genderTone(peer?.gender)}`}>{genderSymbol(peer?.gender)} {genderLabel(peer?.gender)}</span>{peer && <small>{countryWithFlag(peer.country, peer.countryCode)}</small>}</div></div>
            {connectAnim && <div className="connect-overlay"><GenderAvatar gender={connectAnim.gender} name={connectAnim.name} /><strong>Connecting with {connectAnim.name}</strong><span className={`connect-gender ${genderTone(connectAnim.gender)}`}>{genderSymbol(connectAnim.gender)} {genderLabel(connectAnim.gender)}</span><small>{countryWithFlag(connectAnim.country, connectAnim.countryCode)} · Setting up your private video…</small></div>}
            <div className="self-frame"><StreamVideo stream={localStream} mirrored muted /><span>You {profile?.gender ? genderSymbol(profile.gender) : ""}{selfHidden ? " · Hidden from partner" : ""}</span></div>
            <div className="chat-overlay">
              <div className="chat-scroll" ref={chatScrollRef} onScroll={(event) => { const el = event.currentTarget; chatNearBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 60; }}>
                {messages.length === 0 && <p className="chat-hint">Say hello 👋 — messages float here while you chat.</p>}
                {messages.map((message) => <div className={message.mine ? "chat-line mine" : "chat-line"} key={message.id}><p>{message.text}</p><small>{message.mine ? "You" : peer?.name || "Match"}</small></div>)}
              </div>
              <form onSubmit={(event) => void submitChat(event)} className="chat-dock"><input value={chatText} onChange={(event) => setChatText(event.target.value)} maxLength={500} placeholder="Write a message…" aria-label="Write a message" /><button type="submit" aria-label="Send message"><Icon name="send" size={16} /></button></form>
            </div>
          </>}
        </div>

        {callState === "connected" && <div className="call-dock">
          {connectionNotice && <div className="connection-notice" role="status">{connectionNotice}</div>}
          {maskPickerOpen && <div className="mask-picker external" role="dialog" aria-label="Face mask filters">
            <div className="mask-picker-head"><div><small>FACE FILTERS</small><strong>{faceEngineStatus === "loading" ? "Loading pro face tracking…" : "Auto-tracked to every face"}</strong></div><button type="button" onClick={() => setMaskPickerOpen(false)} aria-label="Close mask filters"><Icon name="close" size={16} /></button></div>
            <div className="mask-filter-list">
              <button type="button" className={!faceBlur ? "mask-filter selected" : "mask-filter"} onClick={() => void disableFaceEffect()}>
                <span className="mask-filter-preview off"><Icon name="eye" size={21} /></span><b>No filter</b><small>Show your real face</small>
              </button>
              <button type="button" className={faceBlur && !selectedFaceMaskId ? "mask-filter selected" : "mask-filter"} onClick={() => void enableFaceEffect("")}>
                <span className="mask-filter-preview blur-preview"><Icon name="blur" size={21} /></span><b>Full Face Hide</b><small>Strong face-only blur</small>
              </button>
              {availableFaceMasks.map((mask) => (
                <button type="button" key={mask.id} className={selectedFaceMaskId === mask.id ? "mask-filter selected" : "mask-filter"} onClick={() => void enableFaceEffect(mask.id)}>
                  <span className="mask-filter-preview mask-preview-thumb"><img src={mask.imageUrl} alt="" loading="lazy" decoding="async" /></span><b>{mask.name}</b><small>Auto-fit PNG mask</small>
                </button>
              ))}
            </div>
            {!availableFaceMasks.length && <p className="mask-picker-empty">Admin has not published a PNG mask yet — Full Face Hide is ready.</p>}
          </div>}
          <div className="call-controls external"><button className={muted ? "control-button active-control" : "control-button"} onClick={toggleMute} title={muted ? "Unmute microphone" : "Mute microphone"}><Icon name={muted ? "micOff" : "mic"} /><span>{muted ? "Unmute" : "Mute"}</span></button><button className={faceBlur && !selectedFaceMaskId ? "control-button active-control" : "control-button"} onClick={() => void toggleFaceBlur()} title="Full Face Hide — fully blur every tracked face"><Icon name="blur" /><span>Blur face</span></button><button className={selectedFaceMaskId || maskPickerOpen ? "control-button active-control" : "control-button"} onClick={() => { setMaskPickerOpen((open) => !open); void loadFaceMasks(false); }} title="See all face mask filters"><Icon name="mask" /><span>Masks</span></button><button className={selfHidden ? "control-button active-control" : "control-button"} onClick={() => void toggleSelfHidden()} title="Hide yourself from your partner (person icon)"><Icon name="hideSelf" /><span>Hide me</span></button><button className={peerHidden ? "control-button active-control" : "control-button"} onClick={() => setPeerHidden((hidden) => !hidden)} title="Hide partner only on your screen (screen icon)"><Icon name="hidePartner" /><span>Hide them</span></button><button className="control-button" onClick={() => void flipCamera()} title="Flip camera"><Icon name="flip" /><span>Flip</span></button><button className="control-button hangup" onClick={() => void endCall()} title="End call"><Icon name="close" /><span>End</span></button></div>
        </div>}

        <div className="match-panel">
          <div className="match-panel-heading"><div><span className="field-label">YOUR MATCH PREFERENCE</span><h2>Who would you like to meet?</h2></div><span className="privacy-chip"><Icon name="lock" size={14} />Private</span></div>
          <div className="preference-grid" role="radiogroup" aria-label="Matching preference">
            {([ ["all", "Everyone", "Meet anyone who's ready for a real chat."], ["male", "Men", "Connect with men around the world."], ["female", "Women", "Connect with women around the world."] ] as [Preference, string, string][]).map(([value, label, detail]) => <button key={value} onClick={() => setPreference(value)} className={preference === value ? "preference selected" : "preference"} disabled={callState !== "idle"} role="radio" aria-checked={preference === value}><span className="radio-mark">{preference === value && <Icon name="check" size={13} stroke={3} />}</span><strong>{label}</strong><small>{detail}</small></button>)}
          </div>
          <div className="match-action"><div className="availability"><span /><p><b>{onlineCount} people online · {new Intl.NumberFormat().format(totalVisitors)} total visitors</b><br />You’ll only be paired with someone actively searching.</p></div><button className="primary-cta" disabled={callState !== "idle"} onClick={() => void startMatching()}>{callState === "idle" ? <><Icon name="video" size={20} />Start a conversation <Icon name="arrow" size={18} /></> : <><span className="button-spinner" />{callState === "searching" ? "Looking for someone…" : "You’re connected"}</>}</button></div>
          <div className="optimizer-line"><span><Icon name="gauge" size={14} /> Auto optimizer on</span><span>{quality.label}{quality.kbps ? ` · ~${quality.kbps} kbps` : ""}{quality.rtt ? ` · ${quality.rtt} ms ping` : ""}{quality.fps ? ` · ${quality.fps} fps` : ""}</span><span className="optimizer-note">Background activity slows automatically to keep your call smooth</span></div>
          {mediaError && <p className="media-error">{mediaError} <button type="button" className="media-perm-link" onClick={openPermissions}>Review permissions</button></p>}
        </div>

        <section className="ad-showcase" aria-label="Featured">
          <div className="ad-showcase-head"><span><Icon name="spark" size={16} />Featured</span>{ads.length > 1 && <div className="ad-dots">{ads.map((ad, index) => <button key={ad.id} className={index === Math.min(activeAd, ads.length - 1) ? "ad-dot active" : "ad-dot"} onClick={() => setActiveAd(index)} aria-label={`Show ${ad.title}`} />)}</div>}</div>
          {currentAd ? (
            currentAd.linkUrl
              ? <a className="ad-stage" href={currentAd.linkUrl} target="_blank" rel="noreferrer" style={{ borderColor: currentAd.borderColor }}>{adStageInner}</a>
              : <div className="ad-stage" style={{ borderColor: currentAd.borderColor }}>{adStageInner}</div>
          ) : <div className="ad-stage ad-stage-empty"><span><Icon name="spark" size={26} /></span><b>A featured moment is coming</b><small>This space lights up with community picks.</small></div>}
        </section>
      </section>}

      {tab === "profile" && <section className="page profile-page"><div className="profile-hero"><div className="eyebrow"><span className="dot" />YOUR SPACE</div><h1>Be known by your <em>real self.</em></h1><p>Create your account once, then sign in anywhere. Your basics help us make respectful, compatible connections.</p><div className="privacy-list"><span><Icon name="shield" />Data stays protected</span><span><Icon name="globe" />Country-aware matching</span></div></div>
        <div className="profile-card">
          {signedIn ? <>
            <div className="profile-card-top"><div className="avatar-large">{profileForm.name ? profileForm.name.slice(0, 1).toUpperCase() : <Icon name="user" />}</div><div><span className="field-label">YOUR PROFILE</span><h2>{profileForm.name || "Introduce yourself"}</h2><p>{lockRemaining ? <><Icon name="lock" size={14} />Editable again in {lockRemaining}</> : "Signed in — only shared after a match."}</p></div><button className="signout-button" onClick={signOut}><Icon name="logout" size={15} />Sign out</button></div>
            <form onSubmit={(event) => void saveProfile(event)} className="profile-form"><label>Your name<input value={profileForm.name} disabled={Boolean(lockRemaining)} onChange={(event) => setProfileForm((current) => ({ ...current, name: event.target.value }))} placeholder="How should we call you?" maxLength={80} required /></label><label>Email address<input type="email" value={profileForm.email} disabled={Boolean(lockRemaining)} onChange={(event) => setProfileForm((current) => ({ ...current, email: event.target.value }))} placeholder="you@example.com" required /></label><div className="form-columns"><label>Date of birth<input type="date" value={profileForm.dob} disabled={Boolean(lockRemaining)} onChange={(event) => setProfileForm((current) => ({ ...current, dob: event.target.value }))} max={new Date().toISOString().slice(0, 10)} required /></label><label>Gender<select value={profileForm.gender} disabled={Boolean(lockRemaining)} onChange={(event) => setProfileForm((current) => ({ ...current, gender: event.target.value as Gender }))} required><option value="" disabled>Select one</option><option value="female">Female</option><option value="male">Male</option><option value="nonbinary">Non-binary</option><option value="prefer-not-to-say">Prefer not to say</option></select></label></div><div className="profile-lock-note"><Icon name="lock" size={16} /><span>After saving, profile details are locked for 24 hours to help keep Lumina genuine.</span></div><button type="submit" className="primary-cta profile-save" disabled={saving || Boolean(lockRemaining)}>{saving ? <span className="button-spinner" /> : <Icon name="check" />}{lockRemaining ? `Locked for ${lockRemaining}` : "Save my profile"}</button></form>
          </> : guestMode ? <>
            <div className="profile-card-top"><div className="avatar-large">{profileForm.name ? profileForm.name.slice(0, 1).toUpperCase() : <Icon name="user" />}</div><div><span className="field-label">GUEST PROFILE</span><h2>{profileForm.name || "Introduce yourself"}</h2><p>{lockRemaining ? <><Icon name="lock" size={14} />Editable again in {lockRemaining}</> : "This is only shared after a match."}</p></div></div>
            <form onSubmit={(event) => void saveProfile(event)} className="profile-form"><label>Your name<input value={profileForm.name} disabled={Boolean(lockRemaining)} onChange={(event) => setProfileForm((current) => ({ ...current, name: event.target.value }))} placeholder="How should we call you?" maxLength={80} required /></label><label>Email address<input type="email" value={profileForm.email} disabled={Boolean(lockRemaining)} onChange={(event) => setProfileForm((current) => ({ ...current, email: event.target.value }))} placeholder="you@example.com" required /></label><div className="form-columns"><label>Date of birth<input type="date" value={profileForm.dob} disabled={Boolean(lockRemaining)} onChange={(event) => setProfileForm((current) => ({ ...current, dob: event.target.value }))} max={new Date().toISOString().slice(0, 10)} required /></label><label>Gender<select value={profileForm.gender} disabled={Boolean(lockRemaining)} onChange={(event) => setProfileForm((current) => ({ ...current, gender: event.target.value as Gender }))} required><option value="" disabled>Select one</option><option value="female">Female</option><option value="male">Male</option><option value="nonbinary">Non-binary</option><option value="prefer-not-to-say">Prefer not to say</option></select></label></div><div className="profile-lock-note"><Icon name="lock" size={16} /><span>After saving, profile details are locked for 24 hours to help keep Lumina genuine.</span></div><button type="submit" className="primary-cta profile-save" disabled={saving || Boolean(lockRemaining)}>{saving ? <span className="button-spinner" /> : <Icon name="check" />}{lockRemaining ? `Locked for ${lockRemaining}` : "Save my profile"}</button><button type="button" className="text-button" onClick={() => setGuestMode(false)}>Back to sign up / sign in</button></form>
          </> : <>
            <div className="auth-tabs" role="tablist" aria-label="Account">
              <button role="tab" aria-selected={authMode === "signup"} className={authMode === "signup" ? "auth-tab active" : "auth-tab"} onClick={() => setAuthMode("signup")}>Sign up</button>
              <button role="tab" aria-selected={authMode === "signin"} className={authMode === "signin" ? "auth-tab active" : "auth-tab"} onClick={() => setAuthMode("signin")}>Sign in</button>
            </div>
            {authMode === "signup" ? <form onSubmit={(event) => void submitAuth(event)} className="profile-form auth-form"><p className="auth-intro">Create your Lumina account with your real details.</p><label>Your name<input value={profileForm.name} onChange={(event) => setProfileForm((current) => ({ ...current, name: event.target.value }))} placeholder="How should we call you?" maxLength={80} required /></label><label>Sign-up email<input type="email" value={profileForm.email} onChange={(event) => setProfileForm((current) => ({ ...current, email: event.target.value }))} placeholder="you@example.com" required /></label><div className="form-columns"><label>Birthday<input type="date" value={profileForm.dob} onChange={(event) => setProfileForm((current) => ({ ...current, dob: event.target.value }))} max={new Date().toISOString().slice(0, 10)} required /></label><label>Your gender<select value={profileForm.gender} onChange={(event) => setProfileForm((current) => ({ ...current, gender: event.target.value as Gender }))} required><option value="" disabled>Select one</option><option value="female">Female</option><option value="male">Male</option><option value="nonbinary">Non-binary</option><option value="prefer-not-to-say">Prefer not to say</option></select></label></div><label>Password<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 6 characters" minLength={6} required autoComplete="new-password" /></label><button type="submit" className="primary-cta profile-save" disabled={authBusy}>{authBusy ? <span className="button-spinner" /> : <Icon name="check" />}Create my account</button></form>
            : <form onSubmit={(event) => void submitAuth(event)} className="profile-form auth-form"><p className="auth-intro">Welcome back — sign in with your account email.</p><label>Sign-in email<input type="email" value={signInForm.email} onChange={(event) => setSignInForm((current) => ({ ...current, email: event.target.value }))} placeholder="you@example.com" required autoComplete="email" /></label><label>Password<input type="password" value={signInForm.password} onChange={(event) => setSignInForm((current) => ({ ...current, password: event.target.value }))} placeholder="Your password" required autoComplete="current-password" /></label><button type="submit" className="primary-cta profile-save" disabled={authBusy}>{authBusy ? <span className="button-spinner" /> : <Icon name="arrow" />}Sign in</button></form>}
            <button type="button" className="text-button" onClick={() => setGuestMode(true)}>Continue with a guest profile instead</button>
          </>}
        </div>
        <section className="permissions-card">
          <div><span className="field-label">PERMISSIONS</span><h2>Camera, mic & alerts</h2><p>Declined once? You can review and re-enable every permission here — anytime, forever.</p></div>
          <div className="permissions-summary">
            <span className={`perm-status ${permStatus.camera}`}>Camera {permStatus.camera === "granted" ? "on" : "off"}</span>
            <span className={`perm-status ${permStatus.microphone}`}>Mic {permStatus.microphone === "granted" ? "on" : "off"}</span>
            <span className={`perm-status ${permStatus.notifications}`}>Alerts {permStatus.notifications === "granted" ? "on" : "off"}</span>
          </div>
          <button className="secondary-cta" onClick={openPermissions}><Icon name="shield" size={16} />Review permissions</button>
        </section>
      </section>}

      {tab === "support" && <section className="page support-page">
        <div className="profile-hero"><div className="eyebrow"><span className="dot" />MESSAGE ADMIN</div><h1>Talk to <em>Admin.</em></h1><p>Questions, help, or something not working? Send a message — and attach a photo from your gallery if it helps.</p><div className="privacy-list"><span><Icon name="shield" />Private conversation</span><span><Icon name="mail" />Replies appear here</span></div></div>
        {(!signedIn || supportLocked) ? <div className="support-card support-locked-card" role="alert">
          <span className="support-lock-icon"><Icon name="lock" size={30} /></span>
          <span className="field-label">ADMIN CHAT LOCKED</span>
          <h2>Email account required</h2>
          <p>Admin Chat is only for registered users. Please <b>sign up</b> or <b>sign in</b> with your email account first — guest profiles cannot open this area.</p>
          <div className="support-lock-actions">
            <button type="button" className="primary-cta" onClick={() => { setGuestMode(false); setAuthMode("signup"); setTab("profile"); }}><Icon name="user" size={17} />Sign up</button>
            <button type="button" className="secondary-cta" onClick={() => { setGuestMode(false); setAuthMode("signin"); setTab("profile"); }}><Icon name="mail" size={17} />Sign in</button>
          </div>
        </div> : <div className="support-card">
          <div className="support-head"><span className="avatar-large support-avatar">A</span><div><span className="field-label">LUMINA SUPPORT</span><h2>Admin Chat</h2><p><i className="support-online" />We usually reply as soon as we can.</p></div></div>
          <div className="support-messages" ref={supportScrollRef}>
            {supportMessages.length ? supportMessages.map((message) => (
              <div className={message.senderRole === "admin" ? "support-message theirs" : "support-message mine"} key={message.id}>
                {message.imageUrl && <img src={message.imageUrl} alt="Shared with Admin" loading="lazy" decoding="async" />}
                {message.body && <p>{message.body}</p>}
                <small>{message.senderRole === "admin" ? "Admin" : "You"} · {dateLabel(message.createdAt)}</small>
              </div>
            )) : <div className="support-empty"><span><Icon name="mail" size={24} /></span><b>No messages yet</b><small>Say hello — your conversation with Admin starts here.</small></div>}
          </div>
          {supportImage && <div className="support-image-preview"><img src={supportImage.data} alt="Attachment preview" /><div><b>{supportImage.name}</b><small>Ready to send to Admin</small></div><button type="button" onClick={() => setSupportImage(null)} aria-label="Remove attachment"><Icon name="close" size={16} /></button></div>}
          <form className="support-composer" onSubmit={(event) => void sendSupportMessage(event)}>
            <button type="button" className="support-attach" onClick={() => supportFileRef.current?.click()} aria-label="Add image from gallery" title="Add image from gallery"><Icon name="upload" size={19} /></button>
            <input ref={supportFileRef} type="file" accept="image/*" className="file-hidden" onChange={(event) => { void handleSupportImage(event.target.files?.[0]); event.target.value = ""; }} />
            <input value={supportText} onChange={(event) => setSupportText(event.target.value)} maxLength={2000} placeholder="Message Admin…" aria-label="Message Admin" />
            <button type="submit" className="support-send" disabled={supportSending || (!supportText.trim() && !supportImage)} aria-label="Send message to Admin"><Icon name="send" size={18} /></button>
          </form>
        </div>}
      </section>}

      {tab === "admin" && (isAdmin ? <section className="page admin-page">
        <div className="admin-heading"><div><div className="eyebrow"><span className="dot" />ADMINISTRATOR</div><h1>Lumina <em>control room.</em></h1><p>Everything in one calm place — people, accounts, ads, notifications and stream health, each in its own section.</p></div><button className="refresh-button" onClick={() => void loadAdmin()}><Icon name="spark" size={17} />Refresh data</button></div>
        <div className="admin-sections" role="tablist" aria-label="Admin sections">
          {([["overview", "Overview", "spark"], ["people", "People & accounts", "user"], ["activity", "Activity", "layers"], ["ads", "Advertisements", "ad"], ["notifications", "Notifications", "bell"], ["messages", "Admin Chat", "mail"], ["masks", "Face Masks", "blur"], ["branding", "Brand Icon", "spark"], ["system", "Optimizer & system", "gauge"]] as [AdminSection, string, string][]).map(([id, label, icon]) => <button key={id} role="tab" aria-selected={adminSection === id} className={adminSection === id ? "admin-section-tab active" : "admin-section-tab"} onClick={() => setAdminSection(id)}><Icon name={icon} size={16} />{label}</button>)}
        </div>

        {adminSection === "overview" && <>
          <div className="metric-grid six">{[["users", "People", "user"], ["accounts", "Accounts", "mail"], ["totalVisitors", "Total visitors", "users"], ["online", "Online now", "globe"], ["countries", "Countries", "globe"], ["calls", "Calls", "video"], ["activeAds", "Live ads", "ad"]].map(([key, label, icon]) => <div className="metric-card" key={key}><span><Icon name={icon} /></span><strong>{adminData?.summary[key as keyof AdminData["summary"]] ?? "—"}</strong><small>{label}</small></div>)}</div>
          <div className="admin-grid"><section className="admin-panel"><div className="panel-heading"><div><span className="field-label">AT A GLANCE</span><h2>Latest activity</h2></div><span className="activity-live"><i />Live</span></div><div className="activity-feed">{adminData?.activities.length ? adminData.activities.slice(0, 7).map((item) => <div className="activity-item" key={item.id}><span className="activity-icon"><Icon name={item.event.includes("call") ? "video" : item.event.includes("ad") ? "ad" : item.event.includes("notification") ? "bell" : "user"} size={16} /></span><p><b>{item.event.replaceAll("_", " ")}</b><small>{item.userId.slice(0, 8)} · {item.country}</small></p><time>{dateLabel(item.createdAt)}</time></div>) : <div className="admin-empty">Activity will appear as people use Lumina.</div>}</div></section>
          <section className="admin-panel"><div className="panel-heading"><div><span className="field-label">STREAM HEALTH</span><h2>Optimizer</h2></div></div><div className="system-list"><p><Icon name="gauge" size={16} /><span><b>Adaptive bitrate</b><small>Bitrate, frame-rate and resolution adjust to each person’s network in real time.</small></span></p><p><Icon name="video" size={16} /><span><b>Background saver</b><small>Hidden tabs automatically slow polling and drop video to a light stream.</small></span></p><p><Icon name="globe" size={16} /><span><b>{adminData?.summary.online ?? 0} online now</b><small>Presence refreshes every few seconds across the app.</small></span></p></div></section></div>
        </>}

        {adminSection === "people" && <div className="admin-stack">
          <section className="admin-panel"><div className="panel-heading"><div><span className="field-label">SIGN-UP ACCOUNTS</span><h2>Registered people</h2></div><span className="campaign-hint">{adminData?.accounts.length || 0} accounts</span></div><div className="data-table"><div className="table-head"><span>Sign-up email</span><span>Birthday</span><span>Gender</span><span>Joined · last sign-in</span></div>{adminData?.accounts.length ? adminData.accounts.map((account) => <div className="table-row" key={account.id}><span className={onlineUserIds.has(account.id) ? "person-cell online-person" : "person-cell"}><i>{account.name?.slice(0, 1).toUpperCase() || "?"}</i><b>{account.email}<small>{account.name}</small>{onlineUserIds.has(account.id) && <span className="online-name-badge"><i />Online</span>}</b></span><span>{account.dob || "—"}</span><span className={`gender-chip inline ${genderTone(account.gender)}`}>{genderSymbol(account.gender)} {account.gender}</span><span>{dateLabel(account.createdAt)}<small>Last sign-in {dateLabel(account.lastLoginAt)}</small></span></div>) : <div className="admin-empty">No sign-up accounts yet.</div>}</div></section>
          <section className="admin-panel"><div className="panel-heading"><div><span className="field-label">PROFILE DIRECTORY</span><h2>People & locations</h2></div><label className="search-box"><Icon name="search" size={17} /><input value={adminEmail} onChange={(event) => setAdminEmail(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") void loadAdmin(); }} placeholder="Find by email" /></label></div><div className="data-table"><div className="table-head"><span>Person</span><span>Profile</span><span>Country</span><span>Updated</span></div>{adminData?.users.length ? adminData.users.map((person) => <div className="table-row" key={person.userId}><span className={onlineUserIds.has(person.userId) ? "person-cell online-person" : "person-cell"}><i>{person.name?.slice(0, 1).toUpperCase() || "?"}</i><b>{person.email || "No email"}<small>{person.name || "Unnamed"}</small>{onlineUserIds.has(person.userId) && <span className="online-name-badge"><i />Online</span>}</b></span><span>{person.gender || "—"}<small>{person.dob || "No DOB"}</small></span><span>{countryWithFlag(person.country, person.countryCode)}</span><span>{dateLabel(person.updatedAt as unknown as string)}</span></div>) : <div className="admin-empty">No people found.</div>}</div></section>
        </div>}

        {adminSection === "activity" && <section className="admin-panel"><div className="panel-heading"><div><span className="field-label">LIVE AUDIT</span><h2>All recent activity</h2></div><span className="activity-live"><i />Updating</span></div><div className="activity-feed">{adminData?.activities.length ? adminData.activities.slice(0, 25).map((item) => <div className="activity-item" key={item.id}><span className="activity-icon"><Icon name={item.event.includes("call") ? "video" : item.event.includes("ad") ? "ad" : item.event.includes("notification") ? "bell" : "user"} size={16} /></span><p><b>{item.event.replaceAll("_", " ")}</b><small>{item.userId.slice(0, 8)} · {item.country}</small></p><time>{dateLabel(item.createdAt)}</time></div>) : <div className="admin-empty">Activity will appear as people use Lumina.</div>}</div></section>}

        {adminSection === "ads" && <section className="admin-panel campaign-panel flat"><div className="panel-heading"><div><span className="field-label">ADVERTISING</span><h2>Create a campaign</h2></div><span className="campaign-hint">Any ratio · image loops forever · video 3–30s loops</span></div>
          <form className="campaign-form" onSubmit={(event) => void saveAd(event)}>
            <label>Title<input required maxLength={120} value={adForm.title} onChange={(event) => setAdForm((current) => ({ ...current, title: event.target.value }))} placeholder="A short campaign title" /></label>
            <label>Media URL <small>(or upload from gallery)</small><input type="text" value={adForm.mediaUrl.startsWith("data:") ? "" : adForm.mediaUrl} onChange={(event) => { setAdForm((current) => ({ ...current, mediaUrl: event.target.value })); setAdFileName(""); }} placeholder={adFileName ? `Uploaded: ${adFileName}` : "https://..."} /></label>
            <label>Destination URL <small>(optional)</small><input type="url" value={adForm.linkUrl} onChange={(event) => setAdForm((current) => ({ ...current, linkUrl: event.target.value }))} placeholder="https://..." /></label>
            <div className="ad-options">
              <button type="button" className="upload-button" onClick={() => adFileRef.current?.click()}><Icon name="upload" size={17} />Upload image / video</button>
              <input ref={adFileRef} type="file" accept="image/*,video/*" className="file-hidden" onChange={(event) => { void handleAdFile(event.target.files?.[0]); event.target.value = ""; }} />
              <label>Border accent<input type="color" value={adForm.borderColor} onChange={(event) => setAdForm((current) => ({ ...current, borderColor: event.target.value }))} /></label>
              <button className="secondary-cta" type="submit"><Icon name="ad" size={18} />Publish campaign</button>
            </div>
            {adForm.mediaUrl && <div className="ad-upload-preview" style={{ borderColor: adForm.borderColor }}>{adForm.mediaType === "video" ? <video src={adForm.mediaUrl} muted loop autoPlay playsInline /> : <img src={adForm.mediaUrl} alt="Campaign preview" />}<span>{adFileName || "Linked media"}{adDuration ? ` · ${adDuration}s loop` : adForm.mediaType === "image" ? " · loops forever" : ""}</span></div>}
          </form>
          <div className="campaign-list">{adminData?.ads.length ? adminData.ads.map((ad) => <div className="campaign-row" key={ad.id}><div className="campaign-thumb" style={{ borderColor: ad.borderColor }}>{ad.mediaType === "video" ? <span><Icon name="play" size={17} /></span> : <img src={ad.mediaUrl} alt="" />}</div><div><b>{ad.title}</b><small>{ad.mediaType}{ad.durationSeconds ? ` · ${ad.durationSeconds}s` : ""} · {dateLabel(ad.createdAt)}</small></div><button onClick={() => void toggleAd(ad)} className={ad.active ? "status-toggle live" : "status-toggle"}>{ad.active ? "Showing" : "Hidden"}</button><button className="remove-ad" onClick={() => void deleteAd(ad)} aria-label={`Remove ${ad.title}`}><Icon name="trash" size={18} /></button></div>) : <div className="admin-empty">No campaigns yet. Published ads appear in the 1:1 showcase at the bottom of the home page.</div>}</div>
        </section>}

        {adminSection === "notifications" && <div className="admin-stack">
          <section className="admin-panel"><div className="panel-heading"><div><span className="field-label">NOTIFICATIONS</span><h2>Send an update</h2></div><span className="campaign-hint">Text + optional image</span></div>
            <form className="campaign-form notif-form" onSubmit={(event) => void sendNotification(event)}>
              <div className="notif-target">
                <span className="notif-target-label">Send to</span>
                <div className="recipient-combobox">
                  <label className="search-box wide recipient-search">
                    <Icon name="search" size={17} />
                    <input
                      value={notifTargetSearch}
                      onChange={(event) => handleNotifTargetSearch(event.target.value)}
                      onFocus={() => setNotifSuggestOpen(Boolean(notifTargetSearch.trim()))}
                      onBlur={() => window.setTimeout(() => setNotifSuggestOpen(false), 140)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter") {
                          event.preventDefault();
                          const exact = notifCandidates.find((person) => person.email.toLowerCase() === notifTargetSearch.trim().toLowerCase());
                          if (exact) selectNotifCandidate(exact);
                          else if (notifSuggestions.length === 1) selectNotifCandidate(notifSuggestions[0]);
                        }
                        if (event.key === "Escape") setNotifSuggestOpen(false);
                      }}
                      placeholder="Everyone, or search / paste a registered email…"
                      autoComplete="off"
                    />
                    {notifTargetSearch && <button type="button" className="recipient-clear" aria-label="Clear recipient search" onMouseDown={(event) => { event.preventDefault(); handleNotifTargetSearch(""); setNotifSuggestOpen(false); }}><Icon name="close" size={14} /></button>}
                  </label>
                  {notifSuggestOpen && notifQuery && <div className="recipient-suggestions" role="listbox" aria-label="Registered account suggestions">
                    {notifSuggestions.length ? notifSuggestions.map((person) => (
                      <button type="button" role="option" aria-selected={notifForm.target === person.id} key={person.id} className="recipient-suggestion" onMouseDown={(event) => { event.preventDefault(); selectNotifCandidate(person); }}>
                        <span className="activity-icon"><Icon name="user" size={15} /></span>
                        <p><b>{person.email}</b><small>{person.name || "Registered account"}</small></p>
                        <span className="recipient-select-label">Select</span>
                      </button>
                    )) : <div className="recipient-none">No registered account matches “{notifTargetSearch.trim()}”. Paste the exact registered email or check the spelling.</div>}
                  </div>}
                </div>
                <div className="recipient-selection">
                  {notifForm.target === "all"
                    ? <><Icon name="bell" size={14} /><span>Sending to <b>Everyone</b></span></>
                    : <><Icon name="check" size={14} /><span>Sending only to <b>{selectedTargetLabel}</b></span><button type="button" onClick={() => handleNotifTargetSearch("")}>Everyone instead</button></>}
                </div>
                <label className="notif-count">How many copies?
                  <span className="notif-count-input"><input type="number" min={1} step={1} inputMode="numeric" value={notifCount} onChange={(event) => setNotifCount(event.target.value.replace(/[^0-9]/g, ""))} aria-label="How many notification copies to send" /><small>copies</small></span>
                  <small className="notif-count-help">1 is normal. Type any number to send that many copies in the inbox and that many separate alerts in the user’s device notification bar (when notification permission is allowed).</small>
                </label>
              </div>
              <label>Title<input required maxLength={200} value={notifForm.title} onChange={(event) => setNotifForm((current) => ({ ...current, title: event.target.value }))} placeholder="Something lovely is happening" /></label>
              <label>Image URL <small>(optional)</small><input type="text" value={notifForm.imageUrl.startsWith("data:") ? "" : notifForm.imageUrl} onChange={(event) => setNotifForm((current) => ({ ...current, imageUrl: event.target.value, imageName: "" }))} placeholder={notifForm.imageName ? `Uploaded: ${notifForm.imageName}` : "https://..."} /></label>
              <label className="notif-body">Message<textarea value={notifForm.body} onChange={(event) => setNotifForm((current) => ({ ...current, body: event.target.value }))} maxLength={1000} placeholder="Write a warm message — send as many as you like, each lives for 24 hours…" rows={3} /></label>
              <div className="ad-options"><button type="button" className="upload-button" onClick={() => notifImageRef.current?.click()}><Icon name="upload" size={17} />Upload image</button><input ref={notifImageRef} type="file" accept="image/*" className="file-hidden" onChange={(event) => { void handleNotifImage(event.target.files?.[0]); event.target.value = ""; }} />{notifForm.imageUrl && <img className="notif-thumb" src={notifForm.imageUrl} alt="Notification attachment" />}<button className="secondary-cta" type="submit"><Icon name="bell" size={17} />Send notification</button></div>
            </form>
          </section>
          <section className="admin-panel notification-history-panel">
            <div className="panel-heading notification-history-head">
              <div><span className="field-label">HISTORY</span><h2>Sent notifications</h2><small className="history-subtext">Select any notification, select all, or clean the whole history.</small></div>
              <span className="campaign-hint">{adminNotifications.length} saved</span>
            </div>
            {adminNotifications.length ? <>
              <div className="notification-bulkbar">
                <label className="bulk-select"><input type="checkbox" checked={allAdminNotifsSelected} onChange={(event) => setSelectedNotifIds(event.target.checked ? new Set(adminNotifications.map((item) => item.id)) : new Set())} /><span>Select all</span></label>
                <span>{selectedNotifIds.size} selected</span>
                <button type="button" className="bulk-delete" disabled={!selectedNotifIds.size} onClick={() => void deleteAdminNotifications([...selectedNotifIds])}><Icon name="trash" size={15} />Delete selected</button>
                <button type="button" className="bulk-delete danger" onClick={() => void deleteAdminNotifications([], true)}><Icon name="trash" size={15} />Delete all</button>
              </div>
              <div className="notification-admin-list">
                {adminNotifications.map((item) => (
                  <div className={selectedNotifIds.has(item.id) ? "notification-admin-row selected" : "notification-admin-row"} key={item.id}>
                    <label className="notif-check" aria-label={`Select notification ${item.title}`}><input type="checkbox" checked={selectedNotifIds.has(item.id)} onChange={() => toggleAdminNotification(item.id)} /></label>
                    <span className="activity-icon"><Icon name="bell" size={16} /></span>
                    <p><b>{item.title}</b><small>{item.targetUserId ? "One person" : "Everyone"} · {item.body.slice(0, 90) || "No message"}</small></p>
                    <time>{dateLabel(item.createdAt)}</time>
                    <button type="button" className="remove-ad notification-remove" onClick={() => void deleteAdminNotifications([item.id])} aria-label={`Delete notification ${item.title}`} title="Delete this notification"><Icon name="trash" size={17} /></button>
                  </div>
                ))}
              </div>
            </> : <div className="admin-empty">No notifications sent yet.</div>}
          </section>
        </div>}

        {adminSection === "messages" && <div className="support-admin-grid">
          <section className="admin-panel support-threads-panel">
            <div className="panel-heading"><div><span className="field-label">ADMIN INBOX</span><h2>User conversations</h2></div><span className="campaign-hint">{supportConversations.length} chats</span></div>
            <div className="support-thread-list">
              {supportConversations.length ? supportConversations.map((conversation) => (
                <button type="button" key={conversation.userId} className={`${selectedSupportId === conversation.userId ? "support-thread selected" : "support-thread"}${onlineUserIds.has(conversation.userId) ? " online-thread" : ""}`} onClick={() => void selectSupportConversation(conversation)}>
                  <span className={onlineUserIds.has(conversation.userId) ? "person-cell online-person" : "person-cell"}><i>{conversation.name.slice(0, 1).toUpperCase() || "?"}</i><p><b>{conversation.name}</b><small>{conversation.email || conversation.userId.slice(0, 8)}</small>{onlineUserIds.has(conversation.userId) && <span className="online-name-badge"><i />Online</span>}</p></span>
                  <span className="support-thread-meta"><small>{countryWithFlag(conversation.country, conversation.countryCode)}</small>{conversation.unread > 0 && <span className="support-unread">{conversation.unread}</span>}</span>
                </button>
              )) : <div className="admin-empty">No user messages yet. Conversations from Admin Chat will appear here.</div>}
            </div>
          </section>
          <section className="admin-panel support-chat-panel">
            <div className="panel-heading"><div><span className="field-label">CONVERSATION</span><h2>{selectedConversation ? selectedConversation.name : "Choose a chat"}</h2></div>{selectedConversation && <span className="conversation-actions"><span className="campaign-hint">{selectedConversation.email}</span><button type="button" className="bulk-delete danger" onClick={() => void deleteSupportConversation()}><Icon name="trash" size={14} />Delete chat</button></span>}</div>
            {selectedConversation ? <>
              <div className="support-messages admin-support-messages" ref={adminSupportScrollRef}>
                {selectedConversation.messages.map((message) => (
                  <div className={message.senderRole === "admin" ? "support-message mine admin-message" : "support-message theirs admin-message"} key={message.id}>
                    <button type="button" className="message-delete" onClick={() => void deleteSupportMessage(message.id)} aria-label="Delete this message" title="Delete this message"><Icon name="trash" size={13} /></button>
                    {message.imageUrl && <img src={message.imageUrl} alt="Shared in Admin Chat" loading="lazy" decoding="async" />}
                    {message.body && <p>{message.body}</p>}
                    <small>{message.senderRole === "admin" ? "Admin" : selectedConversation.name} · {dateLabel(message.createdAt)}</small>
                  </div>
                ))}
              </div>
              {adminReplyImage && <div className="support-image-preview"><img src={adminReplyImage.data} alt="Reply attachment preview" /><div><b>{adminReplyImage.name}</b><small>Ready to send</small></div><button type="button" onClick={() => setAdminReplyImage(null)} aria-label="Remove attachment"><Icon name="close" size={16} /></button></div>}
              <form className="support-composer admin-reply-composer" onSubmit={(event) => void sendAdminReply(event)}>
                <button type="button" className="support-attach" onClick={() => adminSupportFileRef.current?.click()} aria-label="Add image from gallery" title="Add image from gallery"><Icon name="upload" size={19} /></button>
                <input ref={adminSupportFileRef} type="file" accept="image/*" className="file-hidden" onChange={(event) => { void handleSupportImage(event.target.files?.[0], true); event.target.value = ""; }} />
                <input value={adminReplyText} onChange={(event) => setAdminReplyText(event.target.value)} maxLength={2000} placeholder={`Reply to ${selectedConversation.name}…`} aria-label="Reply to user" />
                <button type="submit" className="support-send" disabled={!adminReplyText.trim() && !adminReplyImage} aria-label="Send reply"><Icon name="send" size={18} /></button>
              </form>
            </> : <div className="admin-empty">Select a conversation to read and reply.</div>}
          </section>
        </div>}

        {adminSection === "masks" && <section className="admin-panel campaign-panel flat">
          <div className="panel-heading"><div><span className="field-label">FACE MASKS</span><h2>Tracked PNG masks</h2></div><span className="campaign-hint">Auto face tracking · eye-hole align</span></div>
          <p className="mask-intro">Upload any PNG and publish it. Users choose it from <b>Masks</b> during a call; it auto-detects full, half-face and eye-hole designs, then follows every tracked face. Hidden masks disappear from the user filter list.</p>
          <form className="campaign-form mask-form" onSubmit={(event) => void saveMask(event)}>
            <label>Mask name<input maxLength={80} value={maskForm.name} onChange={(event) => setMaskForm((current) => ({ ...current, name: event.target.value }))} placeholder="e.g. Pink Cat Mask" /></label>
            <div className="ad-options mask-options">
              <button type="button" className="upload-button" onClick={() => maskFileRef.current?.click()}><Icon name="upload" size={17} />Upload PNG mask</button>
              <input ref={maskFileRef} type="file" accept=".png,image/png" className="file-hidden" onChange={(event) => { void handleMaskFile(event.target.files?.[0]); event.target.value = ""; }} />
              <button className="secondary-cta" type="submit" disabled={!maskForm.imageUrl}><Icon name="blur" size={17} />Publish mask</button>
            </div>
            {maskForm.imageUrl && <div className="mask-preview"><img src={maskForm.imageUrl} alt="PNG mask preview" /><span>{maskForm.fileName} · transparent areas and eye holes are detected automatically</span></div>}
          </form>
          <div className="campaign-list mask-list">
            {faceMasks.length ? faceMasks.map((mask) => (
              <div className="campaign-row mask-row" key={mask.id}>
                <div className="mask-thumb"><img src={mask.imageUrl} alt="" /></div>
                <div><b>{mask.name}</b><small>PNG mask · {dateLabel(mask.createdAt)}</small></div>
                <button type="button" onClick={() => void setMaskActive(mask, !mask.active)} className={mask.active ? "status-toggle live" : "status-toggle"}>{mask.active ? "Available" : "Hidden"}</button>
                <button type="button" className="remove-ad" onClick={() => void deleteMask(mask)} aria-label={`Remove ${mask.name}`}><Icon name="trash" size={18} /></button>
              </div>
            )) : <div className="admin-empty">No PNG masks yet. Without a mask, Blur Face uses the strongest built-in full-face concealment.</div>}
          </div>
        </section>}

        {adminSection === "branding" && <section className="admin-panel campaign-panel flat branding-panel">
          <div className="panel-heading"><div><span className="field-label">BRAND & SPLASH</span><h2>One logo everywhere</h2></div><span className="campaign-hint">Header · PWA · Footer · Splash</span></div>
          <p className="mask-intro">Upload one logo and save it once. Lumina uses it in the <b>top brand icon</b>, <b>PWA install icon</b>, <b>bottom footer icon</b>, and — when splash is set to Same Logo — the <b>center of the splash screen</b>. Or choose one different full-screen splash image/GIF/video only.</p>
          <div className="brand-sync-grid four">
            <div className="brand-sync-card"><small>1 · TOP BRAND</small><span className="brand-sync-preview header-preview"><img src={brandDraft?.icon512 || brandIcon} alt="Top brand logo preview" /></span><b>Home header</b></div>
            <div className="brand-sync-card"><small>2 · PWA ICON</small><span className="brand-sync-preview pwa-preview"><img src={brandDraft?.icon512 || brandIcon} alt="PWA icon preview" /></span><b>Install app icon</b></div>
            <div className="brand-sync-card"><small>3 · BOTTOM ICON</small><span className="brand-sync-preview footer-preview"><img src={brandDraft?.icon512 || brandIcon} alt="Footer logo preview" /></span><b>Home footer</b></div>
            <div className="brand-sync-card"><small>4 · SPLASH LOGO</small><span className="brand-sync-preview splash-preview"><img src={splashDraft.mode === "full" && splashDraft.mediaUrl && splashDraft.mediaType !== "video" ? splashDraft.mediaUrl : brandDraft?.icon512 || brandIcon} alt="Splash logo preview" /></span><b>{splashDraft.mode === "full" ? "Full-screen splash" : "Center splash logo"}</b></div>
          </div>
          <div className="brand-actions">
            <button type="button" className="upload-button" onClick={() => brandFileRef.current?.click()}><Icon name="upload" size={17} />Upload new logo</button>
            <input ref={brandFileRef} type="file" accept="image/*" className="file-hidden" onChange={(event) => { void handleBrandFile(event.target.files?.[0]); event.target.value = ""; }} />
            <button type="button" className="secondary-cta" disabled={!brandDraft || brandSaving} onClick={() => void saveBrand()}>{brandSaving ? <span className="button-spinner" /> : <Icon name="check" size={17} />}Save logo to areas 1–3</button>
            <button type="button" className="bulk-delete danger brand-reset" disabled={brandSaving} onClick={() => void resetBrand()}><Icon name="trash" size={15} />Reset default</button>
          </div>
          {brandDraft && <p className="brand-file-note">Ready: <b>{brandDraft.fileName}</b> — save it, then choose Same Logo below if splash should use it too.</p>}

          <div className="splash-admin-box">
            <div className="panel-heading splash-admin-head"><div><span className="field-label">SPLASH SCREEN</span><h2>Opening screen</h2></div><span className="campaign-hint">Logo 1–10s · Media 1–8s</span></div>
            <div className="splash-mode-grid" role="radiogroup" aria-label="Splash screen type">
              <button type="button" role="radio" aria-checked={splashDraft.mode === "logo"} className={splashDraft.mode === "logo" ? "splash-mode selected" : "splash-mode"} onClick={() => setSplashDraft((current) => ({ ...current, mode: "logo", durationSeconds: String(Math.min(10, Math.max(1, Number(current.durationSeconds) || 2))) }))}><img src={brandDraft?.icon512 || brandIcon} alt="" /><b>Same logo</b><small>Saved brand/PWA logo in the center</small></button>
              <button type="button" role="radio" aria-checked={splashDraft.mode === "full"} className={splashDraft.mode === "full" ? "splash-mode selected" : "splash-mode"} onClick={() => setSplashDraft((current) => ({ ...current, mode: "full", durationSeconds: String(Math.min(8, Math.max(1, Number(current.durationSeconds) || 3))) }))}>{splashDraft.mediaUrl && splashDraft.mediaType !== "video" ? <img src={splashDraft.mediaUrl} alt="" /> : <span><Icon name="spark" size={24} /></span>}<b>Different full screen</b><small>One image, GIF or video fills the screen</small></button>
            </div>
            {splashDraft.mode === "full" && <div className="splash-media-row">
              <button type="button" className="upload-button" onClick={() => splashFileRef.current?.click()}><Icon name="upload" size={17} />Upload image / GIF / video</button>
              <input ref={splashFileRef} type="file" accept="image/*,video/*" className="file-hidden" onChange={(event) => { void handleSplashFile(event.target.files?.[0]); event.target.value = ""; }} />
              {splashDraft.mediaUrl && <span className="splash-media-preview">{splashDraft.mediaType === "video" ? <video src={splashDraft.mediaUrl} muted loop autoPlay playsInline /> : <img src={splashDraft.mediaUrl} alt="Splash media preview" />}</span>}
              {splashDraft.fileName && <small>{splashDraft.fileName}</small>}
            </div>}
            <label className="splash-duration">Show for
              <span><input type="number" min={1} max={splashDraft.mode === "logo" ? 10 : 8} step={1} value={splashDraft.durationSeconds} onChange={(event) => setSplashDraft((current) => ({ ...current, durationSeconds: event.target.value.replace(/[^0-9]/g, "") }))} /> seconds</span>
              <small>{splashDraft.mode === "logo" ? "Choose 1–10 seconds." : "Choose 1–8 seconds."}</small>
            </label>
            <div className="brand-actions splash-actions">
              <button type="button" className="secondary-cta" disabled={splashSaving} onClick={() => void saveSplash()}>{splashSaving ? <span className="button-spinner" /> : <Icon name="check" size={17} />}Save splash</button>
              <button type="button" className="upload-button" onClick={previewSplash}><Icon name="eye" size={17} />Preview</button>
              <button type="button" className="bulk-delete danger brand-reset" disabled={splashSaving} onClick={() => void deleteSplash()}><Icon name="trash" size={15} />Delete splash</button>
            </div>
          </div>
        </section>}

        {adminSection === "system" && <section className="admin-panel"><div className="panel-heading"><div><span className="field-label">OPTIMIZER & SYSTEM</span><h2>Built for smooth, light streaming</h2></div><span className="activity-live"><i />Active</span></div>
          <div className="system-list wide">
            <p><Icon name="gauge" size={17} /><span><b>Adaptive stream optimizer</b><small>Every call is measured live (ping, frame-rate, bandwidth). Bitrate, resolution scale and frame-rate glide up or down so motion stays smooth without loading the Wi-Fi.</small></span></p>
            <p><Icon name="video" size={17} /><span><b>Background slow-down</b><small>When Lumina is in a background tab, polling slows, ad rotation pauses and the sent video drops to a light saver stream automatically.</small></span></p>
            <p><Icon name="blur" size={17} /><span><b>Full face concealment + masks</b><small>Tracked faces are fully concealed on-device; an active admin PNG mask follows each face and auto-aligns detected eye holes.</small></span></p>
            <p><Icon name="mail" size={17} /><span><b>Admin Chat</b><small>Users can message Admin with gallery images from the Admin Chat page; replies return to the same private thread.</small></span></p>
            <p><Icon name="gauge" size={17} /><span><b>Scale-ready smoothness</b><small>Indexed notification/support/signal queries, chunked bulk sends, long-poll delivery, visibility-aware polling and cached PWA assets keep the experience light.</small></span></p>
            <p><Icon name="users" size={17} /><span><b>Visitors & flags</b><small>{new Intl.NumberFormat().format(adminData?.summary.totalVisitors ?? totalVisitors)} unique device visitors tracked by privacy-safe IP/device fingerprints, with IP country flags for all countries.</small></span></p>
            <p><Icon name="download" size={17} /><span><b>Offline-ready PWA</b><small>The app shell, manifest and icons are cached for offline opening; live matching and chat resume automatically when the connection returns.</small></span></p>
            <p><Icon name="bell" size={17} /><span><b>Notifications</b><small>New visitors are invited to allow notifications; updates then arrive in-app and as system notifications.</small></span></p>
            <p><Icon name="download" size={17} /><span><b>Installable PWA</b><small>Lumina installs from the browser on phone and desktop, with its own icon and pink theme.</small></span></p>
          </div>
        </section>}
      </section> : <section className="page restricted-page"><div className="restricted-card"><span><Icon name="shield" size={32} /></span><h1>Administrator access only.</h1><p>The control room is visible only to the Lumina administrator account.</p><button className="secondary-cta" onClick={() => setTab("connect")}>Back to Connect</button></div></section>)}

      <footer><LuminaLogo compact iconUrl={brandIcon} /><span>© {new Date().getFullYear()} Lumina Connect</span><span className="footer-dot">•</span><span>Real people. Real moments.</span><span className="footer-spacer" /><button onClick={() => void installApp()}><Icon name="download" size={15} />Install app</button></footer>
    </main>
  );
}
