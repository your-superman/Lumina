import { getBrandSetting } from "@/lib/brand";

export const dynamic = "force-dynamic";

export async function GET() {
  const brand = await getBrandSetting();
  const version = brand.updatedAt ? encodeURIComponent(brand.updatedAt) : "default";
  const icon = (size: 192 | 512) => `/api/brand/icon?size=${size}&v=${version}`;

  return Response.json({
    name: "Lumina Connect",
    short_name: "Lumina",
    description: "Real people. Real moments. Instant video connection.",
    id: "/",
    scope: "/",
    start_url: "/",
    display: "standalone",
    background_color: "#fff8fc",
    theme_color: "#FC84BD",
    icons: [
      { src: icon(192), sizes: "192x192", type: "image/png", purpose: "any" },
      { src: icon(512), sizes: "512x512", type: "image/png", purpose: "any" },
      { src: icon(512), sizes: "512x512", type: "image/png", purpose: "maskable" },
      { src: "/lumina-icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" },
    ],
  }, {
    headers: {
      "Content-Type": "application/manifest+json",
      "Cache-Control": "no-store, max-age=0",
    },
  });
}
