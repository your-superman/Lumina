import { desc, gt } from "drizzle-orm";
import { db } from "@/db";
import { accounts, activityLogs, advertisements, callSessions, notifications, presence, profiles, visitors } from "@/db/schema";
import { isAdmin } from "@/lib/app";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const userId = url.searchParams.get("userId") || "";
  if (!(await isAdmin(userId))) return Response.json({ error: "Administrator access required." }, { status: 403 });
  const emailQuery = (url.searchParams.get("email") || "").trim().toLowerCase();

  const allProfiles = await db.select().from(profiles).orderBy(desc(profiles.updatedAt)).limit(200);
  const users = emailQuery ? allProfiles.filter((profile) => profile.email.toLowerCase().includes(emailQuery)) : allProfiles;
  const [activities, ads, sessions, accountRows, sentNotifications, onlineRows, totalVisitors] = await Promise.all([
    db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(250),
    db.select().from(advertisements).orderBy(desc(advertisements.createdAt)).limit(100),
    db.select().from(callSessions).orderBy(desc(callSessions.startedAt)).limit(200),
    db.select({
      id: accounts.id, email: accounts.email, name: accounts.name, dob: accounts.dob,
      gender: accounts.gender, country: accounts.country, countryCode: accounts.countryCode, createdAt: accounts.createdAt, lastLoginAt: accounts.lastLoginAt,
    }).from(accounts).orderBy(desc(accounts.createdAt)).limit(200),
    db.select().from(notifications).orderBy(desc(notifications.createdAt)).limit(500),
    db.select({ userId: presence.userId }).from(presence).where(gt(presence.lastSeen, new Date(Date.now() - 45_000))),
    db.$count(visitors),
  ]);

  return Response.json({
    summary: {
      users: allProfiles.length,
      countries: new Set(allProfiles.map((profile) => profile.country).filter((country) => country !== "Unknown")).size,
      calls: sessions.length,
      activeAds: ads.filter((ad) => ad.active).length,
      online: onlineRows.length,
      accounts: accountRows.length,
      totalVisitors,
    },
    onlineUserIds: onlineRows.map((row) => row.userId),
    users,
    accounts: accountRows,
    activities,
    ads,
    notifications: sentNotifications,
  });
}
