import { createHash } from "crypto";
import { eq, gt, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import { presence, profiles, visitors } from "@/db/schema";
import { countryCodeFromName, profileForUser, visitorCountry, visitorCountryCode } from "@/lib/app";

export const dynamic = "force-dynamic";

async function counts() {
  const cutoff = new Date(Date.now() - 45_000);
  const [online, totalVisitors] = await Promise.all([
    db.$count(presence, gt(presence.lastSeen, cutoff)),
    db.$count(visitors),
  ]);
  return { online, totalVisitors };
}

function clientIp(request: Request) {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  return (
    forwarded ||
    request.headers.get("cf-connecting-ip") ||
    request.headers.get("x-real-ip") ||
    ""
  ).trim();
}

function deviceInfo(request: Request) {
  const ua = request.headers.get("user-agent") || "";
  const lower = ua.toLowerCase();
  const isTablet = /ipad|tablet|tab\b|sm-t|nexus 7|nexus 9|kindle|silk/.test(lower) || (lower.includes("android") && !lower.includes("mobile"));
  const isMobile = !isTablet && (/iphone|ipod|android.*mobile|windows phone|mobile|opera mini|iemobile/.test(lower));
  const deviceType = /bot|crawler|spider/.test(lower) ? "bot" : isTablet ? "tablet" : isMobile ? "mobile" : "desktop";

  let device = "Desktop";
  if (lower.includes("iphone")) device = "iPhone";
  else if (lower.includes("ipad")) device = "iPad";
  else if (lower.includes("android")) device = isTablet ? "Android tablet" : "Android phone";
  else if (lower.includes("windows")) device = "Windows device";
  else if (lower.includes("macintosh") || lower.includes("mac os")) device = "Mac";
  else if (lower.includes("linux")) device = "Linux device";

  let browser = "Browser";
  if (lower.includes("edg/")) browser = "Edge";
  else if (lower.includes("opr/") || lower.includes("opera")) browser = "Opera";
  else if (lower.includes("firefox")) browser = "Firefox";
  else if (lower.includes("chrome") || lower.includes("crios")) browser = "Chrome";
  else if (lower.includes("safari")) browser = "Safari";

  return { deviceType, deviceLabel: `${device} · ${browser}`.slice(0, 80) };
}

async function trackVisitor(request: Request, userId: string, country: string, countryCode: string) {
  const ip = clientIp(request);
  const ua = request.headers.get("user-agent") || "unknown";
  // Store only a one-way device fingerprint hash — never the raw IP address.
  const fingerprint = ip ? `${ip}|${ua}` : `user:${userId}|${ua}`;
  const id = createHash("sha256").update(fingerprint).digest("hex");
  const device = deviceInfo(request);
  const now = new Date();

  await db
    .insert(visitors)
    .values({
      id,
      userId,
      deviceType: device.deviceType,
      deviceLabel: device.deviceLabel,
      country,
      countryCode,
      visits: 1,
      firstSeen: now,
      lastSeen: now,
    })
    .onConflictDoUpdate({
      target: visitors.id,
      set: {
        userId,
        deviceType: device.deviceType,
        deviceLabel: device.deviceLabel,
        country,
        countryCode,
        visits: sql`case when ${visitors.lastSeen} < now() - interval '30 minutes' then ${visitors.visits} + 1 else ${visitors.visits} end`,
        lastSeen: now,
      },
    });
}

export async function GET() {
  return Response.json(await counts());
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const userId = String(body.userId || "").trim();
    if (!userId) return Response.json(await counts());
    const profile = await profileForUser(userId);
    const ipCode = visitorCountryCode(request);
    const country = ipCode ? visitorCountry(request) : profile?.country || visitorCountry(request);
    const countryCode = ipCode || profile?.countryCode || countryCodeFromName(country);
    // Backfill the profile's flag once, so existing members get their country
    // automatically on their next visit (no profile edit needed).
    if (profile && ipCode && !profile.countryCode) {
      await db.update(profiles).set({ country, countryCode }).where(eq(profiles.userId, userId));
    }
    await trackVisitor(request, userId, country, countryCode);

    await db
      .insert(presence)
      .values({
        userId,
        name: profile?.name || "",
        gender: profile?.gender || "",
        country,
        countryCode,
        lastSeen: new Date(),
      })
      .onConflictDoUpdate({
        target: presence.userId,
        set: {
          name: profile?.name || "",
          gender: profile?.gender || "",
          country,
          countryCode,
          lastSeen: new Date(),
        },
      });
    // Opportunistic cleanup keeps the table tiny and the count honest.
    await db.delete(presence).where(lt(presence.lastSeen, new Date(Date.now() - 5 * 60_000)));
    return Response.json(await counts());
  } catch {
    return Response.json({ online: 0, totalVisitors: 0 }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const userId = new URL(request.url).searchParams.get("userId") || "";
  if (userId) await db.delete(presence).where(eq(presence.userId, userId));
  return Response.json({ ok: true });
}
