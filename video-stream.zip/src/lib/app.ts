import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { activityLogs, profiles } from "@/db/schema";

export const ADMIN_EMAIL = "mirzaahmed20042004@gmail.com";

/** ISO 3166-1 alpha-2 code from the visitor's IP, via CDN/proxy geo headers. */
export function visitorCountryCode(request: Request) {
  const raw =
    request.headers.get("x-vercel-ip-country") ||
    request.headers.get("cf-ipcountry") ||
    request.headers.get("x-country-code") ||
    request.headers.get("x-appengine-country") ||
    request.headers.get("x-country") ||
    "";
  const code = raw.trim().toUpperCase();
  return /^[A-Z]{2}$/.test(code) ? code : "";
}

let displayNames: Intl.DisplayNames | null = null;
function regionNames() {
  if (!displayNames) {
    try { displayNames = new Intl.DisplayNames(["en"], { type: "region" }); } catch { displayNames = null; }
  }
  return displayNames;
}

/** "PK" -> "Pakistan" for every country in the world (platform region data). */
export function countryNameFromCode(code: string) {
  const clean = (code || "").trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(clean)) return "";
  try { return regionNames()?.of(clean) || clean; } catch { return clean; }
}

let codeByName: Map<string, string> | null = null;
/** "Pakistan" -> "PK" (reverse lookup across all ISO codes, built once). */
export function countryCodeFromName(name: string) {
  const clean = (name || "").trim();
  if (/^[A-Z]{2}$/i.test(clean)) return clean.toUpperCase();
  if (!clean || clean === "Unknown") return "";
  if (!codeByName) {
    codeByName = new Map();
    const names = regionNames();
    if (names) {
      for (let a = 65; a <= 90; a++) {
        for (let b = 65; b <= 90; b++) {
          const code = String.fromCharCode(a, b);
          try {
            const label = names.of(code);
            if (label && label !== code) codeByName.set(label.toLowerCase(), code);
          } catch { /* not a real region code */ }
        }
      }
    }
  }
  return codeByName.get(clean.toLowerCase()) || "";
}

export function visitorCountry(request: Request) {
  const code = visitorCountryCode(request);
  if (code) return countryNameFromCode(code) || code;
  const named = (request.headers.get("x-country") || "").trim();
  return (named && !/^[A-Z]{2}$/i.test(named) ? named : "Unknown").slice(0, 80);
}

export async function logActivity(
  userId: string,
  event: string,
  country = "Unknown",
  detail: Record<string, unknown> = {},
) {
  if (!userId) return;
  await db.insert(activityLogs).values({ userId, event, country, detail });
}

export async function isAdmin(userId: string) {
  if (!userId) return false;
  const [profile] = await db
    .select({ email: profiles.email })
    .from(profiles)
    .where(eq(profiles.userId, userId))
    .limit(1);
  return profile?.email.toLowerCase() === ADMIN_EMAIL;
}

export async function profileForUser(userId: string) {
  const [profile] = await db
    .select()
    .from(profiles)
    .where(eq(profiles.userId, userId))
    .limit(1);
  return profile;
}

export async function recentActivity(userId: string) {
  return db
    .select()
    .from(activityLogs)
    .where(and(eq(activityLogs.userId, userId)))
    .orderBy(desc(activityLogs.createdAt))
    .limit(25);
}
