import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appSettings } from "@/db/schema";

export type BrandSetting = {
  icon192: string;
  icon512: string;
  updatedAt: string | null;
};

export type SplashSetting = {
  mode: "logo" | "full";
  mediaType: "image" | "gif" | "video";
  mediaUrl: string;
  durationSeconds: number;
  updatedAt: string | null;
};

export const defaultSplash: SplashSetting = {
  mode: "logo",
  mediaType: "image",
  mediaUrl: "",
  durationSeconds: 2,
  updatedAt: null,
};

const emptyBrand: BrandSetting = { icon192: "", icon512: "", updatedAt: null };

export async function getBrandSetting(): Promise<BrandSetting> {
  try {
    const [row] = await db.select().from(appSettings).where(eq(appSettings.key, "brand")).limit(1);
    const value = (row?.value || {}) as Partial<BrandSetting>;
    return {
      icon192: typeof value.icon192 === "string" ? value.icon192 : "",
      icon512: typeof value.icon512 === "string" ? value.icon512 : "",
      updatedAt: row?.updatedAt ? row.updatedAt.toISOString() : null,
    };
  } catch {
    return emptyBrand;
  }
}

export async function getSplashSetting(): Promise<SplashSetting> {
  try {
    const [row] = await db.select().from(appSettings).where(eq(appSettings.key, "splash")).limit(1);
    const value = (row?.value || {}) as Partial<SplashSetting>;
    const mode = value.mode === "full" ? "full" : "logo";
    const mediaType = value.mediaType === "video" ? "video" : value.mediaType === "gif" ? "gif" : "image";
    const durationFallback = mode === "logo" ? 10 : 8;
    const durationSeconds = Math.min(durationFallback, Math.max(1, Math.floor(Number(value.durationSeconds) || defaultSplash.durationSeconds)));
    return {
      mode,
      mediaType,
      mediaUrl: typeof value.mediaUrl === "string" ? value.mediaUrl : "",
      durationSeconds,
      updatedAt: row?.updatedAt ? row.updatedAt.toISOString() : null,
    };
  } catch {
    return defaultSplash;
  }
}

export function validSplashMedia(value: unknown, mediaType: string) {
  const url = String(value || "").trim();
  if (!url) return "";
  if (mediaType === "video") {
    if (url.startsWith("data:video/") && url.length < 30_000_000) return url;
  } else if (url.startsWith("data:image/") && url.length < 16_000_000) {
    return url;
  }
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.toString() : "";
  } catch {
    return "";
  }
}

export function brandIconBytes(dataUrl: string) {
  const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || "");
  if (!match) return null;
  return { contentType: match[1], bytes: Buffer.from(match[2], "base64") };
}

export function validBrandImage(value: unknown) {
  const url = String(value || "").trim();
  if (!url) return "";
  if (/^data:image\/(png|jpeg|webp);base64,/.test(url) && url.length < 6_000_000 && brandIconBytes(url)) return url;
  return "";
}
