import { and, asc, desc, eq } from "drizzle-orm";
import { randomUUID } from "crypto";
import { db } from "@/db";
import { accounts, profiles, supportMessages } from "@/db/schema";
import { isAdmin, logActivity, profileForUser } from "@/lib/app";

export const dynamic = "force-dynamic";

function validImage(value: unknown) {
  const url = String(value || "").trim();
  if (!url) return "";
  if (url.startsWith("data:image/") && url.length < 5_000_000) return url;
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.toString() : "";
  } catch {
    return "";
  }
}

type SupportRow = typeof supportMessages.$inferSelect;

async function hasRegisteredAccount(userId: string) {
  const [account] = await db.select({ id: accounts.id }).from(accounts).where(eq(accounts.id, userId)).limit(1);
  return Boolean(account);
}

function lockedResponse() {
  return Response.json(
    { error: "Admin Chat is locked. Please sign up or sign in with your email account to message Admin.", locked: true },
    { status: 403 },
  );
}

function publicMessage(row: SupportRow) {
  return {
    id: row.id,
    userId: row.userId,
    senderId: row.senderId,
    senderRole: row.senderRole,
    body: row.body,
    imageUrl: row.imageUrl,
    readByAdmin: row.readByAdmin,
    readByUser: row.readByUser,
    createdAt: row.createdAt,
  };
}

export async function GET(request: Request) {
  const userId = new URL(request.url).searchParams.get("userId") || "";
  if (!userId) return Response.json({ error: "userId is required" }, { status: 400 });
  const admin = await isAdmin(userId);

  if (!admin) {
    if (!(await hasRegisteredAccount(userId))) return lockedResponse();
    const rows = await db
      .select()
      .from(supportMessages)
      .where(eq(supportMessages.userId, userId))
      .orderBy(asc(supportMessages.createdAt))
      .limit(200);
    return Response.json({ admin: false, messages: rows.map(publicMessage) });
  }

  const [rows, profileRows, accountRows] = await Promise.all([
    db.select().from(supportMessages).orderBy(desc(supportMessages.createdAt)).limit(600),
    db.select().from(profiles).limit(500),
    db.select().from(accounts).limit(500),
  ]);
  const people = new Map<string, { name: string; email: string; country: string; countryCode: string }>();
  profileRows.forEach((person) => people.set(person.userId, {
    name: person.name || "Lumina user",
    email: person.email || "",
    country: person.country || "Unknown",
    countryCode: person.countryCode || "",
  }));
  accountRows.forEach((account) => people.set(account.id, {
    name: account.name || people.get(account.id)?.name || "Lumina user",
    email: account.email || people.get(account.id)?.email || "",
    country: account.country || people.get(account.id)?.country || "Unknown",
    countryCode: account.countryCode || people.get(account.id)?.countryCode || "",
  }));

  const grouped = new Map<string, SupportRow[]>();
  rows.forEach((row) => {
    const list = grouped.get(row.userId) || [];
    list.push(row);
    grouped.set(row.userId, list);
  });

  const conversations = [...grouped.entries()].map(([threadUserId, threadRows]) => {
    const messages = [...threadRows].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime()).map(publicMessage);
    const person = people.get(threadUserId);
    return {
      userId: threadUserId,
      name: person?.name || "Lumina user",
      email: person?.email || "",
      country: person?.country || "Unknown",
      countryCode: person?.countryCode || "",
      unread: threadRows.filter((row) => row.senderRole === "user" && !row.readByAdmin).length,
      lastMessageAt: messages[messages.length - 1]?.createdAt,
      messages,
    };
  }).sort((a, b) => new Date(b.lastMessageAt || 0).getTime() - new Date(a.lastMessageAt || 0).getTime());

  return Response.json({ admin: true, conversations });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const userId = String(body.userId || "").trim();
    if (!userId) return Response.json({ error: "userId is required" }, { status: 400 });
    const action = String(body.action || "send");
    const admin = await isAdmin(userId);

    if (action === "markRead") {
      if (admin) {
        const targetUserId = String(body.targetUserId || "").trim();
        if (!targetUserId) return Response.json({ error: "targetUserId is required" }, { status: 400 });
        await db.update(supportMessages)
          .set({ readByAdmin: true })
          .where(and(eq(supportMessages.userId, targetUserId), eq(supportMessages.senderRole, "user")));
      } else {
        if (!(await hasRegisteredAccount(userId))) return lockedResponse();
        await db.update(supportMessages)
          .set({ readByUser: true })
          .where(and(eq(supportMessages.userId, userId), eq(supportMessages.senderRole, "admin")));
      }
      return Response.json({ ok: true });
    }

    if (action === "deleteMessage" || action === "deleteConversation") {
      if (!admin) return Response.json({ error: "Administrator access required." }, { status: 403 });
      const profile = await profileForUser(userId);
      if (action === "deleteConversation") {
        const targetUserId = String(body.targetUserId || "").trim();
        if (!targetUserId) return Response.json({ error: "Choose a conversation first." }, { status: 400 });
        const deleted = await db.delete(supportMessages).where(eq(supportMessages.userId, targetUserId)).returning({ id: supportMessages.id });
        await logActivity(userId, "admin_support_conversation_deleted", profile?.country || "Unknown", { targetUserId, count: deleted.length });
        return Response.json({ ok: true, deleted: deleted.length });
      }
      const messageId = String(body.messageId || "").trim();
      if (!messageId) return Response.json({ error: "Choose a message to delete." }, { status: 400 });
      const deleted = await db.delete(supportMessages).where(eq(supportMessages.id, messageId)).returning({ id: supportMessages.id });
      await logActivity(userId, "admin_support_message_deleted", profile?.country || "Unknown", { messageId });
      return Response.json({ ok: true, deleted: deleted.length });
    }

    const text = String(body.body || "").trim().slice(0, 2000);
    const imageUrl = validImage(body.imageUrl);
    if (!text && !imageUrl) return Response.json({ error: "Write a message or attach an image." }, { status: 400 });

    if (action === "reply") {
      if (!admin) return Response.json({ error: "Administrator access required." }, { status: 403 });
      const targetUserId = String(body.targetUserId || "").trim();
      if (!targetUserId) return Response.json({ error: "Choose a conversation first." }, { status: 400 });
      const id = randomUUID();
      const [message] = await db.insert(supportMessages).values({
        id,
        userId: targetUserId,
        senderId: userId,
        senderRole: "admin",
        body: text,
        imageUrl,
        readByAdmin: true,
        readByUser: false,
      }).returning();
      const profile = await profileForUser(userId);
      await logActivity(userId, "admin_support_reply", profile?.country || "Unknown", { targetUserId });
      return Response.json({ ok: true, message: publicMessage(message) });
    }

    if (!(await hasRegisteredAccount(userId))) return lockedResponse();

    const id = randomUUID();
    const [message] = await db.insert(supportMessages).values({
      id,
      userId,
      senderId: userId,
      senderRole: "user",
      body: text,
      imageUrl,
      readByAdmin: false,
      readByUser: true,
    }).returning();
    const profile = await profileForUser(userId);
    await logActivity(userId, "support_message_sent", profile?.country || "Unknown", { hasImage: Boolean(imageUrl) });
    return Response.json({ ok: true, message: publicMessage(message) });
  } catch {
    return Response.json({ error: "Message could not be sent." }, { status: 500 });
  }
}
