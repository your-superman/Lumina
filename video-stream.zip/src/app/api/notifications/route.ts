import { and, desc, eq, gt, inArray, isNull, lt, or } from "drizzle-orm";
import { randomUUID } from "crypto";
import { db } from "@/db";
import { notificationReads, notifications } from "@/db/schema";
import { isAdmin, logActivity, profileForUser } from "@/lib/app";

export const dynamic = "force-dynamic";

const DAY_MS = 24 * 60 * 60 * 1000;

function validImage(value: unknown) {
  const url = String(value || "").trim();
  if (!url) return "";
  if (url.startsWith("data:image/") && url.length < 4_000_000) return url;
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.toString() : "";
  } catch { return ""; }
}

/** Notifications live exactly 24 hours, then disappear for everyone. */
async function purgeExpired() {
  const now = new Date();
  await db.delete(notifications).where(lt(notifications.expiresAt, now));
  // Legacy rows created before expiresAt existed fall back to createdAt + 24h.
  await db.delete(notifications).where(and(isNull(notifications.expiresAt), lt(notifications.createdAt, new Date(now.getTime() - DAY_MS))));
}

async function visibleRows(userId: string) {
  const now = new Date();
  return db
    .select()
    .from(notifications)
    .where(and(
      or(isNull(notifications.targetUserId), eq(notifications.targetUserId, userId)),
      or(gt(notifications.expiresAt, now), and(isNull(notifications.expiresAt), gt(notifications.createdAt, new Date(now.getTime() - DAY_MS)))),
    ))
    .orderBy(desc(notifications.createdAt))
    .limit(500);
}

export async function GET(request: Request) {
  const userId = new URL(request.url).searchParams.get("userId") || "";
  if (!userId) return Response.json({ notifications: [], unread: 0 });
  await purgeExpired();
  const rows = await visibleRows(userId);
  const reads = rows.length
    ? await db.select().from(notificationReads).where(and(
      eq(notificationReads.userId, userId),
      inArray(notificationReads.notificationId, rows.map((row) => row.id)),
    ))
    : [];
  const readIds = new Set(reads.map((row) => row.notificationId));
  const list = rows.map((row) => ({ ...row, read: readIds.has(row.id) }));
  return Response.json({ notifications: list, unread: list.filter((row) => !row.read).length });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const adminId = String(body.userId || "");
    if (!(await isAdmin(adminId))) return Response.json({ error: "Administrator access required." }, { status: 403 });
    const title = String(body.title || "").trim().slice(0, 200);
    const bodyText = String(body.body || "").trim().slice(0, 1000);
    const targetRaw = String(body.targetUserId || "all").trim();
    if (!title) return Response.json({ error: "A notification title is required." }, { status: 400 });
    if (targetRaw !== "all" && !(await profileForUser(targetRaw))) {
      return Response.json({ error: "That registered account was not found. Search and select the exact email." }, { status: 404 });
    }
    const requestedCount = Number(body.count ?? 1);
    const count = Number.isFinite(requestedCount)
      ? Math.min(10_000, Math.max(1, Math.floor(requestedCount)))
      : 1;
    const now = new Date();
    const expiresAt = new Date(now.getTime() + DAY_MS);
    const imageUrl = validImage(body.imageUrl);
    const values = Array.from({ length: count }, () => ({
      id: randomUUID(),
      targetUserId: targetRaw === "all" ? null : targetRaw,
      title,
      body: bodyText,
      imageUrl,
      createdBy: adminId,
      createdAt: now,
      expiresAt,
    }));
    // Chunked inserts keep even very large copy-count sends fast and smooth.
    for (let index = 0; index < values.length; index += 250) {
      await db.insert(notifications).values(values.slice(index, index + 250));
    }
    const profile = await profileForUser(adminId);
    await logActivity(adminId, targetRaw === "all" ? "notification_sent_all" : "notification_sent_user", profile?.country || "Unknown", { notificationId: values[0].id, count });
    return Response.json({ ok: true, id: values[0].id, sent: count });
  } catch {
    return Response.json({ error: "Notification could not be sent." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const adminId = String(body.userId || "");
    if (!(await isAdmin(adminId))) return Response.json({ error: "Administrator access required." }, { status: 403 });

    if (body.all === true) {
      const deleted = await db.delete(notifications).returning({ id: notifications.id });
      await db.delete(notificationReads);
      const profile = await profileForUser(adminId);
      await logActivity(adminId, "notifications_deleted_all", profile?.country || "Unknown", { count: deleted.length });
      return Response.json({ ok: true, deleted: deleted.length });
    }

    const ids = Array.isArray(body.ids)
      ? [...new Set(body.ids.map((id) => String(id)).filter(Boolean))].slice(0, 1000)
      : [];
    if (!ids.length) return Response.json({ error: "Select at least one notification to delete." }, { status: 400 });

    await db.delete(notificationReads).where(inArray(notificationReads.notificationId, ids));
    const deleted = await db.delete(notifications).where(inArray(notifications.id, ids)).returning({ id: notifications.id });
    const profile = await profileForUser(adminId);
    await logActivity(adminId, "notifications_deleted", profile?.country || "Unknown", { count: deleted.length });
    return Response.json({ ok: true, deleted: deleted.length });
  } catch {
    return Response.json({ error: "Notifications could not be deleted." }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  const body = (await request.json()) as Record<string, unknown>;
  const userId = String(body.userId || "");
  const notificationId = String(body.notificationId || "");
  if (!userId) return Response.json({ error: "Missing details." }, { status: 400 });
  if (body.markAll === true) {
    const rows = await visibleRows(userId);
    if (rows.length) {
      await db
        .insert(notificationReads)
        .values(rows.map((row) => ({ notificationId: row.id, userId })))
        .onConflictDoNothing();
    }
    return Response.json({ ok: true, marked: rows.length });
  }
  if (!notificationId) return Response.json({ error: "Missing details." }, { status: 400 });
  await db.insert(notificationReads).values({ notificationId, userId }).onConflictDoNothing();
  return Response.json({ ok: true });
}
