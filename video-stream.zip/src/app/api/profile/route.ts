import { eq } from "drizzle-orm";
import { db } from "@/db";
import { accounts, profiles } from "@/db/schema";
import { countryCodeFromName, logActivity, profileForUser, visitorCountry, visitorCountryCode } from "@/lib/app";

export const dynamic = "force-dynamic";

const validGenders = new Set(["male", "female", "nonbinary", "prefer-not-to-say"]);

export async function GET(request: Request) {
  const userId = new URL(request.url).searchParams.get("userId")?.trim() || "";
  if (!userId) return Response.json({ error: "userId is required" }, { status: 400 });
  return Response.json({ profile: await profileForUser(userId) });
}

export async function PUT(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const userId = String(body.userId || "").trim();
    const name = String(body.name || "").trim();
    const email = String(body.email || "").trim().toLowerCase();
    const dob = String(body.dob || "").trim();
    const gender = String(body.gender || "").trim().toLowerCase();

    if (!userId || !name || !email || !dob || !validGenders.has(gender)) {
      return Response.json({ error: "Please complete all profile fields." }, { status: 400 });
    }
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      return Response.json({ error: "Enter a valid email address." }, { status: 400 });
    }
    if (new Date(dob).getTime() > Date.now()) {
      return Response.json({ error: "Date of birth cannot be in the future." }, { status: 400 });
    }

    const existing = await profileForUser(userId);
    if (existing?.profileLockedUntil && existing.profileLockedUntil.getTime() > Date.now()) {
      const changed = existing.name !== name || existing.email !== email || existing.dob !== dob || existing.gender !== gender;
      if (changed) {
        return Response.json(
          { error: "Your profile is locked for 24 hours after saving.", lockedUntil: existing.profileLockedUntil },
          { status: 423 },
        );
      }
      return Response.json({ profile: existing });
    }

    const now = new Date();
    const lockedUntil = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    // Country auto-detected from the visitor's IP on every save.
    const ipCode = visitorCountryCode(request);
    const ipCountry = visitorCountry(request);
    const country = ipCode ? ipCountry : existing?.country === "Unknown" ? ipCountry : existing?.country || ipCountry;
    const countryCode = ipCode || countryCodeFromName(country);
    const value = {
      email,
      name,
      dob,
      gender,
      country,
      countryCode,
      profileLockedUntil: lockedUntil,
      updatedAt: now,
    };

    if (existing) {
      await db.update(profiles).set(value).where(eq(profiles.userId, userId));
    } else {
      await db.insert(profiles).values({ userId, ...value, createdAt: now });
    }
    // Keep a linked sign-up account in sync for the admin directory.
    await db.update(accounts).set({ email, name, dob, gender, country, countryCode }).where(eq(accounts.id, userId));

    const profile = await profileForUser(userId);
    await logActivity(userId, existing ? "profile_updated" : "profile_created", profile?.country || country, { gender });
    return Response.json({ profile });
  } catch {
    return Response.json({ error: "Could not save your profile." }, { status: 500 });
  }
}
