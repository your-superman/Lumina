import { and, asc, eq, gt, ne } from "drizzle-orm";
import { db } from "@/db";
import { callSessions, callSignals } from "@/db/schema";

export const dynamic = "force-dynamic";

async function activeMember(sessionId: string, userId: string) {
  const [session] = await db
    .select()
    .from(callSessions)
    .where(and(eq(callSessions.id, sessionId), eq(callSessions.status, "active")))
    .limit(1);
  return session && (session.callerId === userId || session.partnerId === userId) ? session : null;
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export async function GET(request: Request) {
  const url = new URL(request.url);
  const sessionId = url.searchParams.get("sessionId") || "";
  const userId = url.searchParams.get("userId") || "";
  const after = Math.max(0, Number(url.searchParams.get("after") || "0"));
  if (!sessionId || !userId) return Response.json({ error: "Missing session details." }, { status: 400 });
  if (!(await activeMember(sessionId, userId))) return Response.json({ error: "Session not found." }, { status: 403 });

  // Long-poll: one quiet connection delivers new signals within ~200 ms,
  // replacing dozens of battery-hungry interval requests per minute.
  const wait = url.searchParams.get("wait") === "1";
  const deadline = Date.now() + (wait ? 9000 : 0);
  for (;;) {
    const signals = await db
      .select({ id: callSignals.id, kind: callSignals.kind, payload: callSignals.payload, createdAt: callSignals.createdAt })
      .from(callSignals)
      .where(and(eq(callSignals.sessionId, sessionId), ne(callSignals.senderId, userId), gt(callSignals.id, after)))
      .orderBy(asc(callSignals.id))
      .limit(80);
    if (signals.length > 0 || Date.now() >= deadline) return Response.json({ signals });
    await sleep(200);
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const sessionId = String(body.sessionId || "");
    const userId = String(body.userId || "");
    const kind = String(body.kind || "");
    const payload = body.payload;
    if (!sessionId || !userId || !kind || payload === undefined) {
      return Response.json({ error: "Incomplete signal." }, { status: 400 });
    }
    if (!(await activeMember(sessionId, userId))) return Response.json({ error: "Session not found." }, { status: 403 });
    const [signal] = await db.insert(callSignals).values({ sessionId, senderId: userId, kind, payload }).returning({ id: callSignals.id });
    return Response.json({ id: signal.id });
  } catch {
    return Response.json({ error: "Signal could not be sent." }, { status: 500 });
  }
}
