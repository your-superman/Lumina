import { desc, eq } from "drizzle-orm";
import { randomUUID } from "crypto";
import { db } from "@/db";
import { faceMasks } from "@/db/schema";
import { isAdmin, logActivity, profileForUser } from "@/lib/app";

export const dynamic = "force-dynamic";

function validPng(value: unknown) {
  const url = String(value || "").trim();
  if (!url) return "";
  // Uploaded gallery PNGs arrive as data URLs; external PNG links also work.
  if (url.startsWith("data:image/png") && url.length < 14_000_000) return url;
  try {
    const parsed = new URL(url);
    return (parsed.protocol === "http:" || parsed.protocol === "https:") && parsed.pathname.toLowerCase().endsWith(".png")
      ? parsed.toString()
      : "";
  } catch {
    return "";
  }
}

export async function GET(request: Request) {
  const userId = new URL(request.url).searchParams.get("userId") || "";
  const admin = await isAdmin(userId);
  const masks = await db.select().from(faceMasks).orderBy(desc(faceMasks.createdAt));
  const availableMasks = masks.filter((mask) => mask.active);
  const activeMask = availableMasks[0] || null;
  // Users receive every admin-published mask so they can choose their own
  // filter in the call; admins receive the full library including hidden ones.
  return Response.json(admin ? { activeMask, masks, availableMasks } : { activeMask, masks: availableMasks, availableMasks });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const userId = String(body.userId || "");
    if (!(await isAdmin(userId))) return Response.json({ error: "Administrator access required." }, { status: 403 });
    const action = String(body.action || "create");
    const id = String(body.id || "");

    if (action === "delete") {
      await db.delete(faceMasks).where(eq(faceMasks.id, id));
      return Response.json({ ok: true });
    }

    if (action === "activate" || action === "deactivate") {
      if (!id) return Response.json({ error: "Choose a mask first." }, { status: 400 });
      await db.update(faceMasks)
        .set({ active: action === "activate", updatedAt: new Date() })
        .where(eq(faceMasks.id, id));
      return Response.json({ ok: true });
    }

    const name = String(body.name || "Face mask").trim().slice(0, 80) || "Face mask";
    const imageUrl = validPng(body.imageUrl);
    if (!imageUrl) return Response.json({ error: "Please upload a PNG mask image." }, { status: 400 });

    const newId = randomUUID();
    const shouldActivate = body.activate !== false;
    await db.insert(faceMasks).values({ id: newId, name, imageUrl, active: shouldActivate, createdBy: userId });
    const profile = await profileForUser(userId);
    await logActivity(userId, "face_mask_created", profile?.country || "Unknown", { maskId: newId });
    return Response.json({ ok: true, id: newId });
  } catch {
    return Response.json({ error: "Face mask could not be saved." }, { status: 500 });
  }
}
