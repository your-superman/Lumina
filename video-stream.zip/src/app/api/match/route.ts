import { and, eq, ne } from "drizzle-orm";
import { randomUUID } from "crypto";
import { db } from "@/db";
import { callSessions, matchingQueue, profiles } from "@/db/schema";
import { logActivity, profileForUser, visitorCountry } from "@/lib/app";

export const dynamic = "force-dynamic";

const preferences = new Set(["all", "male", "female"]);

type MatchResult = {
  matched: boolean;
  sessionId?: string;
  initiator?: boolean;
  peer?: { name: string; gender: string; country: string; countryCode: string };
};

async function sessionResult(userId: string): Promise<MatchResult> {
  const [queueItem] = await db
    .select()
    .from(matchingQueue)
    .where(and(eq(matchingQueue.userId, userId), eq(matchingQueue.status, "matched")))
    .limit(1);

  if (!queueItem?.sessionId) return { matched: false };
  const [session] = await db.select().from(callSessions).where(eq(callSessions.id, queueItem.sessionId)).limit(1);
  if (!session || session.status !== "active") return { matched: false };
  const peerId = session.callerId === userId ? session.partnerId : session.callerId;
  const peer = await profileForUser(peerId);
  return {
    matched: true,
    sessionId: session.id,
    initiator: session.callerId === userId,
    peer: peer ? { name: peer.name || "Lumina guest", gender: peer.gender, country: peer.country, countryCode: peer.countryCode || "" } : undefined,
  };
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export async function GET(request: Request) {
  const url = new URL(request.url);
  const userId = url.searchParams.get("userId")?.trim() || "";
  if (!userId) return Response.json({ error: "userId is required" }, { status: 400 });
  // Long-poll while searching: matches surface within ~500 ms without
  // hammering the phone radio with interval requests.
  const wait = url.searchParams.get("wait") === "1";
  const deadline = Date.now() + (wait ? 8000 : 0);
  for (;;) {
    const result = await sessionResult(userId);
    if (result.matched || Date.now() >= deadline) return Response.json(result);
    await sleep(500);
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const userId = String(body.userId || "").trim();
    const action = String(body.action || "seek");
    if (!userId) return Response.json({ error: "userId is required" }, { status: 400 });

    if (action === "cancel") {
      const current = await sessionResult(userId);
      if (current.sessionId) {
        await db.update(callSessions).set({ status: "ended", endedBy: userId, endedAt: new Date() }).where(eq(callSessions.id, current.sessionId));
        await db.delete(matchingQueue).where(eq(matchingQueue.sessionId, current.sessionId));
      } else {
        await db.delete(matchingQueue).where(eq(matchingQueue.userId, userId));
      }
      const profile = await profileForUser(userId);
      await logActivity(userId, "match_cancelled", profile?.country || visitorCountry(request));
      return Response.json({ ok: true });
    }

    const preference = String(body.preference || "all").toLowerCase();
    const profile = await profileForUser(userId);
    if (!profile?.name || !profile.gender) {
      return Response.json({ error: "Finish your profile before searching." }, { status: 400 });
    }
    if (!preferences.has(preference)) return Response.json({ error: "Invalid preference." }, { status: 400 });

    const existing = await sessionResult(userId);
    if (existing.matched) return Response.json(existing);

    const matching = await db.transaction(async (tx) => {
      await tx
        .insert(matchingQueue)
        .values({
          userId,
          preference,
          gender: profile.gender,
          country: profile.country || visitorCountry(request),
          status: "searching",
          sessionId: null,
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: matchingQueue.userId,
          set: { preference, gender: profile.gender, status: "searching", sessionId: null, updatedAt: new Date() },
        });

      const waiting = await tx
        .select()
        .from(matchingQueue)
        .where(and(eq(matchingQueue.status, "searching"), ne(matchingQueue.userId, userId)))
        .orderBy(matchingQueue.createdAt)
        .limit(60);
      const candidate = waiting.find(
        (person) =>
          (preference === "all" || person.gender === preference) &&
          (person.preference === "all" || person.preference === profile.gender),
      );

      if (!candidate) return null;
      const sessionId = randomUUID();
      await tx.insert(callSessions).values({ id: sessionId, callerId: userId, partnerId: candidate.userId });
      await tx
        .update(matchingQueue)
        .set({ status: "matched", sessionId, updatedAt: new Date() })
        .where(eq(matchingQueue.userId, userId));
      await tx
        .update(matchingQueue)
        .set({ status: "matched", sessionId, updatedAt: new Date() })
        .where(eq(matchingQueue.userId, candidate.userId));
      return { sessionId, candidateId: candidate.userId };
    });

    if (!matching) {
      await logActivity(userId, "matching_started", profile.country, { preference });
      return Response.json({ matched: false, waiting: true });
    }
    const peer = await profileForUser(matching.candidateId);
    await Promise.all([
      logActivity(userId, "call_matched", profile.country, { sessionId: matching.sessionId }),
      logActivity(matching.candidateId, "call_matched", peer?.country || "Unknown", { sessionId: matching.sessionId }),
    ]);
    return Response.json({
      matched: true,
      sessionId: matching.sessionId,
      initiator: true,
      peer: peer ? { name: peer.name || "Lumina guest", gender: peer.gender, country: peer.country, countryCode: peer.countryCode || "" } : undefined,
    });
  } catch {
    return Response.json({ error: "Matchmaking is temporarily unavailable." }, { status: 500 });
  }
}
