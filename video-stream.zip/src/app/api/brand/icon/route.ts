import { brandIconBytes, getBrandSetting } from "@/lib/brand";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const size = new URL(request.url).searchParams.get("size") === "192" ? "192" : "512";
  const brand = await getBrandSetting();
  const dataUrl = size === "192" ? brand.icon192 || brand.icon512 : brand.icon512 || brand.icon192;
  const image = brandIconBytes(dataUrl);

  if (!image) {
    return Response.redirect(new URL(`/icons/icon-${size}.png`, request.url), 302);
  }

  return new Response(new Uint8Array(image.bytes), {
    headers: {
      "Content-Type": image.contentType,
      "Cache-Control": "public, max-age=86400, immutable",
      "X-Lumina-Brand-Updated": brand.updatedAt || "",
    },
  });
}
