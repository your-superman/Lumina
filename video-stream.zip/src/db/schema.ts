import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export const profiles = pgTable(
  "profiles",
  {
    userId: varchar("user_id", { length: 64 }).primaryKey(),
    email: varchar("email", { length: 320 }).notNull().default(""),
    name: varchar("name", { length: 80 }).notNull().default(""),
    dob: varchar("dob", { length: 10 }).notNull().default(""),
    gender: varchar("gender", { length: 16 }).notNull().default(""),
    country: varchar("country", { length: 80 }).notNull().default("Unknown"),
    countryCode: varchar("country_code", { length: 2 }).notNull().default(""),
    profileLockedUntil: timestamp("profile_locked_until", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("profiles_email_idx").on(table.email)],
);

export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id", { length: 64 }).notNull(),
  event: varchar("event", { length: 60 }).notNull(),
  country: varchar("country", { length: 80 }).notNull().default("Unknown"),
  detail: jsonb("detail").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const matchingQueue = pgTable("matching_queue", {
  userId: varchar("user_id", { length: 64 }).primaryKey(),
  preference: varchar("preference", { length: 16 }).notNull().default("all"),
  gender: varchar("gender", { length: 16 }).notNull().default(""),
  country: varchar("country", { length: 80 }).notNull().default("Unknown"),
  status: varchar("status", { length: 16 }).notNull().default("searching"),
  sessionId: varchar("session_id", { length: 64 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const callSessions = pgTable("call_sessions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  callerId: varchar("caller_id", { length: 64 }).notNull(),
  partnerId: varchar("partner_id", { length: 64 }).notNull(),
  status: varchar("status", { length: 16 }).notNull().default("active"),
  endedBy: varchar("ended_by", { length: 64 }),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  endedAt: timestamp("ended_at", { withTimezone: true }),
});

export const callSignals = pgTable(
  "call_signals",
  {
    id: serial("id").primaryKey(),
    sessionId: varchar("session_id", { length: 64 }).notNull(),
    senderId: varchar("sender_id", { length: 64 }).notNull(),
    kind: varchar("kind", { length: 24 }).notNull(),
    payload: jsonb("payload").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("call_signals_session_id_idx").on(table.sessionId, table.id)],
);

export const advertisements = pgTable("advertisements", {
  id: varchar("id", { length: 64 }).primaryKey(),
  title: varchar("title", { length: 120 }).notNull(),
  mediaUrl: text("media_url").notNull(),
  mediaType: varchar("media_type", { length: 12 }).notNull().default("image"),
  linkUrl: text("link_url").notNull().default(""),
  borderColor: varchar("border_color", { length: 20 }).notNull().default("#FC84BD"),
  durationSeconds: integer("duration_seconds"),
  active: boolean("active").notNull().default(true),
  createdBy: varchar("created_by", { length: 64 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const accounts = pgTable(
  "accounts",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    email: varchar("email", { length: 320 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    passwordSalt: varchar("password_salt", { length: 64 }).notNull(),
    name: varchar("name", { length: 80 }).notNull(),
    dob: varchar("dob", { length: 10 }).notNull(),
    gender: varchar("gender", { length: 16 }).notNull(),
    country: varchar("country", { length: 80 }).notNull().default("Unknown"),
    countryCode: varchar("country_code", { length: 2 }).notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  },
  (table) => [uniqueIndex("accounts_email_idx").on(table.email)],
);

export const presence = pgTable(
  "presence",
  {
    userId: varchar("user_id", { length: 64 }).primaryKey(),
    name: varchar("name", { length: 80 }).notNull().default(""),
    gender: varchar("gender", { length: 16 }).notNull().default(""),
    country: varchar("country", { length: 80 }).notNull().default("Unknown"),
    countryCode: varchar("country_code", { length: 2 }).notNull().default(""),
    lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("presence_last_seen_idx").on(table.lastSeen)],
);

export const visitors = pgTable(
  "visitors",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    userId: varchar("user_id", { length: 64 }).notNull().default(""),
    deviceType: varchar("device_type", { length: 24 }).notNull().default("desktop"),
    deviceLabel: varchar("device_label", { length: 80 }).notNull().default("Web browser"),
    country: varchar("country", { length: 80 }).notNull().default("Unknown"),
    countryCode: varchar("country_code", { length: 2 }).notNull().default(""),
    visits: integer("visits").notNull().default(1),
    firstSeen: timestamp("first_seen", { withTimezone: true }).notNull().defaultNow(),
    lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("visitors_last_seen_idx").on(table.lastSeen),
    index("visitors_country_idx").on(table.countryCode),
    index("visitors_user_idx").on(table.userId),
  ],
);

export const notifications = pgTable(
  "notifications",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    targetUserId: varchar("target_user_id", { length: 64 }),
    title: varchar("title", { length: 200 }).notNull(),
    body: text("body").notNull().default(""),
    imageUrl: text("image_url").notNull().default(""),
    createdBy: varchar("created_by", { length: 64 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
  },
  (table) => [
    index("notifications_target_created_idx").on(table.targetUserId, table.createdAt),
    index("notifications_expires_idx").on(table.expiresAt),
    index("notifications_created_idx").on(table.createdAt),
  ],
);

export const notificationReads = pgTable(
  "notification_reads",
  {
    notificationId: varchar("notification_id", { length: 64 }).notNull(),
    userId: varchar("user_id", { length: 64 }).notNull(),
    readAt: timestamp("read_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("notification_reads_pair_idx").on(table.notificationId, table.userId),
    index("notification_reads_user_idx").on(table.userId),
  ],
);

export const faceMasks = pgTable("face_masks", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 80 }).notNull(),
  imageUrl: text("image_url").notNull(),
  active: boolean("active").notNull().default(false),
  createdBy: varchar("created_by", { length: 64 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const appSettings = pgTable("app_settings", {
  key: varchar("key", { length: 64 }).primaryKey(),
  value: jsonb("value").notNull().default({}),
  updatedBy: varchar("updated_by", { length: 64 }).notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const supportMessages = pgTable(
  "support_messages",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    userId: varchar("user_id", { length: 64 }).notNull(),
    senderId: varchar("sender_id", { length: 64 }).notNull(),
    senderRole: varchar("sender_role", { length: 12 }).notNull().default("user"),
    body: text("body").notNull().default(""),
    imageUrl: text("image_url").notNull().default(""),
    readByAdmin: boolean("read_by_admin").notNull().default(false),
    readByUser: boolean("read_by_user").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("support_messages_user_created_idx").on(table.userId, table.createdAt),
    index("support_messages_created_idx").on(table.createdAt),
  ],
);
