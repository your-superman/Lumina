import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appSettings } from "@/db/schema";
import { getBrandSetting, getSplashSetting, validBrandImage, validSplashMedia } from "@/lib/brand";
import { isAdmin, logActivity, profileForUser } from "@/lib/app";

export const dynamic = "force-dynamic";

export async function GET() {
  const [brand, splash] = await Promise.all([getBrandSetting(), getSplashSetting()]);
  return Response.json({
    ...brand,
    icon: brand.icon512 || "/icons/icon-512.png",
    defaultIcon: "/icons/icon-512.png",
    splash,
  }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const userId = String(body.userId || "");
    if (!(await isAdmin(userId))) return Response.json({ error: "Administrator access required." }, { status: 403 });
    const action = String(body.action || "save");

    if (action === "reset") {
      await db.delete(appSettings).where(eq(appSettings.key, "brand"));
      const profile = await profileForUser(userId);
      await logActivity(userId, "brand_icon_reset", profile?.country || "Unknown");
      return Response.json({ ok: true, icon: "/icons/icon-512.png", icon192: "", icon512: "", updatedAt: null });
    }

    if (action === "deleteSplash") {
      await db.delete(appSettings).where(eq(appSettings.key, "splash"));
      const profile = await profileForUser(userId);
      await logActivity(userId, "splash_deleted", profile?.country || "Unknown");
      return Response.json({ ok: true, splash: await getSplashSetting() });
    }

    if (action === "saveSplash") {
      const mode = String(body.mode || "logo") === "full" ? "full" : "logo";
      const mediaType = String(body.mediaType || "image") === "video" ? "video" : String(body.mediaType || "image") === "gif" ? "gif" : "image";
      const maxDuration = mode === "logo" ? 10 : 8;
      const requestedDuration = Number(body.durationSeconds ?? 2);
      const durationSeconds = Number.isFinite(requestedDuration)
        ? Math.min(maxDuration, Math.max(1, Math.floor(requestedDuration)))
        : 2;
      const mediaUrl = mode === "full" ? validSplashMedia(body.mediaUrl, mediaType) : "";
      if (mode === "full" && !mediaUrl) {
        return Response.json({ error: "Please upload a full-screen image, GIF or video for the splash screen." }, { status: 400 });
      }
      const value = { mode, mediaType, mediaUrl, durationSeconds };
      const now = new Date();
      await db.insert(appSettings)
        .values({ key: "splash", value, updatedBy: userId, updatedAt: now })
        .onConflictDoUpdate({ target: appSettings.key, set: { value, updatedBy: userId, updatedAt: now } });
      const profile = await profileForUser(userId);
      await logActivity(userId, "splash_updated", profile?.country || "Unknown", { mode, mediaType, durationSeconds });
      return Response.json({ ok: true, splash: { ...value, updatedAt: now.toISOString() } });
    }

    const icon512 = validBrandImage(body.icon512);
    const icon192 = validBrandImage(body.icon192) || icon512;
    if (!icon512 || !icon192) return Response.json({ error: "Please upload a PNG, JPG or WebP logo image." }, { status: 400 });

    const value = { icon192, icon512 };
    const now = new Date();
    await db.insert(appSettings)
      .values({ key: "brand", value, updatedBy: userId, updatedAt: now })
      .onConflictDoUpdate({ target: appSettings.key, set: { value, updatedBy: userId, updatedAt: now } });

    const profile = await profileForUser(userId);
    await logActivity(userId, "brand_icon_updated", profile?.country || "Unknown");
    return Response.json({ ok: true, icon: icon512, icon192, icon512, updatedAt: now.toISOString() });
  } catch {
    return Response.json({ error: "Brand icon could not be saved." }, { status: 500 });
  }
}
