class LuminaAudioProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.gain = 1;
    this.envelope = 0;
  }

  process(inputs, outputs) {
    const input = inputs[0];
    const output = outputs[0];
    if (!input || !input[0] || !output || !output[0]) return true;

    // Lightweight speech gate + slow AGC on the dedicated audio thread.
    // Native browser AEC/NS remains active before this stage; this only
    // smooths level jumps and reduces steady background hiss.
    let sum = 0;
    const first = input[0];
    for (let i = 0; i < first.length; i++) sum += first[i] * first[i];
    const rms = Math.sqrt(sum / Math.max(1, first.length));
    this.envelope += (rms - this.envelope) * 0.08;

    const gate = this.envelope < 0.006 ? 0.35 : 1;
    const desiredGain = Math.min(2.2, Math.max(0.55, 0.16 / Math.max(0.035, this.envelope))) * gate;
    this.gain += (desiredGain - this.gain) * 0.04;

    for (let channel = 0; channel < output.length; channel++) {
      const source = input[Math.min(channel, input.length - 1)] || first;
      const destination = output[channel];
      for (let i = 0; i < destination.length; i++) {
        const sample = Math.max(-1, Math.min(1, source[i] * this.gain));
        destination[i] = sample;
      }
    }
    return true;
  }
}

registerProcessor("lumina-audio-processor", LuminaAudioProcessor);
