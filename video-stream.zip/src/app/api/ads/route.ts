import { desc, eq } from "drizzle-orm";
import { randomUUID } from "crypto";
import { db } from "@/db";
import { advertisements } from "@/db/schema";
import { isAdmin, logActivity, profileForUser } from "@/lib/app";

export const dynamic = "force-dynamic";

function safeUrl(value: unknown, allowEmpty = false) {
  const url = String(value || "").trim();
  if (!url && allowEmpty) return "";
  // Gallery uploads arrive as data URLs (any aspect ratio, kept whole).
  if ((url.startsWith("data:image/") || url.startsWith("data:video/")) && url.length < 28_000_000) return url;
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.toString() : "";
  } catch {
    return "";
  }
}

export async function GET(request: Request) {
  const viewerId = new URL(request.url).searchParams.get("userId") || "";
  const admin = await isAdmin(viewerId);
  const ads = await db
    .select()
    .from(advertisements)
    .where(admin ? undefined : eq(advertisements.active, true))
    .orderBy(desc(advertisements.createdAt));
  return Response.json({ ads, admin });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const userId = String(body.userId || "");
    if (!(await isAdmin(userId))) return Response.json({ error: "Administrator access required." }, { status: 403 });
    const action = String(body.action || "create");
    const adId = String(body.id || "");

    if (action === "delete") {
      await db.delete(advertisements).where(eq(advertisements.id, adId));
      const profile = await profileForUser(userId);
      await logActivity(userId, "ad_deleted", profile?.country || "Unknown", { adId });
      return Response.json({ ok: true });
    }

    if (action === "toggle") {
      const active = Boolean(body.active);
      await db.update(advertisements).set({ active, updatedAt: new Date() }).where(eq(advertisements.id, adId));
      return Response.json({ ok: true });
    }

    const title = String(body.title || "").trim().slice(0, 120);
    const mediaUrl = safeUrl(body.mediaUrl);
    const linkUrl = safeUrl(body.linkUrl, true);
    const mediaType = String(body.mediaType || "image") === "video" ? "video" : "image";
    const borderColor = /^#[0-9a-fA-F]{6}$/.test(String(body.borderColor || "")) ? String(body.borderColor) : "#FC84BD";
    const durationSeconds = body.durationSeconds ? Math.round(Number(body.durationSeconds)) : null;
    if (!title || !mediaUrl) return Response.json({ error: "An ad title and an image/video are required." }, { status: 400 });
    if (mediaType === "video" && durationSeconds !== null && (durationSeconds < 3 || durationSeconds > 30)) {
      return Response.json({ error: "Video ads must be between 3 and 30 seconds." }, { status: 400 });
    }

    if (action === "update" && adId) {
      await db
        .update(advertisements)
        .set({ title, mediaUrl, linkUrl, mediaType, borderColor, durationSeconds, updatedAt: new Date() })
        .where(eq(advertisements.id, adId));
      return Response.json({ ok: true, id: adId });
    }

    const id = randomUUID();
    await db.insert(advertisements).values({ id, title, mediaUrl, linkUrl, mediaType, borderColor, durationSeconds, active: true, createdBy: userId });
    const profile = await profileForUser(userId);
    await logActivity(userId, "ad_created", profile?.country || "Unknown", { adId: id, mediaType });
    return Response.json({ ok: true, id });
  } catch {
    return Response.json({ error: "Advertisement could not be saved." }, { status: 500 });
  }
}
