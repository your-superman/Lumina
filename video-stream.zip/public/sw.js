const CACHE_NAME = "lumina-shell-v8";
const CORE = ["/", "/manifest.webmanifest", "/lumina-icon.svg", "/icons/icon-192.png", "/icons/icon-512.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(CORE))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/api/")) return; // live data is never cached

  if (url.pathname === "/manifest.webmanifest") {
    // Always fetch the newest manifest so an admin-changed logo reaches the
    // PWA install icon instead of being trapped in an old cache.
    event.respondWith(fetch(request, { cache: "no-store" }).catch(() => caches.match(request, { ignoreSearch: true })));
    return;
  }

  const isStaticAsset =
    url.pathname.startsWith("/_next/static/") ||
    url.pathname.startsWith("/icons/") ||
    url.pathname.startsWith("/mediapipe/") ||
    url.pathname.startsWith("/models/") ||
    url.pathname === "/lumina-icon.svg";

  if (isStaticAsset) {
    // Cache-first with a quiet background refresh: repeat opens work offline
    // instantly while assets still update when the network returns.
    event.respondWith(
      caches.match(request, { ignoreSearch: true }).then((cached) => {
        const refresh = fetch(request).then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          }
          return response;
        }).catch(() => cached);
        return cached || refresh;
      })
    );
    return;
  }

  if (request.mode === "navigate") {
    // Network-first for the app shell, falling back to the cached shell so
    // Lumina opens offline. Live calls and data simply resume when online.
    event.respondWith(
      fetch(request).then((response) => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put("/", copy));
        }
        return response;
      }).catch(async () => (await caches.match("/", { ignoreSearch: true })) || caches.match(request, { ignoreSearch: true }))
    );
  }
});

self.addEventListener("push", (event) => {
  let payload = { title: "Lumina Connect", body: "You have a new update." };
  try {
    if (event.data) payload = { ...payload, ...event.data.json() };
  } catch {
    if (event.data) payload.body = event.data.text();
  }
  event.waitUntil(self.registration.showNotification(payload.title, {
    body: payload.body,
    icon: "/api/brand/icon?size=192",
    badge: "/api/brand/icon?size=192",
    data: { url: payload.url || "/" },
  }));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = event.notification.data?.url || "/";
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clients) => {
      for (const client of clients) {
        if ("focus" in client) return client.focus();
      }
      return self.clients.openWindow(target);
    })
  );
});
