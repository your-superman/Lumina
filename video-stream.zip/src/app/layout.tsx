import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import Script from "next/script";
import "./globals.css";

export const metadata: Metadata = {
  title: "Lumina Connect — Real people. Real moments.",
  description: "Instant, real-time video connections with people around the world.",
  applicationName: "Lumina Connect",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/api/brand/icon?size=192", sizes: "192x192", type: "image/png" },
      { url: "/api/brand/icon?size=512", sizes: "512x512", type: "image/png" },
      { url: "/lumina-icon.svg", sizes: "any", type: "image/svg+xml" },
    ],
    apple: "/api/brand/icon?size=512",
  },
  appleWebApp: { capable: true, statusBarStyle: "default", title: "Lumina" },
};

export const viewport: Viewport = {
  themeColor: "#FC84BD",
  colorScheme: "light",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        {/* Capture the PWA install prompt the moment the browser offers it,
            so the in-app Install button works on first tap, every time. */}
        <Script id="lumina-install-capture" strategy="beforeInteractive">{`
          window.__luminaBIP = null;
          window.addEventListener("beforeinstallprompt", function (e) { e.preventDefault(); window.__luminaBIP = e; });
          window.addEventListener("appinstalled", function () { window.__luminaBIP = null; });
        `}</Script>
        {children}
      </body>
    </html>
  );
}
